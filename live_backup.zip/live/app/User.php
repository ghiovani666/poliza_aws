<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;

/**
 * @property string password
 */
class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $appends = ['isAdmin'];

    public function routeNotificationForSlack($notification)
    {
        return 'https://hooks.slack.com/services/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';
    }

    public function employee()
    {
        return $this->hasOne(Employee::class)->withDefault();
    }

    public function getIsAdminAttribute()
    {
        return $this->employee->type == 1;
    }

    public function getIsAssessorAttribute()
    {
        return in_array($this->employee->type, [1, 2, 7]);
    }

    public function loginAs(User $user)
    {
        if ($user->can('loginAs')) {
            Auth::login($user);
        }

        return Auth::user();
    }

    public function changePassword(string $newPassword)
    {
        $this->password = bcrypt($newPassword);

        return $this;
    }
}
