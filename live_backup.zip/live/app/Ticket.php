<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $guarded = [];
    protected $casts = ['copy_to' => 'array'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault(['name' => 'No asignado']);
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function getEmployeesToCopy()
    {
        return Employee::query()->whereIn('id', $this->copy_to)->orderBy('name')->get();
    }

    public function comments()
    {
        return $this->morphMany(Comment::class, 'commentable');
    }
}
