<?php

namespace App\Observers;

use App\Lead;
use App\Notifications\LeadWasCreated;
use Carbon\Carbon;

class LeadObserver
{
    /**
     * Handle the lead "created" event.
     *
     * @param Lead $lead
     * @return void
     */
    public function created(Lead $lead)
    {

    }

    /**
     * Handle the lead "updated" event.
     *
     * @param Lead $lead
     * @return void
     */
    public function updated(Lead $lead)
    {
        //
    }

    /**
     * Handle the lead "deleted" event.
     *
     * @param Lead $lead
     * @return void
     */
    public function deleted(Lead $lead)
    {
        //
    }

    /**
     * Handle the lead "restored" event.
     *
     * @param Lead $lead
     * @return void
     */
    public function restored(Lead $lead)
    {
        //
    }

    /**
     * Handle the lead "force deleted" event.
     *
     * @param Lead $lead
     * @return void
     */
    public function forceDeleted(Lead $lead)
    {
        //
    }

    public function saving(Lead $lead)
    {
        // save win date when stage_id = 5 or process_id = 3
        if ($lead->stage_id == 5 || $lead->process_id == 3) {
            $lead->win_date = Carbon::now();
        }
    }
}
