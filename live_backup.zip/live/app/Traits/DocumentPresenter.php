<?php


namespace App\Traits;


use Illuminate\Support\Facades\Storage;

trait DocumentPresenter
{
    public function getPublishedAttribute()
    {
        return $this->enabled ? 'Si' : 'No';
    }

    public function getFileUrlAttribute()
    {
        return asset($this->url);
    }

    public function getHasFileAttribute()
    {
        return Storage::exists($this->filename);
    }
}
