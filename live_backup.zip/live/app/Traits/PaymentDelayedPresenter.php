<?php


namespace App\Traits;


use Carbon\Carbon;

trait PaymentDelayedPresenter
{
    public function getPaymentExpirationDateAttribute()
    {
        $date = Carbon::parse($this->expiration_date);
        return $date->format('d/m/Y');
    }
}
