<?php


namespace App\Traits;


trait DateTimeHelper
{
    private $timeZone = 'America/Lima';

    public function getCreatedTimeAgoAttribute()
    {
        return $this->created_at->tz($this->timeZone)->diffForHumans();
    }

    public function getCreatedDateTimeAttribute()
    {
        return $this->created_at->tz($this->timeZone)->format('d/m/Y H:i');
    }

    public function getUpdatedDateTimeAttribute()
    {
        return $this->updated_at->tz($this->timeZone)->format('d/m/Y H:i');
    }

    public function getBirthDateStringAttribute()
    {
        if (is_null($this->birth_date)) {
            return null;
        }

        return $this->birth_date->format('d/m/Y');
    }

    public function getHasBirthDateAttribute()
    {
        return !is_null($this->birth_date);
    }

    public function toDate($field)
    {
        if (is_null($this->$field)) {
            return null;
        }

        return $this->$field->format('d/m/Y');
    }
}
