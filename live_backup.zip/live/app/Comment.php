<?php

namespace App;

use App\Traits\DateTimeHelper;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class Comment extends Model
{
    use DateTimeHelper, SoftDeletes;

    protected $casts = ['actions' => 'array'];
    protected $appends = ['actionsNamed', 'hasAttachment', 'attachmentUrl', 'createdTimeAgo'];
    protected $guarded = [];

    public function commentable()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getActionsNamedAttribute()
    {
        if (!is_array($this->actions)) {
            return [];
        }

        $actions = CommentAction::query()->whereIn('id', $this->actions)->get(['id', 'name']);

        if (is_object($actions)) {
            return $actions->toArray();
        }

        return [];
    }

    public function getHasAttachmentAttribute()
    {
        return Storage::disk('public')->exists($this->attachment);
    }

    public function getAttachmentUrlAttribute()
    {
        return Storage::disk('public')->url($this->attachment);
    }

    public function scopeByEmployee(Builder $query, Employee $employee)
    {
        return $query->where('user_id', $employee->user_id);
    }

    public function scopeWithAction(Builder $query, $id)
    {
        return $query->where('actions', 'like', '%' . $id . '%');
    }

    public function scopeRangeDate(Builder $query, Request $request, $field = 'created_at')
    {
        $query->when($request->filled($field), function (Builder $query) use ($request, $field) {
            $dates = explode(' - ', $request->get($field));
            $fromDate = Carbon::parse($dates[0])->utc()->toDateTimeString();
            $toDate = Carbon::parse($dates[1])->utc()->addHours(24)->toDateTimeString();

            $query->whereBetween($field, [$fromDate, $toDate]);
        });
    }
}
