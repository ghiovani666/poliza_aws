<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PolicyBeneficiary extends Model
{
    protected $guarded = [];
}
