<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeType extends Model
{
    const SELL_SUPERVISOR = 12;
    const SELL_ASSESSOR = 13;

    public function supervise()
    {
        return $this->belongsToMany(EmployeeType::class, 'role_supervise', 'role_id', 'supervise_id');
    }

    public function hierarchy()
    {
        $roles = [$this->id];
        $data = $this->supervise->pluck('id')->toArray();
        while (is_array($data) && count($data) > 0) {
            $current = $data;
            $data = [];

            foreach ($current as $value) {
                $roles[] = $value;
                $rows = EmployeeType::find($value)->supervise->pluck('id')->toArray();
                if (is_array($rows)) {
                    $data = array_merge($data, $rows);
                }
            }
        }
        return $roles;
    }
}
