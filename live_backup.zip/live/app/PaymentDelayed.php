<?php

namespace App;

use App\Traits\DateTimeHelper;
use App\Traits\PaymentDelayedPresenter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentDelayed extends Model
{
    use DateTimeHelper, PaymentDelayedPresenter, SoftDeletes;

    protected $guarded = [];

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'No encontrado']);;
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault(['name' => 'No encontrado']);;
    }

    public function assessor()
    {
        return $this->belongsTo(Employee::class)->withDefault(['name' => 'No encontrado']);
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class)->withDefault(['name' => 'No encontrado']);;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function policy()
    {
        return $this->belongsTo(Policy::class)->withDefault(['name' => 'No encontrado']);
    }
}
