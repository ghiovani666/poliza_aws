<?php

namespace App;

use App\Traits\DateTimeHelper;
use App\Traits\DocumentPresenter;
use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    use DateTimeHelper, DocumentPresenter;

    protected $guarded = [];

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'No encontrado']);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
