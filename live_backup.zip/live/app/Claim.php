<?php

namespace App;

use App\Traits\DateTimeHelper;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

class Claim extends Model
{
    use SoftDeletes, DateTimeHelper;

    /**
     * @var array
     */
    protected $guarded = [];

    /**
     * @param Policy $policy
     * @param Request $request
     * @return Builder
     */
    public static function fetchAll(Policy $policy, Request $request)
    {
        return Claim::query()
            ->where('policy_id', $policy->id);
    }

    public function policy()
    {
        return $this->belongsTo(Policy::class)->withDefault();
    }

    public function files()
    {
        return $this->hasMany(ClaimFile::class);
    }
}
