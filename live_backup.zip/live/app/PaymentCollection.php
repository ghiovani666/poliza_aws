<?php

namespace App;

use App\Traits\DateTimeHelper;
use Illuminate\Database\Eloquent\Model;

class PaymentCollection extends Model
{
    use DateTimeHelper;

    protected $guarded = [];
    protected $casts = ['policies' => 'array'];

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'No asignado']);
    }

    public function sector()
    {
        return $this->belongsTo(Sector::class)->withDefault(['name' => 'No asignado']);
    }

    public function product()
    {
        return $this->belongsTo(Product::class)->withDefault(['name' => 'No asignado']);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault(['name' => 'No asignado']);
    }

    public function assessor()
    {
        return $this->belongsTo(Employee::class)->withDefault(['name' => 'No asignado']);
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class)->withDefault(['name' => 'No asignado']);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getPoliciesCounterAttribute()
    {
        return is_array($this->policies) ? count($this->policies) : 0;
    }

    public function getStatusNameAttribute()
    {
        if (is_null($this->status)) {
            return 'No asignado';
        }

        $statuses = dropdownData('PaymentCollectionStatuses');
        return $statuses[$this->status];
    }

    public function getPoliciesNumberAttribute()
    {
        if (is_array($this->policies)) {
            $policies = Policy::query()->whereIn('id', $this->policies)->get('code');
            return $policies->implode('code', ',');
        }
        return null;
    }
}
