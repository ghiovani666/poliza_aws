<?php

namespace App;

use App\Helpers\PolicyPresenter;
use App\Traits\DateTimeHelper;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

class Accident extends Model
{
    use SoftDeletes, DateTimeHelper, PolicyPresenter;

    /**
     * @var array
     */
    protected $guarded = [];

    /**
     * @param Policy $policy
     * @param Request $request
     * @return Builder
     */
    public static function fetchAll(Policy $policy, Request $request)
    {
        return Accident::query()
            ->where('policy_id', $policy->id);
            // ->with(['status', 'customer', 'assessor', 'company'])
            // ->leftJoin('customers', 'customers.id', '=', 'policies.customer_id')
            // ->select('policies.*', 'customers.name', 'customers.document_number')
            // ->when($request->filled('customer'), function (Builder $query) use ($request) {
            //     $query->where('customers.name', 'like', "%{$request->customer}%");
            // })
            // ->when($request->filled('document'), function (Builder $query) use ($request) {
            //     $query->where('customers.document_number', 'like', "%{$request->document}%");
            // })
            // ->when($request->filled('code'), function ($query) use ($request) {
            //     $query->where('policies.code', 'like', "%{$request->code}%");
            // })
            // ->when($request->filled('active'), function ($query) use ($request) {
            //     $query->where('active', (int)$request->active);
            // })
            // ->when($request->filled('status_id'), function ($query) use ($request) {
            //     $query->where('operation_status', (int)$request->status_id);
            // })
            // ->when($request->filled('request_date'), function ($query) use ($request) {
            //     $range = explode(' a ', $request->get('request_date'));
            //     $from = Carbon::createFromFormat('d/m/Y', $range[0]);
            //     $to = Carbon::createFromFormat('d/m/Y', $range[1]);

            //     $query->whereBetween('requested_date', [$from, $to]);
            // })
            // ->when($request->filled('delivery_date'), function ($query) use ($request) {
            //     $range = explode(' a ', $request->get('delivery_date'));
            //     $from = Carbon::createFromFormat('d/m/Y', $range[0]);
            //     $to = Carbon::createFromFormat('d/m/Y', $range[1]);

            //     $query->whereBetween('delivery_date', [$from, $to]);
            // })
            // ->when($request->filled('validity_date'), function ($query) use ($request) {
            //     $range = explode(' a ', $request->get('validity_date'));
            //     $from = Carbon::createFromFormat('d/m/Y', $range[0])->toDateString();
            //     $to = Carbon::createFromFormat('d/m/Y', $range[1])->toDateString();

            //     $query->whereBetween('validity_date', [$from, $to]);
            // })
            // ->when($request->filled('assessor_id'), function ($query) use ($request) {
            //     $query->where('assessor_id', $request->assessor_id);
            // })
            // ->when($employee->job->visibility == 2, function ($query) use ($employee) {
            //     if (is_null($employee->supervise)) {
            //         $employee->supervise = [];
            //     }
            //     $query->where(function ($query) use ($employee) {
            //         $query->whereIn('assessor_id', $employee->supervise)
            //             ->orWhere('assessor_id', $employee->id);
            //     });
            // })
            // ->when($employee->job->visibility == 3, function ($query) use ($employee) {
            //     $query->where('assessor_id', $employee->id);
            // });
    }

    public function policy()
    {
        return $this->belongsTo(Policy::class)->withDefault();
    }

    public function files()
    {
        return $this->hasMany(AccidentFile::class);
    }
}
