<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PolicyPaymentType extends Model
{
    protected $guarded = [];
}
