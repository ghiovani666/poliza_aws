<?php

namespace App;

use App\Enums\DocumentType;
use App\Traits\DateTimeHelper;
use Carbon\Carbon;
use Collective\Html\Eloquent\FormAccessible;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

/**
 * @property Carbon birth_date
 */
class Customer extends Model
{
    use DateTimeHelper, FormAccessible, SoftDeletes;

    protected $guarded = [];
    protected $dates = ['birth_date'];

    /**
     * @param Employee $employee
     * @param Request $request
     * @return Builder|mixed
     */
    public static function fetchAll(Employee $employee, Request $request)
    {
        return Customer::query()
            ->with(['policies'])
            ->withCount(['policies'])
            ->when($request->filled('name'), function ($query) use ($request) {
                $query->where('name', 'like', "%{$request->get('name')}%");
            })
            ->when($request->filled('dni'), function ($query) use ($request) {
                $query->where('document_number', 'like', "%{$request->get('dni')}%");
            })
            ->when($employee->job->visibility == 2, function ($query) use ($employee) {
                if (is_null($employee->supervise)) {
                    $employee->supervise = [];
                }

                $customersId = Policy::query()->whereIn('assessor_id', $employee->supervise)->pluck('customer_id');
                $query->whereIn('id', $customersId);
            })
            ->when($employee->job->visibility == 3, function ($query) use ($employee) {
                $customersId = Policy::query()->where('assessor_id', $employee->id)->pluck('customer_id');
                $query->whereIn('id', $customersId);
            });
    }

    public function policies()
    {
        return $this->hasMany(Policy::class);
    }

    public function getDocumentTypeNameAttribute()
    {
        return DocumentType::getDescription($this->document_type);
    }

    public function getAgeAttribute()
    {
        if (is_null($this->birth_date)) {
            return null;
        }

        return $this->birth_date->age;
    }

    public function formBirthDateAttribute()
    {
        return Carbon::parse($this->birth_date)->format('Y-m-d');
    }
}
