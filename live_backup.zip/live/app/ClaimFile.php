<?php

namespace App;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

class ClaimFile extends Model
{
    /**
     * @var array
     */
    protected $guarded = [];

    /**
     * @param Policy $policy
     * @param Request $request
     * @return Builder
     */
    public static function fetchAll(Policy $policy, Request $request)
    {
        return Claim::query()
            ->where('policy_id', $policy->id);
    }

    public function claim()
    {
        return $this->belongsTo(Claim::class)->withDefault();
    }
}
