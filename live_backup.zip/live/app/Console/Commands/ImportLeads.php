<?php

namespace App\Console\Commands;

use App\Imports\LeadsImport;
use App\Lead;
use Illuminate\Console\Command;
use Maatwebsite\Excel\Facades\Excel;

class ImportLeads extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:leads';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import leads';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // clean table
        //Lead::query()->truncate();

        // store
        $filePath = storage_path('app/import_leads.xls');

        // import
        Excel::import(new LeadsImport(), $filePath);
    }
}
