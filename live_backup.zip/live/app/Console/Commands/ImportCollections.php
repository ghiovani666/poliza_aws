<?php

namespace App\Console\Commands;

use App\Imports\FinancesImport;
use App\Imports\PaymentCollectionsImport;
use App\PaymentCollection;
use Illuminate\Console\Command;
use Maatwebsite\Excel\Facades\Excel;

class ImportCollections extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:collections';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // clean table
        PaymentCollection::query()->truncate();

        // store
        $filePath = storage_path('app/import_collections.csv');

        // import
        Excel::import(new PaymentCollectionsImport(), $filePath);
    }
}
