<?php

namespace App\Console\Commands;

use App\Finance;
use App\Imports\FinancesImport;
use Illuminate\Console\Command;
use Maatwebsite\Excel\Facades\Excel;

class ImportFinances extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:finances';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // clean table
        Finance::query()->truncate();

        // store
        $filePath = storage_path('app/import_finances.csv');

        // import
        Excel::import(new FinancesImport(), $filePath);
    }
}
