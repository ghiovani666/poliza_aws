<?php

namespace App\Console\Commands;

use App\Imports\PoliciesImport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ImportPolicies extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:policies';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import initial policies';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // truncate table
        DB::table('employees')->truncate();
        DB::table('customers')->truncate();
        DB::table('policies')->truncate();
        DB::table('policy_beneficiaries')->truncate();
        DB::table('policy_insureds')->truncate();

        // store
        $filePath = storage_path('app/MorganData5.csv');

        // import
        Excel::import(new PoliciesImport, $filePath);
    }
}
