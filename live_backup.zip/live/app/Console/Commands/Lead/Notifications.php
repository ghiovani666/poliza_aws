<?php

namespace App\Console\Commands\Lead;

use App\Employee;
use App\Notifications\DailyReportToAdmin;
use App\Notifications\DailyReportToAssessor;
use App\Notifications\DailyReportToSupervisor;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Notification;

class Notifications extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'leads:notifications';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send leads reports';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $admins = Employee::query()->where('type', 8)->get();

        Notification::send($admins, new DailyReportToAdmin());

        $supervisors = Employee::query()->where('type', 6)->get();

        Notification::send($supervisors, new DailyReportToSupervisor());

        $assessors = Employee::query()->where('type', 1)->where('id','>',6)->get();

        Notification::send($assessors, new DailyReportToAssessor());
    }
}
