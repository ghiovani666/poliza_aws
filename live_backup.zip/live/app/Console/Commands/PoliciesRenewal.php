<?php

namespace App\Console\Commands;

use App\Policy;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class PoliciesRenewal extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'policies:renewal';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate pre renewal policies';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // check annual policies
        Policy::query()
            ->where('period', 12)
            ->whereDate(DB::raw('NOW()'), DB::raw('DATE_SUB(renewal_date, INTERVAL 30 DAY)'))
            //->whereBetween(DB::raw('DATEDIFF(renewal_date, NOW())'), [0, 30]) // only for update once time
            ->get()
            ->each(function (Policy $policy) {
                $policy->createPreRenewal()->save();
            });

        // check non annual policies
        Policy::query()
            ->where('period', '<>', 12)
            ->whereDate(DB::raw('NOW()'), DB::raw('DATE_SUB(renewal_date, INTERVAL 5 DAY)'))
            ->get()
            ->each(function (Policy $policy) {
                $policy->createPreRenewal()->save();
            });
    }
}
