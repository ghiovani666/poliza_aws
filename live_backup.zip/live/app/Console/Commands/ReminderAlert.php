<?php

namespace App\Console\Commands;

use App\Employee;
use App\Notifications\AlertLoyaltyNotification;
use App\Notifications\AlertRenewalNotification;
use App\Notifications\AlertSurveyNotification;
use App\Policy;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;

class ReminderAlert extends Command
{
    /**
     * @var Collection
     */
    public $users;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reminder:alert';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reminder for alerts';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->users = Employee::query()->where('type', 5)->get();

        $this->sendLoyalties();
        $this->sendSurveys();
        $this->sendRenewal();
    }

    private function sendLoyalties()
    {
        // loyalties
        $policies = Policy::query()
            ->where('alert_royalties_enabled', true)
            ->where('release_date', '=', DB::raw('SUBDATE(date(now()),alert_royalties_days)'))
            ->get();
        Notification::send($this->users, new AlertLoyaltyNotification($policies));
    }

    private function sendSurveys()
    {
        // surveys
        $policies = Policy::query()
            ->where('alert_surveys_enabled', true)
            ->where('release_date', '=', DB::raw('SUBDATE(date(now()),alert_surveys_days)'))
            ->get();
        Notification::send($this->users, new AlertSurveyNotification($policies));
    }

    private function sendRenewal()
    {
        // renewal
        $policies = Policy::query()
            ->where('alert_renewal_enabled', true)
            ->where('release_date', '=', DB::raw('SUBDATE(date(now()),alert_renewal_days)'))
            ->get();
        Notification::send($this->users, new AlertRenewalNotification($policies));
    }
}
