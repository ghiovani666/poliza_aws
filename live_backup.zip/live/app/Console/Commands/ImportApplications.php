<?php

namespace App\Console\Commands;

use App\Imports\ApplicationsImport;
use App\Imports\PoliciesImport;
use App\PaymentApplication;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ImportApplications extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:applications';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import initial applications';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // clean table
        PaymentApplication::query()->truncate();

        // store
        $filePath = storage_path('app/import_applications.csv');

        // import
        Excel::import(new ApplicationsImport(), $filePath);
    }
}
