<?php

namespace App\Policies;

use App\PolicyVehicle;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PolicyVehiclePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function view(User $user, PolicyVehicle $vehicle)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function update(User $user, PolicyVehicle $vehicle)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function delete(User $user, PolicyVehicle $vehicle)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function restore(User $user, PolicyVehicle $vehicle)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function forceDelete(User $user, PolicyVehicle $vehicle)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function import(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }
}
