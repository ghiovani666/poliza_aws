<?php

namespace App\Policies;

use App\PolicyInsured;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PolicyInsuredPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any policy insureds.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can view the policy insured.
     *
     * @param \App\User $user
     * @param \App\PolicyInsured $policyInsured
     * @return mixed
     */
    public function view(User $user, PolicyInsured $policyInsured)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can create policy insureds.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can update the policy insured.
     *
     * @param \App\User $user
     * @param \App\PolicyInsured $policyInsured
     * @return mixed
     */
    public function update(User $user, PolicyInsured $policyInsured)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can delete the policy insured.
     *
     * @param \App\User $user
     * @param \App\PolicyInsured $policyInsured
     * @return mixed
     */
    public function delete(User $user, PolicyInsured $policyInsured)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can restore the policy insured.
     *
     * @param \App\User $user
     * @param \App\PolicyInsured $policyInsured
     * @return mixed
     */
    public function restore(User $user, PolicyInsured $policyInsured)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can permanently delete the policy insured.
     *
     * @param \App\User $user
     * @param \App\PolicyInsured $policyInsured
     * @return mixed
     */
    public function forceDelete(User $user, PolicyInsured $policyInsured)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function import(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }
}
