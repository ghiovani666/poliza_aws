<?php

namespace App\Policies;

use App\Lead;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LeadPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any leads.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can view the lead.
     *
     * @param User $user
     * @param Lead $lead
     * @return mixed
     */
    public function view(User $user, Lead $lead)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can create leads.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can update the lead.
     *
     * @param User $user
     * @param Lead $lead
     * @return mixed
     */
    public function update(User $user, Lead $lead)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can delete the lead.
     *
     * @param User $user
     * @param Lead $lead
     * @return mixed
     */
    public function delete(User $user, Lead $lead)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can restore the lead.
     *
     * @param User $user
     * @param Lead $lead
     * @return mixed
     */
    public function restore(User $user, Lead $lead)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    /**
     * Determine whether the user can permanently delete the lead.
     *
     * @param User $user
     * @param Lead $lead
     * @return mixed
     */
    public function forceDelete(User $user, Lead $lead)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 13, 16, 14, 15, 17]);
    }

    public function dashboard(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 8, 10, 11, 12, 16, 14, 15]);
    }
}
