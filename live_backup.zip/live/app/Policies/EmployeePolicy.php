<?php

namespace App\Policies;

use App\Employee;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class EmployeePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any employees.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 8, 9, 11, 12]);
    }

    /**
     * Determine whether the user can view the employee.
     *
     * @param User $user
     * @param Employee $employee
     * @return mixed
     */
    public function view(User $user, Employee $employee)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 8, 9, 11, 12]);
    }

    /**
     * Determine whether the user can create employees.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 8, 9, 11, 12]);
    }

    /**
     * Determine whether the user can update the employee.
     *
     * @param User $user
     * @param Employee $employee
     * @return mixed
     */
    public function update(User $user, Employee $employee)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can delete the employee.
     *
     * @param User $user
     * @param Employee $employee
     * @return mixed
     */
    public function delete(User $user, Employee $employee)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can restore the employee.
     *
     * @param User $user
     * @param Employee $employee
     * @return mixed
     */
    public function restore(User $user, Employee $employee)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can permanently delete the employee.
     *
     * @param User $user
     * @param Employee $employee
     * @return mixed
     */
    public function forceDelete(User $user, Employee $employee)
    {
        return in_array($user->employee->type, [1, 2, 3, 6, 9, 11,]);
    }

    public function migrate(User $user, Employee $employee)
    {
        return !$employee->hasUser;
    }
}
