<?php

namespace App\Policies;

use App\Finance;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class FinancePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any finances.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the finance.
     *
     * @param User $user
     * @param Finance $finance
     * @return mixed
     */
    public function view(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create finances.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11, 12,]);
    }

    /**
     * Determine whether the user can update the finance.
     *
     * @param User $user
     * @param Finance $finance
     * @return mixed
     */
    public function update(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can delete the finance.
     *
     * @param User $user
     * @param Finance $finance
     * @return mixed
     */
    public function delete(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can restore the finance.
     *
     * @param User $user
     * @param Finance $finance
     * @return mixed
     */
    public function restore(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can permanently delete the finance.
     *
     * @param User $user
     * @param Finance $finance
     * @return mixed
     */
    public function forceDelete(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    public function disable(User $user, Finance $finance)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }
}
