<?php

namespace App\Policies;

use App\PolicyBeneficiary;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PolicyBeneficiaryPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any policy beneficiaries.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can view the policy beneficiary.
     *
     * @param \App\User $user
     * @param \App\PolicyBeneficiary $policyBeneficiary
     * @return mixed
     */
    public function view(User $user, PolicyBeneficiary $policyBeneficiary)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can create policy beneficiaries.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can update the policy beneficiary.
     *
     * @param \App\User $user
     * @param \App\PolicyBeneficiary $policyBeneficiary
     * @return mixed
     */
    public function update(User $user, PolicyBeneficiary $policyBeneficiary)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can delete the policy beneficiary.
     *
     * @param \App\User $user
     * @param \App\PolicyBeneficiary $policyBeneficiary
     * @return mixed
     */
    public function delete(User $user, PolicyBeneficiary $policyBeneficiary)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can restore the policy beneficiary.
     *
     * @param \App\User $user
     * @param \App\PolicyBeneficiary $policyBeneficiary
     * @return mixed
     */
    public function restore(User $user, PolicyBeneficiary $policyBeneficiary)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    /**
     * Determine whether the user can permanently delete the policy beneficiary.
     *
     * @param \App\User $user
     * @param \App\PolicyBeneficiary $policyBeneficiary
     * @return mixed
     */
    public function forceDelete(User $user, PolicyBeneficiary $policyBeneficiary)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }

    public function import(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15, 16, 17]);
    }
}
