<?php

namespace App\Policies;

use App\User;
use App\Ticket;
use Illuminate\Auth\Access\HandlesAuthorization;

class TicketPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any tickets.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the ticket.
     *
     * @param \App\User $user
     * @param \App\Ticket $ticket
     * @return mixed
     */
    public function view(User $user, Ticket $ticket)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create tickets.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can update the ticket.
     *
     * @param \App\User $user
     * @param \App\Ticket $ticket
     * @return mixed
     */
    public function update(User $user, Ticket $ticket)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can delete the ticket.
     *
     * @param \App\User $user
     * @param \App\Ticket $ticket
     * @return mixed
     */
    public function delete(User $user, Ticket $ticket)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 16, 14, 15]);
    }

    /**
     * Determine whether the user can restore the ticket.
     *
     * @param \App\User $user
     * @param \App\Ticket $ticket
     * @return mixed
     */
    public function restore(User $user, Ticket $ticket)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 16, 14, 15]);
    }

    /**
     * Determine whether the user can permanently delete the ticket.
     *
     * @param \App\User $user
     * @param \App\Ticket $ticket
     * @return mixed
     */
    public function forceDelete(User $user, Ticket $ticket)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 16, 14, 15]);
    }
}
