<?php

namespace App\Policies;

use App\PaymentDelayed;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PaymentDelayedPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any payment delayeds.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the payment delayed.
     *
     * @param \App\User $user
     * @param \App\PaymentDelayed $paymentDelayed
     * @return mixed
     */
    public function view(User $user, PaymentDelayed $paymentDelayed)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create payment delayeds.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15]);
    }

    /**
     * Determine whether the user can update the payment delayed.
     *
     * @param \App\User $user
     * @param \App\PaymentDelayed $paymentDelayed
     * @return mixed
     */
    public function update(User $user, PaymentDelayed $paymentDelayed)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15]);
    }

    /**
     * Determine whether the user can delete the payment delayed.
     *
     * @param \App\User $user
     * @param \App\PaymentDelayed $paymentDelayed
     * @return mixed
     */
    public function delete(User $user, PaymentDelayed $paymentDelayed)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15]);
    }

    /**
     * Determine whether the user can restore the payment delayed.
     *
     * @param \App\User $user
     * @param \App\PaymentDelayed $paymentDelayed
     * @return mixed
     */
    public function restore(User $user, PaymentDelayed $paymentDelayed)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15]);
    }

    /**
     * Determine whether the user can permanently delete the payment delayed.
     *
     * @param \App\User $user
     * @param \App\PaymentDelayed $paymentDelayed
     * @return mixed
     */
    public function forceDelete(User $user, PaymentDelayed $paymentDelayed)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15]);
    }

    public function import(User $user)
    {
        return in_array($user->employee->type, [4]);
    }
}
