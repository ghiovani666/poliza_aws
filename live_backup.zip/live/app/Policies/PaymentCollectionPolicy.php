<?php

namespace App\Policies;

use App\PaymentCollection;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PaymentCollectionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any payment collections.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the payment collection.
     *
     * @param \App\User $user
     * @param \App\PaymentCollection $paymentCollection
     * @return mixed
     */
    public function view(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create payment collections.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11, 12,]);
    }

    /**
     * Determine whether the user can update the payment collection.
     *
     * @param \App\User $user
     * @param \App\PaymentCollection $paymentCollection
     * @return mixed
     */
    public function update(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can delete the payment collection.
     *
     * @param \App\User $user
     * @param \App\PaymentCollection $paymentCollection
     * @return mixed
     */
    public function delete(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can restore the payment collection.
     *
     * @param \App\User $user
     * @param \App\PaymentCollection $paymentCollection
     * @return mixed
     */
    public function restore(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can permanently delete the payment collection.
     *
     * @param \App\User $user
     * @param \App\PaymentCollection $paymentCollection
     * @return mixed
     */
    public function forceDelete(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    public function disable(User $user, PaymentCollection $paymentCollection)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }
}
