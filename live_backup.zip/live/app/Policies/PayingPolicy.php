<?php

namespace App\Policies;

use App\User;
use App\Paying;
use Illuminate\Auth\Access\HandlesAuthorization;

class PayingPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any payings.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can view the paying.
     *
     * @param \App\User $user
     * @param \App\Paying $paying
     * @return mixed
     */
    public function view(User $user, Paying $paying)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can create payings.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can update the paying.
     *
     * @param \App\User $user
     * @param \App\Paying $paying
     * @return mixed
     */
    public function update(User $user, Paying $paying)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can delete the paying.
     *
     * @param \App\User $user
     * @param \App\Paying $paying
     * @return mixed
     */
    public function delete(User $user, Paying $paying)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can restore the paying.
     *
     * @param \App\User $user
     * @param \App\Paying $paying
     * @return mixed
     */
    public function restore(User $user, Paying $paying)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    /**
     * Determine whether the user can permanently delete the paying.
     *
     * @param \App\User $user
     * @param \App\Paying $paying
     * @return mixed
     */
    public function forceDelete(User $user, Paying $paying)
    {
        return in_array($user->employee->type, [1, 3]);
    }

    public function report(User $user)
    {
        return in_array($user->employee->type, [1, 3, 13]);
    }
}
