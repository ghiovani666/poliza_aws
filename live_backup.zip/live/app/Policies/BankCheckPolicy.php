<?php

namespace App\Policies;

use App\BankCheck;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class BankCheckPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any bank checks.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the bank check.
     *
     * @param User $user
     * @param BankCheck $bankCheck
     * @return mixed
     */
    public function view(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create bank checks.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11, 12,]);
    }

    /**
     * Determine whether the user can update the bank check.
     *
     * @param User $user
     * @param BankCheck $bankCheck
     * @return mixed
     */
    public function update(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can delete the bank check.
     *
     * @param User $user
     * @param BankCheck $bankCheck
     * @return mixed
     */
    public function delete(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can restore the bank check.
     *
     * @param User $user
     * @param BankCheck $bankCheck
     * @return mixed
     */
    public function restore(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can permanently delete the bank check.
     *
     * @param User $user
     * @param BankCheck $bankCheck
     * @return mixed
     */
    public function forceDelete(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    public function disable(User $user, BankCheck $bankCheck)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }
}
