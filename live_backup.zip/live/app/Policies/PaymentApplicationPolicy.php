<?php

namespace App\Policies;

use App\PaymentApplication;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PaymentApplicationPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any payment applications.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can view the payment application.
     *
     * @param User $user
     * @param PaymentApplication $paymentApplication
     * @return mixed
     */
    public function view(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 14, 15]);
    }

    /**
     * Determine whether the user can create payment applications.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11, 12,]);
    }

    /**
     * Determine whether the user can update the payment application.
     *
     * @param User $user
     * @param PaymentApplication $paymentApplication
     * @return mixed
     */
    public function update(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can delete the payment application.
     *
     * @param User $user
     * @param PaymentApplication $paymentApplication
     * @return mixed
     */
    public function delete(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can restore the payment application.
     *
     * @param User $user
     * @param PaymentApplication $paymentApplication
     * @return mixed
     */
    public function restore(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    /**
     * Determine whether the user can permanently delete the payment application.
     *
     * @param User $user
     * @param PaymentApplication $paymentApplication
     * @return mixed
     */
    public function forceDelete(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }

    public function disable(User $user, PaymentApplication $paymentApplication)
    {
        return in_array($user->employee->type, [1, 2, 3, 4, 5, 6, 9, 11,]);
    }
}
