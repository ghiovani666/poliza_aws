<?php

namespace App\Charts;

use App\Employee;
use App\EmployeeType;
use App\Enums\SellType;
use App\Policy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TableTop
{
    const TYPE_COUNTER = 1;
    const TYPE_PRIME = 2;
    const MODE_VALIDITY = 'validity_date';
    const MODE_REQUEST = 'requested_date';
    const MODE_DELIVERY = 'delivery_date';

    /**
     * @var Request
     */
    private $request;
    /**
     * @var int
     */
    private $counterType;

    public function __construct(Request $request, $counterType)
    {
        $this->request = $request;
        $this->counterType = $counterType;
    }

    public function run()
    {
        $supervisors = $this->getSupervisors();
        $data = [];

        foreach ($supervisors as $supervisor) {
            $employees = $this->getTopEmployeesBySupervisor($supervisor);
            $topData = [];

            foreach ($employees as $employee) {
                $months = [];
                for ($month = 1; $month <= 12; $month++) {
                    $months['month' . $month] = $this->getEmployeeTotalByMonth($employee, $month);
                }
                $topData[] = array_merge([
                    'assessor_id' => $employee->assessor_id,
                    'name' => $employee->name,
                    'total' => $employee->total,
                ], $months);
            }
            $data[] = [
                'supervisor' => $supervisor->name,
                'top' => $topData
            ];
        }

        return $data;
    }

    /**
     * @return Builder[]|Collection
     */
    private function getSupervisors()
    {
        return Employee::query()
            ->select('id', 'name', 'supervise')
            ->where('type', EmployeeType::SELL_SUPERVISOR)
            ->get();
    }

    private function getTopEmployeesBySupervisor(Employee $supervisor)
    {
        $employees = is_array($supervisor->supervise) ? $supervisor->supervise : [];
        $query = $this->baseQuery()
            ->select('assessor_id', 'employees.name');

        if ($this->counterType == self::TYPE_COUNTER) {
            $query->addSelect(DB::raw('count(*) as total'));
        }

        if ($this->counterType == self::TYPE_PRIME) {
            $query->addSelect(DB::raw('SUM(prime) as total'));
        }

        return $query->whereIn('assessor_id', $employees)
            ->orderByDesc(DB::raw('total'))
            ->groupBy('assessor_id')
            ->take(10)
            ->get();
    }

    public function baseQuery()
    {
        return Policy::query()
            ->leftJoin('employees', 'employees.id', 'policies.assessor_id')
            ->select('assessor_id', 'employees.name')
            ->when($this->request->filled('employee_type'), function ($query) {
                $roles = EmployeeType::find($this->request->employee_type)->hierarchy();
                $query->whereIn('employees.type', $roles);
            })
            ->when($this->request->filled('employee_id'), function ($query) {
                $employees = [];
                foreach ($this->request->employee_id as $id) {
                    $employees = array_merge($employees, Employee::find($id)->hierarchy());
                }
                $query->whereIn('employees.id', $employees);
            })
            ->when($this->request->filled('year') && !$this->request->filled('sell_type'), function ($query) {
                $query->whereYear('validity_date', $this->request->year);
            })
            ->when($this->request->filled('year') && $this->request->filled('sell_type'), function ($query) {
                $query->whereYear($this->getDateFieldBySellType($this->request->sell_type), $this->request->year);
            })
            ->when($this->request->filled('month') && !$this->request->filled('sell_type'), function ($query) {
                $query->whereMonth('validity_date', $this->request->month);
            })
            ->when($this->request->filled('month') && $this->request->filled('sell_type'), function ($query) {
                $query->whereMonth($this->getDateFieldBySellType($this->request->sell_type), $this->request->month);
            })
            ->currency($this->request)
            ->company($this->request->get('company_id'), $this->request->filled('company_id'))
            ->sectorName($this->request->get('sector'), $this->request->filled('sector'))
            ->sellType($this->request->get('sell_type'), $this->request->filled('sell_type'))
            ->assessor($this->request->get('assessor_id'), $this->request->filled('assessor_id'));
    }

    /**
     * @param int $status
     * @return string|null
     */
    private function getDateFieldBySellType(int $status): ?string
    {
        switch ($status) {
            case SellType::NEW_SALE:
            case SellType::RENEWAL:
            case SellType::ENDORSEMENT:
                return self::MODE_VALIDITY;
            case SellType::AGENCY:
                return self::MODE_REQUEST;
        }
    }

    private function getEmployeeTotalByMonth($employee, int $month)
    {
        $total = 0;
        $this->request->merge(['month' => $month]);

        $query = $this->baseQuery()
            ->where('assessor_id', $employee->assessor_id);

        if ($this->counterType == self::TYPE_COUNTER) {
            $total = $query->count();
        }

        if ($this->counterType == self::TYPE_PRIME) {
            $total = $query->sum('prime');
        }

        $this->request->merge(['month' => null]);

        return $total;
    }
}
