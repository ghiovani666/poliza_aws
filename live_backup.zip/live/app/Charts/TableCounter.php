<?php

namespace App\Charts;

use App\Policy;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class TableCounter
{
    const TYPE_COUNTER = 1;
    const TYPE_PRIME = 2;
    const MODE_VALIDITY = 'validity_date';
    const MODE_REQUEST = 'requested_date';
    const MODE_DELIVERY = 'delivery_date';

    /**
     * @var Request
     */
    private $request;
    /**
     * @var Builder
     */
    private $builder;
    /**
     * @var int|mixed
     */
    private $counterType;
    /**
     * @var int
     */
    private $year;
    /**
     * @var int
     */
    private $month;
    /**
     * @var string
     */
    private $dateMode;

    public function __construct(Request $request, $counterType = self::TYPE_COUNTER, $dateMode = null)
    {
        $this->request = $request;
        $this->counterType = $counterType;
        $this->dateMode = $dateMode;
        $this->builder = Policy::query()
            ->where('active', 1)
            ->operationStatus($request)
            ->currency($request)
            ->company($request->get('company_id'), $request->filled('company_id'))
            ->sectorName($request->get('sector'), $request->filled('sector'))
            ->sellType($request->get('sell_type'), $request->filled('sell_type'))
            ->assessor($request->get('assessor_id'), $request->filled('assessor_id'));
    }

    /**
     * @param int $year
     * @return TableCounter
     */
    public function setYear(int $year): TableCounter
    {
        $this->year = $year;
        $this->builder->whereYear($this->dateMode, $year);

        return $this;
    }

    /**
     * @param int $month
     * @return TableCounter
     */
    public function setMonth(int $month): TableCounter
    {
        $this->month = $month;
        $this->builder->whereMonth($this->dateMode, $this->month);

        return $this;
    }

    /**
     * @throws Exception
     */
    public function run()
    {
        if ($this->counterType === self::TYPE_PRIME) {
            return $this->builder->sum('prime');
        }

        if ($this->counterType === self::TYPE_COUNTER) {
            return $this->builder->count();
        }

        throw new Exception('Invalid counter type.');
    }
}
