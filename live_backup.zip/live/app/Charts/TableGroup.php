<?php

namespace App\Charts;

use Illuminate\Database\Eloquent\Model;

class TableGroup extends Model
{
    //
}
