<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentAction extends Model
{
    protected $appends = ['available'];

    public function getAvailableAttribute()
    {
        if (request()->filled('lead_id')) {
            /** @var $lead Lead */
            $lead = Lead::find(request()->get('lead_id'));

            if ($this->id == 4) {
                $meeting = $lead->comments()->where('actions', 'like', '%4%')->get();
                return $meeting->count() == 0;
            }
            if ($this->id == 5) {
                $meeting1 = $lead->comments()->where('actions', 'like', '%4%')->get();
                $meeting2 = $lead->comments()->where('actions', 'like', '%5%')->get();
                return $meeting1->count() > 0 && $meeting2->count() == 0;
            }
            if ($this->id == 6) {
                $meeting1 = $lead->comments()->where('actions', 'like', '%5%')->get();
                $meeting2 = $lead->comments()->where('actions', 'like', '%6%')->get();
                return $meeting1->count() > 0 && $meeting2->count() == 0;
            }
        }
        return true;
    }
}
