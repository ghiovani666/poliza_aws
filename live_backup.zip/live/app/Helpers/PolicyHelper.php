<?php

namespace App\Helpers;

use App\Policy;

class PolicyHelper
{
    /**
     * @var array
     */
    protected $sellTypes = [
        1 => 'Venta Nueva',
        2 => 'Agenciamiento',
        3 => 'Renovación',
        4 => 'Endoso',
    ];
    /**
     * @var array
     */
    protected $status = [
        1 => 'En emisión',
        2 => 'Emitido',
        3 => 'En Agenciamiento',
        4 => 'Agenciado',
        5 => 'En renovación',
        6 => 'Renovado',
        7 => 'Perdido',
        8 => 'Anulado',
    ];
    /**
     * @var array
     */
    protected $paymentMethods = [
        1 => 'CC (cargo en cuenta)',
        2 => 'CP (cupón)',
        3 => 'Contado',
    ];
    /**
     * @var array
     */
    protected $periods = [
        1 => 'Mensual',
        2 => 'Bimestral',
        3 => 'Trimestral',
        6 => 'Semestral',
        12 => 'Anual',
    ];
    /**
     * @var Policy
     */
    protected $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    public function sellType()
    {
        return $this->sellTypes[$this->policy->sell_type];
    }

    public function status()
    {
        return $this->status[$this->policy->operation_status];
    }

    public function paymentType()
    {
        return $this->status[$this->policy->payment_type];
    }

    public function period()
    {
        return $this->status[$this->policy->period];
    }
}
