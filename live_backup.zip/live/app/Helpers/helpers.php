<?php

use App\Bank;
use App\Broker;
use App\CommentAction;
use App\Company;
use App\Customer;
use App\Document;
use App\Employee;
use App\EmployeeType;
use App\Enums\CurrencyType;
use App\Enums\DocumentType;
use App\Enums\FinanceStatuses;
use App\Enums\PaymentType;
use App\Enums\PeriodType;
use App\Enums\SellType;
use App\Policy;
use App\PolicyDocumentType;
use App\PolicyStatus;
use App\Product;
use App\Sector;
use App\Survey;
use App\VehicleType;
use Illuminate\Support\Facades\Auth;

if (!function_exists('dropdownData')) {
    function dropdownData($key, $model = null)
    {
        $employee = Auth::user()->employee;
        $data = [];
        switch ($key) {
            case 'Brokers':
                $data = Broker::query()->orderBy('name')->pluck('name', 'id');
                break;
            case 'Banks':
                $data = Bank::query()->orderBy('name')->pluck('name', 'id')->toArray();
                break;
            case 'Companies':
                $data = Company::query()->orderBy('name')->pluck('name', 'id')->toArray();
                break;
            case 'Customers':
                $data = Customer::query()
                    ->when(Auth::user()->isAssessor, function ($query) {
                        $query->whereHas('policies', function ($query) {
                            $query->where('assessor_id', Auth::user()->employee->id);
                        });
                    })
                    ->orderBy('name')
                    ->pluck('name', 'id')->toArray();
                break;
            case 'Currency':
                $data = CurrencyType::toArray();
                break;
            case 'DocumentTypes':
                $data = DocumentType::toSelectArray();
                break;
            case 'Dues':
                for ($i = 1; $i <= 12; $i++) {
                    $data[$i] = $i;
                }
                break;
            case 'Employees':
                $data = Employee::query()
                    ->when($employee->isSupervisor, function ($query) use ($employee) {
                        if (is_null($employee->supervise)) {
                            $employee->supervise = [];
                        }
                        $query->whereIn('id', $employee->supervise)
                            ->orWhere('id', $employee->id);
                    })
                    ->orderBy('name')
                    ->pluck('name', 'id');
                break;
            case 'EmployeeType':
                $data = EmployeeType::query()
                    ->orderBy('name')
                    ->pluck('name', 'id');
                break;
            case 'FinanceStatuses':
                $data = FinanceStatuses::toSelectArray();
                break;
            case 'PaymentCollectionStatuses':
                $data = [1 => 'Ok', 2 => 'En proceso', 3 => 'Cerrado'];
                break;
            case 'PaymentType':
                $data = PaymentType::toSelectArray();
                break;
            case 'Policies':
                $data = Policy::query()
                    ->when(is_object($model) && $model->customer_id > 0, function ($query) use ($model) {
                        $query->where('customer_id', $model->customer_id);
                    })
                    ->orderByDesc('id')
                    ->pluck('code', 'id')
                    ->toArray();
                break;
            case 'PeriodTypes':
                $data = PeriodType::toSelectArray();
                break;
            case 'PolicyStatuses':
                $data = PolicyStatus::query()->pluck('name', 'id')->toArray();
                break;
            case 'VehicleTypes':
                $data = VehicleType::query()->orderBy('name')->pluck('name', 'id')->toArray();
                break;
            case 'PolicyDocumentTypes':
                $data = PolicyDocumentType::query()->orderBy('name')->pluck('name', 'id')->toArray();
                break;
            case 'YesNot':
                $data = ['' => '- Seleccionar -', 1 => 'Si', 0 => 'No'];
                break;
            case 'Sectors':
                if (is_null($model) || !is_integer($model->company_id)) {
                    return [];
                }

                $data = Sector::query()
                    ->where('company_id', $model->company_id)
                    ->orderBy('name')
                    ->pluck('name', 'id')
                    ->toArray();
                break;
            case 'SellTypes':
                $data = SellType::toSelectArray();
                break;
            case 'Products':
                if (is_null($model) || !is_integer($model->sector_id)) {
                    return [];
                }

                $data = Product::query()
                    ->where('sector_id', $model->sector_id)
                    ->orderBy('name')
                    ->pluck('name', 'id')
                    ->toArray();
                break;
        }

        return $data;
    }
}

if (!function_exists('activeUrl')) {
    function activeUrl($data)
    {
        return request()->is($data) ? 'active' : null;
    }
}

if (!function_exists('documents')) {
    function documents()
    {
        return Document::query()->where('enabled', 1)->orderBy('name')->get();
    }
}

if (!function_exists('surveys')) {
    function surveys()
    {
        return Survey::query()->orderBy('id')->get();
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin()
    {
        return Auth::check() && Auth::user()->isAdmin;
    }
}

if (!function_exists('employees')) {
    function employees($types = null, $chunk = 0)
    {
        $data = Employee::query()
            ->when(is_array($types), function ($query) use ($types) {
                $query->whereIn('type', $types);
            })
            ->orderBy('name');

        return $chunk > 0 ? $data->get()->chunk(2) : $data->get();
    }
}

if (!function_exists('commentActionsToSelectArray')) {
    function commentActionsToSelectArray()
    {
        return CommentAction::query()->pluck('name', 'id')->toArray();
    }
}
