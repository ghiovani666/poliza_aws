<?php


namespace App\Helpers;

use App\Enums\PaymentType;

trait PolicyPresenter
{
    public function getValidityEndDateAttribute()
    {
        return $this->validityEnd->format('d/m/Y');
    }

    public function getPaymentMethodAttribute()
    {
        return PaymentType::getDescription($this->payment_type);
    }

    public function getRenewalAnswerAttribute()
    {
        if ($this->wish_renewal === 1) {
            return 'Si';
        } elseif ($this->wish_renewal === 0) {
            return 'No';
        } elseif ($this->wish_renewal === 2) {
            return 'No contactado';
        } elseif ($this->wish_renewal === null) {
            return 'Pendiente de gestión';
        } else {
            return '';
        }
    }

    public function getLoyaltyAnswerAttribute()
    {
        return $this->is_service_ok ? 'Si' : 'No';
    }

    public function getSurveyAnswerAttribute()
    {
        return $this->survey_answered ? 'Si' : 'No';
    }

    public function getHasPolicyFileAttribute()
    {
        return $this->documents()->where('type', '5')->exists();
    }

    public function getPolicyFileUrlAttribute()
    {
        return $this->policyFile->url;
    }

    public function getPolicyFileAttribute()
    {
        return $this->documents()->where('type', '5')->first();
    }

    public function getActiveNameAttribute()
    {
        return $this->active ? 'Vigente' : 'No Vigente';
    }

    public function getInspectionAnswerAttribute()
    {
        return $this->getYesNotAnswer($this->inspection);
    }

    private function getYesNotAnswer($value)
    {
        // prevent loose comparison
        switch ($value) {
            case '0':
                $value = 'No';
                break;
            case '1':
                $value = 'Si';
                break;
            default:
                $value = '';
                break;
        }

        return $value;
    }

    public function getAbidanceAnswerAttribute()
    {
        return $this->getYesNotAnswer($this->abidance);
    }
}
