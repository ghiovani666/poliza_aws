<?php

namespace App;

use Collective\Html\Eloquent\FormAccessible;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use FormAccessible;

    protected $guarded = [];

    public function sector()
    {
        return $this->belongsTo(Sector::class);
    }

    public function formCompanyIdAttribute()
    {
        if (is_null($this->sector_id)) {
            return null;
        }

        return $this->sector->company_id;
    }

    public function policies()
    {
        return $this->hasMany(Policy::class);
    }
}
