<?php

namespace App;

use App\Helpers\PolicyPresenter;
use App\Traits\DateTimeHelper;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

/**
 * @property Carbon validity_date
 * @property int period
 * @property bool active
 * @property int sell_type
 * @property int operation_status
 * @property int renew_id
 * @property int renew_count
 * @property Carbon requested_date
 * @property Carbon renewal_date
 */
class Policy extends Model
{
    use  SoftDeletes, DateTimeHelper, PolicyPresenter;

    /**
     * @var array
     */
    protected $guarded = [];

    /**
     * @param Employee $employee
     * @param Request $request
     * @return Builder
     */
    public static function fetchAll(Employee $employee, Request $request)
    {
        return Policy::query()
            ->with(['status', 'customer', 'assessor', 'company'])
            ->leftJoin('customers', 'customers.id', '=', 'policies.customer_id')
            ->select('policies.*', 'customers.name', 'customers.document_number')
            ->when($request->filled('customer'), function (Builder $query) use ($request) {
                $query->where('customers.name', 'like', "%{$request->customer}%");
            })
            ->when($request->filled('document'), function (Builder $query) use ($request) {
                $query->where('customers.document_number', 'like', "%{$request->document}%");
            })
            ->when($request->filled('code'), function ($query) use ($request) {
                $query->where('policies.code', 'like', "%{$request->code}%");
            })
            ->when($request->filled('active'), function ($query) use ($request) {
                $query->where('active', (int)$request->active);
            })
            ->when($request->filled('status_id'), function ($query) use ($request) {
                $query->where('operation_status', (int)$request->status_id);
            })
            ->when($request->filled('request_date'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('request_date'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0]);
                $to = Carbon::createFromFormat('d/m/Y', $range[1]);

                $query->whereBetween('requested_date', [$from, $to]);
            })
            ->when($request->filled('delivery_date'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('delivery_date'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0]);
                $to = Carbon::createFromFormat('d/m/Y', $range[1]);

                $query->whereBetween('delivery_date', [$from, $to]);
            })
            ->when($request->filled('validity_date'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('validity_date'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0])->toDateString();
                $to = Carbon::createFromFormat('d/m/Y', $range[1])->toDateString();

                $query->whereBetween('validity_date', [$from, $to]);
            })
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->assessor_id);
            })
            ->when($employee->job->visibility == 2, function ($query) use ($employee) {
                if (is_null($employee->supervise)) {
                    $employee->supervise = [];
                }
                $query->where(function ($query) use ($employee) {
                    $query->whereIn('assessor_id', $employee->supervise)
                        ->orWhere('assessor_id', $employee->id);
                });
            })
            ->when($employee->job->visibility == 3, function ($query) use ($employee) {
                $query->where('assessor_id', $employee->id);
            });
    }

    /**
     * @param int $year
     * @param int $month
     * @param string $currency
     * @return Builder
     */
    public static function fetchStock($year = 2020, $month = 1, $currency = 'USD')
    {
        return Policy::query()
            ->whereYear('validity_date', $year)
            ->whereMonth('validity_date', $month)
            ->where('currency', $currency)
            ->whereIn('operation_Status', [2, 6]);
    }

    public static function fetchYear($year = 2020, $month = 1)
    {
        return Policy::query()
            ->where('active', 1)
            ->whereYear('validity_date', $year)
            ->whereMonth('validity_date', $month);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault();
    }

    public function assessor()
    {
        return $this->belongsTo(Employee::class)->withDefault();
    }

    public function broker()
    {
        return $this->belongsTo(Broker::class)->withDefault();
    }

    public function key()
    {
        return $this->belongsTo(Key::class);
    }

    public function beneficiaries()
    {
        return $this->hasMany(PolicyBeneficiary::class);
    }

    public function insureds()
    {
        return $this->hasMany(PolicyInsured::class);
    }

    public function vehicles()
    {
        return $this->hasMany(PolicyVehicle::class);
    }

    public function documents()
    {
        return $this->hasMany(PolicyDocument::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'Desconocido']);
    }

    public function sector()
    {
        return $this->belongsTo(Sector::class)->withDefault(['name' => 'Desconocido']);
    }

    public function product()
    {
        return $this->belongsTo(Product::class)->withDefault(['name' => 'Desconocido']);
    }

    public function status()
    {
        return $this->belongsTo(PolicyStatus::class, 'operation_status')->withDefault(['name' => 'Desconocido']);
    }

    public function getValidityEndAttribute()
    {
        $date = Carbon::parse($this->validity_date);
        return $date->addMonths($this->period);
    }

    public function surveys()
    {
        return $this->belongsToMany(Survey::class)->withPivot('answer');
    }

    public function payments()
    {
        return $this->hasMany(PaymentDelayed::class);
    }

    /**
     * @return Policy
     */
    public function createPreRenewal()
    {
        $clone = $this->replicate();
        $clone->active = 0;
        $clone->sell_type = 3;
        $clone->operation_status = 5;

        return $clone;
    }

    /**
     * @param Builder $query
     * @param int $id
     * @param bool $apply
     * @return Builder
     */
    public function scopeCompany($query, $id, $apply = true)
    {
        return $query->when($apply, function ($query) use ($id) {
            $query->where('policies.company_id', $id);
        });
    }

    public function scopeCurrency(Builder $query, Request $request, $field = 'currency')
    {
        return $query->when($request->filled($field), function ($query) use ($request, $field) {
            $query->where('policies.currency', $request->get($field));
        });
    }

    /**
     * @param Builder $query
     * @param string $name
     * @param bool $apply
     * @return Builder
     */
    public function scopeSectorName($query, $name, $apply = true)
    {
        return $query->when($apply, function ($query) use ($name) {
            $sectors = Sector::query()->where('name', 'like', $name)->pluck('id');
            $query->whereIn('sector_id', $sectors);
        });
    }

    /**
     * @param Builder $query
     * @param int $id
     * @param bool $apply
     * @return Builder
     */
    public function scopeSellType($query, $id, $apply = true)
    {
        return $query->when($apply, function ($query) use ($id) {
            $query->where('sell_type', $id);
        });
    }

    /**
     * @param Builder $query
     * @param int $id
     * @param bool $apply
     * @return Builder
     */
    public function scopeAssessor($query, $id, $apply = true)
    {
        return $query->when($apply, function ($query) use ($id) {
            $query->where('assessor_id', $id);
        });
    }

    /**
     * @param Builder $query
     * @param int $year
     * @param bool $apply
     * @return Builder
     */
    public function scopeYear($query, $year, $apply = true)
    {
        return $query->when($apply, function ($query) use ($year) {
            $query->whereYear('validity_date', $year);
        });
    }

    public function setRenewal()
    {
        //$this->active = 0; // removed
        $this->sell_type = 3; // renovacion
        $this->operation_status = 5; // renovado

        return $this;
    }

    public function scopeRenewals($query)
    {
        return $query->where('sell_type', 3)
            ->where('operation_status', 5)
            ->where('period', '<>', 99);
    }

    public function scopeOperationStatus(Builder $query, Request $request, $field = 'operation_status')
    {
        return $query->when($request->filled($field), function ($query) use ($request, $field) {
            $query->where('operation_status', $request->get($field));
        });
    }
}
