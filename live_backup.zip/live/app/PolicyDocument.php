<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PolicyDocument extends Model
{
    protected $guarded = [];
}
