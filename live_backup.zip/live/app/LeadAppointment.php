<?php

namespace App;

use App\Traits\DateTimeHelper;
use Carbon\Carbon;
use Illuminate\Database\Concerns\BuildsQueries;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class LeadAppointment extends Model
{
    use DateTimeHelper;

    protected $appends = ['createdTimeAgo', 'numberName', 'statusName'];
    protected $guarded = [];
    protected $dates = ['date'];
    private $statuses = [
        1 => 'Agendado',
        2 => 'Efectivo',
        3 => 'No Efectivo',
        4 => 'Reprogramada',
    ];

    public static function countByDay($day, Employee $employee, Request $request, $number = null)
    {
        $date = $day->toDateString();

        if (!is_null($number)) {
            $request->merge(['number' => $number]);
        }

        //dd(self::countByQuery($date, $employee, $request)->getBindings());
        return self::countByQuery($date, $employee, $request)->count();
    }

    /**
     * @param string|array $date
     * @param Employee $employee
     * @param Request $request
     * @return BuildsQueries|Builder|mixed
     */
    public static function countByQuery($date, Employee $employee, Request $request)
    {
        return self::query()
            ->where('user_id', $employee->user_id)
            ->when($request->get('type', 0) == 0 && is_string($date), function ($query) use ($date) {
                $query->whereDate('date', $date);
            })
            ->when($request->get('type', 0) == 0 && is_array($date), function ($query) use ($date) {
                $query->whereBetween('date', [$date['from'], $date['to']]);
            })
            ->when($request->filled('number'), function ($query) use ($request) {
                $query->where('number', $request->number);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->status);
            })
            ->when($request->get('type') == 1, function ($query) use ($date) {
                $query->whereHas('lead', function (Builder $query) use ($date) {
                    $query->when(is_string($date), function ($query) use ($date) {
                        $query->whereDate('win_date', $date);
                    });
                    $query->when(is_array($date), function ($query) use ($date) {
                        $query->whereBetween('win_date', [$date['from'], $date['to']]);
                    });
                    $query->where(function ($query) {
                        $query->where('stage_id', 5)
                            ->orWhere('process_id', 3);
                    });
                });
            });
    }

    public static function countByWeek($year, $week, Employee $employee, Request $request, $number = null)
    {
        $firstDayOfWeek = Carbon::now()->setISODate($year, $week)->startOfWeek();
        $lastDateOfWeek = Carbon::now()->setISODate($year, $week)->endOfWeek();
        $date = ['from' => $firstDayOfWeek, 'to' => $lastDateOfWeek];

        if (!is_null($number)) {
            $request->merge(['number' => $number]);
        }

        return self::countByQuery($date, $employee, $request)->count();
    }

    public static function countByMonth($year, $month, Employee $employee, Request $request, $number = null)
    {
        $firstDayOfMonth = Carbon::create($year, $month)->startOfMonth();
        $lastDateOfMonth = Carbon::create($year, $month)->endOfMonth();
        $date = ['from' => $firstDayOfMonth, 'to' => $lastDateOfMonth];

        if (!is_null($number)) {
            $request->merge(['number' => $number]);
        }

        return self::countByQuery($date, $employee, $request)->count();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getNumberNameAttribute()
    {
        $name = 'Cita';
        switch ($this->number) {
            case 1:
                $name = 'Primera Cita';
                break;
            case 2:
                $name = 'Segunda Cita';
                break;
            case 3:
                $name = 'Tercera Cita';
                break;
        }
        return $name;
    }

    public function getStatusNameAttribute()
    {
        return $this->statuses[$this->status];
    }

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }

    //-Verde (efectivas) 2
    //-Rojas (no efectivas) 3
    //-Azul ( todas las demás ) 1 4
    public function getCalendarBackgroundColor()
    {
        // green
        if ($this->status == 2) {
            return '#d4edda'; // #c3e6cb
        }

        // red
        if ($this->status == 3) {
            return '#f8d7da'; // #f5c6cb
        }

        // default blue
        return '#cce5ff'; // #b8daff
    }

    public function getCalendarBorderColor()
    {
        // green
        if ($this->status == 2) {
            return '#c3e6cb'; // #c3e6cb
        }

        // red
        if ($this->status == 3) {
            return '#f5c6cb'; // #f5c6cb
        }

        // default blue
        return '#b8daff'; // #b8daff
    }

    public function getCalendarTextColor()
    {
        // green
        if ($this->status == 2) {
            return '#155724'; // #c3e6cb
        }

        // red
        if ($this->status == 3) {
            return '#721c24'; // #f5c6cb
        }

        // default blue
        return '#004085'; // #b8daff
    }
}
