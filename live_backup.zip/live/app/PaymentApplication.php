<?php

namespace App;

use App\Traits\DateTimeHelper;
use Illuminate\Database\Eloquent\Model;

class PaymentApplication extends Model
{
    use DateTimeHelper;

    protected $guarded = [];

    public function assessor()
    {
        return $this->belongsTo(Employee::class)->withDefault(['name' => 'No selecionado']);
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class)->withDefault(['name' => 'No selecionado']);
    }

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'No selecionado']);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault(['name' => 'No selecionado']);
    }

    public function policy()
    {
        return $this->belongsTo(Policy::class)->withDefault(['code' => 'No selecionado']);
    }

    public function user()
    {
        return $this->belongsTo(User::class)->withDefault();
    }

    public function getStatusNameAttribute()
    {
        if (is_null($this->status)) {
            return 'No asignado';
        }

        $data = dropdownData('PaymentCollectionStatuses');
        return $data[$this->status];
    }
}
