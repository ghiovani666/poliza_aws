<?php

namespace App\Imports;

use App\Employee;
use App\Lead;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class LeadsImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        return new Lead([
            'name' => $row['nombre'],
            'phone' => $row['telefono'],
            'email' => $row['email'],
            'source_id' => $this->getSourceId($row['origen']),
            'stage_id' => $this->getStage($row['etapa']),
            'process_id' => $this->getProcess($row['proceso']),
            'amount' => $row['importe'],
            'currency' => $this->getCurrency($row['moneda']),
            'assessor_id' => $this->getAssessorId($row['asesor']),
            'supervisor_id' => $this->getSupervisor($row['asesor']),
            'created_at' => $this->parseExcelDate($row['fecha_de_creacion']),
            'close_date' => $this->parseExcelDate($row['fecha_de_cierre_estimato']),
        ]);

    }

    private function getSourceId($source)
    {
        if ($source == 'Referido') return 1;

        dd($source);
    }

    private function getStage($stage)
    {
        if ($stage == 'Por Contactar (20%)') return 1;
        if ($stage == 'Contactado (40%)') return 2;
        if ($stage == 'Propuesta enviada (60%)') return 3;
        if ($stage == 'Negociación (80%)') return 4;

        dd($stage);
    }

    private function getProcess($proceso)
    {
        if ($proceso == 'Pendiente') return 1;
        if ($proceso == 'Stand By') return 2;
        if ($proceso == 'Ganado') return 3;
        if ($proceso == 'Perdido') return 4;
        if ($proceso == 'Cancelado') return 5;

        dd($proceso);
    }

    private function getCurrency($currency)
    {
        if ($currency == 'Dolares (USD)') return 'USD';
        if ($currency == 'Soles (PEN)') return 'PEN';

        dd($currency);
    }

    private function getAssessorId($name)
    {
        if ($name = 'KATY BLAS') return 9;

        $employee = Employee::query()->where('name', $name)->first();

        if (is_null($employee)) dd($name);

        return $employee->id;
    }

    private function getSupervisor($name)
    {
        return Employee::find($this->getAssessorId($name))->getSupervisor();
    }

    private function parseExcelDate($date)
    {
        $date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($date);
        return Carbon::parse($date);
    }

    private function getStageId($step_id)
    {
        switch ($step_id) {
            case 334216:
                return 1;
            case 334217:
                return 2;
            case 334218:
                return 3;
            case 334219:
                return 4;
        }
    }

    private function getProcessId($status)
    {
        switch ($status) {
            case 'todo':
                return 1;
            case 'standby':
                return 2;
            case 'won':
                return 3;
            case 'lost':
                return 4;
            case 'cancelled':
                return 5;
        }
    }
}
