<?php

namespace App\Imports;

use App\Enums\DocumentType;
use App\Policy;
use App\PolicyInsured;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PolicyInsuredsImport implements ToModel, WithStartRow
{
    private $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    /**
     * @param array $row
     *
     * @return Model|null
     */
    public function model(array $row)
    {
        $row = $this->parseRow($row);

        return new PolicyInsured([
            'policy_id' => $this->policy->id,
            'name' => $row[0],
            'document_type' => $this->find($row[1]),
            'document_number' => $row[2],
            'birth_date' => Carbon::createFromFormat('d/m/Y', $row[3]),
            'with_eps' => $row[4],
            'eps_type' => $row[5],
            'enabled' => 1
        ]);
    }

    private function parseRow(array $row)
    {
        // detect if data is not parsed
        if (count($row) == 1) {
            // rebuild row for spanish data
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    private function find($document_type)
    {
        $document_type = strtolower($document_type);
        switch ($document_type) {
            case 'dni':
                return DocumentType::DNI;
            case 'ruc':
                return DocumentType::RUC;
            case 'passport':
            case 'pasaporte':
                return DocumentType::PASSPORT;
        }

        return DocumentType::DNI;
    }

    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2;
    }
}
