<?php

namespace App\Imports;

use App\Company;
use App\Customer;
use App\Employee;
use App\Enums\SellType;
use App\Policy;
use App\PolicyBeneficiary;
use App\PolicyInsured;
use App\PolicyPaymentType;
use App\PolicyStatus;
use App\Product;
use App\Sector;
use Carbon\Carbon;
use Exception;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Row;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class PoliciesImport implements WithChunkReading, WithStartRow, OnEachRow
{
    /**
     * @var Company
     */
    private $company;
    /**
     * @var Sector
     */
    private $sector;
    /**
     * @var Product
     */
    private $product;
    /**
     * @var Customer
     */
    private $customer;

    /**
     * @return int
     */
    public function chunkSize(): int
    {
        return 10;
    }

    /**
     * @return int
     */
    public function batchSize(): int
    {
        return 10;
    }

    public function startRow(): int
    {
        return 2;
    }

    /**
     * @param Row $row
     * @throws Exception
     */
    public function onRow(Row $row)
    {
        $rowIndex = $row->getIndex();
        $row = $row->toArray();
        $policy = $this->model($row);
        $policy->save();

        try {
            if (strlen($row[13])) {
                $insured = new PolicyInsured();
                $insured->name = $row[13];

                $policy->insureds()->save($insured);
            }

            if (strlen($row[16]) > 0) {
                $beneficiary = new PolicyBeneficiary();
                $beneficiary->name = $row[16];

                $policy->beneficiaries()->save($beneficiary);
            }
        } catch (Exception $exception) {
            dump($rowIndex);
            dump($exception->getMessage());
        }
    }

    /**
     * @param array $row
     * @return Policy|null
     * @throws Exception
     */
    public function model(array $row)
    {
        return new Policy([
            'user_id' => 1, // default user
            'broker_id' => 1, // default broker
            'requested_date' => $this->parseDate($row[1]),
            'sell_type' => SellType::search($row[2]),
            'assessor_id' => $this->findAssessor($row[3])->id,
            'company_id' => $this->findCompany($row),
            'sector_id' => $this->findSector($row),
            'product_id' => $this->findProduct($row),
            'operation_status' => $this->findStatus($row[7]),
            'active' => $this->parsePolicyStatus($row),
            'procedure_number' => $row[9],
            'customer_id' => $this->findCustomer($row)->id,
            'prime' => $this->parseNumber($row[19]),
            'currency' => $this->parseCurrency($row[20]),
            'commission_real' => $this->parseNumber($row[21]),
            'release_date' => $this->parseDate($row[22]),
            'renewal_month' => $row[23],
            'validity_date' => $this->parseDate($row[24], 'm/j/Y'),
            'renewal_date' => $this->parseDate($row[25]),
            //'delivery_date' => $this->parseDate($row[25]),
            'code' => $this->parseCode($row[26]),
            'secured_amount' => $this->parseNumber($row[28]),
            'payment_type' => $this->findPaymentType($row[29]),
            'dues' => $this->parseNumber($row[30], 12),
            'comments' => $row[32],
            'period' => 12,
        ]);
    }

    private function parseDate($date, $format = 'd/m/Y')
    {
        if ($date === '28//10/2019') {
            $date = '28/10/2019';
        }

        if ($date === '01/06/2018/') {
            $date = '01/06/2018';
        }

        if ($date == '01/0/01/2020') {
            $date = '01/01/2020';
        }

        if ($date == '31/05') {
            $date = '31/05/2019';
        }

        if ($date == 'Agosto') {
            $date = '01/08/2019';
        }

        if ($date == '/03/2019') {
            $date = '01/03/2019';
        }

        if ($date == 'U-93357') {
            return null;
        }

        if (is_string($date) && strlen($date) > 20) {
            return null;
        }

        if (is_string($date) && $date != 'x') {
            return Carbon::createFromFormat($format, $date);
        }

        if (is_numeric($date)) {
            return Date::excelToDateTimeObject($date);
        }

        return null;
    }

    private function findAssessor($name)
    {
        $employee = Employee::query()->where('name', $name)->first();

        if (is_null($employee)) {
            $employee = factory(Employee::class)->create(['name' => $name]);
        }

        return $employee;
    }

    private function findCompany($row)
    {
        // 4
        $company = Company::query()->where('name', $row[4])->first();

        if (is_null($company) && $row[4] != '') {
            $company = factory(Company::class)->create(['name' => $row[4]]);
        }

        $this->company = $company;

        return is_object($company) ? $company->id : null;
    }

    private function findSector($row)
    {
        // 5
        $sector = Sector::query()->where('name', $row[5])->first();

        if (is_null($sector) && $row[5] != '') {
            $sector = factory(Sector::class)->create(['name' => $row[5], 'company_id' => $this->company->id]);
        }

        $this->sector = $sector;

        return is_object($sector) ? $sector->id : null;
    }

    private function findProduct($row)
    {
        // 6
        $product = Product::query()->where('name', $row[6])->first();

        if (is_null($product) && !is_null($this->sector) && $row[6] != '') {
            $product = factory(Product::class)->create(['name' => $row[6], 'sector_id' => $this->sector->id, 'commission' => 0]);
        }

        $this->product = $product;

        return is_object($product) ? $product->id : null;
    }

    private function findStatus($name)
    {
        $status = PolicyStatus::firstOrNew(['name' => $name]);
        $status->editable = 1;
        $status->enabled = 1;
        $status->save();

        return $status->id;
    }

    private function parsePolicyStatus(array $row)
    {
        try {
            $now = Carbon::now();
            //$date1 = Carbon::createFromFormat('m/j/Y', $row[24]);
            $date2 = Carbon::createFromFormat('d/m/Y', $row[25]);

            if ($date2->greaterThan($now)) {
                return 1;
            }

            return 0;
        } catch (Exception $exception) {
            return 3;
        }
    }

    private function findCustomer(array $row)
    {
        $customer = Customer::firstOrNew(['name' => $row[10]]);
        $customer->document_number = $row[11];
        $customer->code = $row[12];
        $customer->phone = $row[14];
        $customer->email = $row[15];
        $customer->address = $row[17];
        $customer->city = $row[18];
        $customer->save();

        $this->customer = $customer;
        return $customer;
    }

    private function parseNumber($number, $limit = null)
    {
        $number = str_replace(',', '', $number);

        if (is_numeric($number) && !is_null($limit) && $number > $limit) {
            return null;
        }

        if (is_numeric($number)) {
            return $number;
        }

        return null;
    }

    private function parseCurrency($currency)
    {
        $currency = strtolower($currency);
        switch ($currency) {
            case 'soles':
                return 'PEN';
                break;
            case 'dolares':
            case 'dólares':
                return 'US';
                break;
        }
    }

    private function parseCode($code)
    {
        $code = preg_replace('/\D+/', '', $code);
        return $code;
    }

    private function findPaymentType($name)
    {
        if (is_null($name)) {
            $name = 'Desconocido';
        }

        $type = PolicyPaymentType::firstOrNew(['name' => $name]);
        $type->save();

        return $type->id;
    }
}
