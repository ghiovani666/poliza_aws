<?php

namespace App\Imports;

use App\Company;
use App\PaymentDelayed;
use App\PaymentDelayedImportLog;
use App\Policy;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PaymentDelayedImport implements ToModel, WithStartRow
{
    /**
     * @var int
     */
    public $rowSuccess = 0;
    /**
     * @var int
     */
    public $rowFail = 0;
    /**
     * @var Company
     */
    private $company;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    /**
     * @param array $row
     *
     * @return Model|null
     * @throws Exception
     */
    public function model(array $row)
    {
        $row = $this->parseRow($row);

        if (is_null($row[0]) || $row[0] == '') {
            return null;
        }

        $policy = Policy::query()
            ->where('code', $row[0])
            ->first();

        $log = new PaymentDelayedImportLog();
        $log->policy = $row[0];
        $log->amount = $row[1];
        $log->expiry_date = $row[2];
        $log->reason = $row[3];
        $log->dues = $row[4];
        $log->modality = $row[5];
        $log->document = $row[6];
        $log->status = $row[7];
        $log->failed = false;
        $log->save();

        ++$this->rowSuccess;

        if (is_null($policy)) {
            // update log status
            $log->setAttribute('failed', true)->save();
            ++$this->rowFail;
            --$this->rowSuccess;

            // skip row
            return null;
        }

        return new PaymentDelayed([
            'user_id' => Auth::id(),
            'company_id' => $policy->company->id,
            'policy_id' => $policy->id,
            'assessor_id' => $policy->assessor_id,
            'customer_id' => $policy->customer_id,
            'amount' => $row[1],
            'expiration_date' => Carbon::createFromFormat('d/m/Y', $row[2]),
            'rejection_reason' => $row[3],
            'dues' => $row[4],
            'payment_method' => $row[5],
            'payment_document' => $row[6],
            'status' => $row[7],
        ]);
    }

    private function parseRow(array $row)
    {
        // detect if data is not parsed
        if (count($row) == 1) {
            // rebuild row for spanish data
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2;
    }
}
