<?php

namespace App\Imports;

use App\PaymentCollection;
use App\Policy;
use Carbon\Carbon;
use Exception;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Row;

class PaymentCollectionsImport implements OnEachRow, WithStartRow
{
    /**
     * @param Row $row
     * @throws Exception
     */
    public function onRow(Row $row)
    {
        $rowIndex = $row->getIndex();
        $row = $row->toArray();

        try {
            // get code in array
            $codes = $this->arrayCodes($row[7]);

            $policyCode = $this->cleanCode($codes[0]);

            // get policy
            $insurePolicy = Policy::query()->where('code', $policyCode)->first();

            // make record
            $payment = new PaymentCollection();
            $payment->created_at = $this->parseDate($row[0]);
            $payment->user_id = 1; // default
            $payment->company_id = $insurePolicy->company_id;
            $payment->customer_id = $insurePolicy->customer_id;
            $payment->ticket = $row[2];
            $payment->assessor_id = $insurePolicy->assessor_id;
            $payment->policies = $insurePolicy->id;
            $payment->sector_id = $insurePolicy->sector_id;
            $payment->product_id = $insurePolicy->product_id;
            $payment->account_number = $row[10];
            $payment->easy_pay = $row[13];
            $payment->status = $this->parseStatus($row[12]);
            $payment->comments = $row[13];
            $payment->save();

        } catch (Exception $exception) {
            dump($rowIndex . ' -> ' . $policyCode);

            //dump($exception->getMessage());
            //exit();
        }
    }

    private function arrayCodes($code)
    {
        return explode('||', $code);
    }

    private function cleanCode($code)
    {
        $code = str_replace('-', '', $code);
        $code = str_replace(' ', '', $code);

        return $code;
    }

    private function parseDate($string)
    {
        try {
            return Carbon::createFromFormat('d/m/Y', $string);
        } catch (Exception $exception) {
            return null;
        }
    }

    private function parseStatus($string)
    {
        switch ($string) {
            case 'OK':
                return 1;
            case 'Proceso':
                return 2;
            case 'Cerrado':
                return 3;
            default:
                return null;
        }
    }

    public function startRow(): int
    {
        return 2;
    }

    private function getCurrency(array $row)
    {
        if (in_array($row[8], ['Soles', 'soles'])) {
            return 'PEN';
        }

        if (in_array($row[8], ['Dólares', 'usd'])) {
            return 'USD';
        }

        return null;
    }
}
