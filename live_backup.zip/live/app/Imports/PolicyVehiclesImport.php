<?php

namespace App\Imports;

use App\Policy;
use App\PolicyVehicle;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PolicyVehiclesImport implements ToModel, WithStartRow
{
    private $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    /**
     * @param array $row
     *
     * @return Model|null
     */
    public function model(array $row)
    {
        $row = $this->parseRow($row);

        return new PolicyVehicle([
            'policy_id' => $this->policy->id,
            'type' => $row[0],
            'use' => $row[1],
            'plate_number' => $row[2],
            'brand' => $row[3],
            'model' => $row[4],
            'engine' => $row[5],
            'chassis' => $row[6],
            'manufacturing_year' => $row[7],
            'commercial_value' => $row[8],
            'certificate_number' => $row[9],
            'currency' => $row[10],
        ]);
    }

    private function parseRow(array $row)
    {
        // detect if data is not parsed
        if (count($row) == 1) {
            // rebuild row for spanish data
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2;
    }
}
