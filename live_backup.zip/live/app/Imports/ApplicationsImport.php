<?php

namespace App\Imports;

use App\PaymentApplication;
use App\Policy;
use Carbon\Carbon;
use Exception;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Row;

class ApplicationsImport implements OnEachRow, WithStartRow
{
    /**
     * @param Row $row
     * @throws Exception
     */
    public function onRow(Row $row)
    {
        $rowIndex = $row->getIndex();
        $row = $row->toArray();

        try {
            // get and clean code
            $policyCode = $row[7];
            $policyCode = str_replace('-', '', $policyCode);
            $policyCode = str_replace(' ', '', $policyCode);

            // get policy
            $insurePolicy = Policy::query()->where('code', $policyCode)->first();

            // make record
            $application = new PaymentApplication();
            $application->created_at = $this->parseDate($row[0]);
            $application->user_id = 1; // default
            $application->company_id = $insurePolicy->company_id;
            $application->customer_id = $insurePolicy->customer_id;
            $application->ticket = $row[2];
            $application->assessor_id = $insurePolicy->assessor_id;
            $application->policy_id = $insurePolicy->id;
            $application->sector_id = $insurePolicy->sector_id;
            $application->product_id = $insurePolicy->product_id;
            $application->currency = $this->getCurrency($row); // 8
            $application->amount = $row[9];
            $application->invoice_document = $row[10];
            $application->invoice = $row[11];
            $application->status = $this->parseStatus($row[12]);
            $application->comments = $row[13];
            $application->save();

        } catch (Exception $exception) {
            dump($rowIndex . ' -> ' . $policyCode);
            //dump($exception->getMessage());
        }
    }

    private function parseDate($string)
    {
        try {
            return Carbon::createFromFormat('d/m/Y', $string);
        } catch (Exception $exception) {
            return null;
        }
    }

    private function getCurrency(array $row)
    {
        if (in_array($row[8], ['Soles', 'soles'])) {
            return 'PEN';
        }

        if (in_array($row[8], ['Dólares', 'usd'])) {
            return 'USD';
        }

        return null;
    }

    private function parseStatus($string)
    {
        switch ($string) {
            case 'Aplicado':
                return 1;
            case 'Proceso':
                return 2;
            case 'Cerrado':
                return 3;
            default:
                return null;
        }
    }

    public function startRow(): int
    {
        return 2;
    }
}
