<?php

namespace App\Imports;

use App\Policy;
use App\PolicyDocument;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PolicyDocumentsImport implements ToModel, WithStartRow
{
    /**
     * @var Policy
     */
    private $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    /**
     * @param array $row
     *
     * @return Model|null
     */
    public function model(array $row)
    {
        $row = $this->parseRow($row);

        return new PolicyDocument([
            'policy_id' => $this->policy->id,
            'name' => $row[0],
            'url' => $row[1],
        ]);
    }

    private function parseRow(array $row)
    {
        if (count($row) == 1) {
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    public function startRow(): int
    {
        return 2;
    }
}
