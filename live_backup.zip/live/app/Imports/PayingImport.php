<?php

namespace App\Imports;

use App\Paying;
use App\PayingImportLog;
use App\PayingItem;
use App\Policy;
use Exception;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PayingImport implements ToModel, WithStartRow
{
    public $rowSuccess = 0;
    public $rowFail = 0;

    /**
     * @param array $row
     *
     * @return PayingItem
     * @throws Exception
     */
    public function model(array $row)
    {
        if (is_null($row[0]) || $row[0] == '') {
            return null;
        }

        $row = $this->parseRow($row);
        $policy = $this->fetchPolicy($row[0]);

        // save log
        $payingLog = new PayingImportLog();
        $payingLog->policy = $row[0];
        $payingLog->prime = $row[1];
        $payingLog->commission = $row[2];
        $payingLog->estimated = $row[3];
        $payingLog->amount = $row[4];
        $payingLog->save();

        ++$this->rowSuccess;

        if (is_null($policy)) {
            // update log status
            $payingLog->setAttribute('failed', true)->save();
            ++$this->rowFail;
            --$this->rowSuccess;

            // skip row
            return null;
        }

        $paying = $this->fetchPaying($policy);

        return new PayingItem([
            'paying_id' => $paying->id,
            'policy_id' => $policy->id,
            'customer_id' => $policy->customer_id,
            'prime' => $row[1],
            'commission_broker' => $row[2],
            'commission_assessor_estimated' => $row[3],
            'commission_assessor_real' => $row[4],
        ]);
    }

    private function parseRow(array $row)
    {
        // detect if data is not parsed
        if (count($row) == 1) {
            // rebuild row for spanish data
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    private function fetchPolicy($code)
    {
        return Policy::query()->where('code', $code)->first();
    }

    private function fetchPaying(Policy $policy)
    {
        return Paying::firstOrCreate(['assessor_id' => $policy->assessor_id, 'status' => 'Pendiente']);
    }

    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2;
    }
}
