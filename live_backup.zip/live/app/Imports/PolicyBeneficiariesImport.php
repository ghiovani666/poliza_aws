<?php

namespace App\Imports;

use App\Enums\DocumentType;
use App\Policy;
use App\PolicyBeneficiary;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class PolicyBeneficiariesImport implements ToModel, WithStartRow
{
    /**
     * @var Policy
     */
    private $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    public function model(array $row)
    {
        $row = $this->parseRow($row);

        return new PolicyBeneficiary([
            'policy_id' => $this->policy->id,
            'name' => $row[0],
            'document_type' => $this->find($row[1]),
            'document_number' => $row[2],
            'birth_date' => Carbon::createFromFormat('d/m/Y', $row[3]),
            'percentage' => $row[4],
            'enabled' => 1
        ]);
    }

    private function parseRow(array $row)
    {
        if (count($row) == 1) {
            $row = explode(';', $row[0]);
        }

        return $row;
    }

    private function find($document_type)
    {
        $document_type = strtolower($document_type);
        switch ($document_type) {
            case 'dni':
                return DocumentType::DNI;
                break;
            case 'ruc':
                return DocumentType::RUC;
                break;
            case 'passport':
            case 'pasaporte':
                return DocumentType::PASSPORT;
                break;
        }

        return DocumentType::DNI;
    }

    public function startRow(): int
    {
        return 2;
    }
}
