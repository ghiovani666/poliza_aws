<?php

namespace App\Exports;

use App\Enums\DocumentType;
use App\Enums\PaymentType;
use App\Enums\PeriodType;
use App\Enums\PolicyPaymentStatus;
use App\Enums\SellType;
use App\Policy;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class PoliciesExport implements FromCollection, WithMapping, WithHeadings
{
    /**
     * @return Collection
     */
    public function collection()
    {
        $data = collect();
        Policy::query()
            ->with(['customer', 'status:id,name', 'broker:id,name', 'assessor:id,name', 'company:id,name', 'sector:id,name', 'product:id,name'])
            ->chunk(5000, function ($policies) use (&$data) {
                $data = $data->merge($policies);
            });

        return $data;
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        // echo(array_reduce($row->beneficiaries()->get()->toArray(), function($acc, $curr) {
        //     $acc = nl2br($acc . $curr["name"] . PHP_EOL);
        //     return $acc;
        // }, "")); exit;
        // var_dump($row->beneficiaries()->get()->toArray()); exit;
        // var_dump($row->beneficiaries()->pluck("name")->toArray()); exit;
        $beneficiaries = $row->beneficiaries()->get()->toArray();
        $insureds = $row->insureds()->get()->toArray();
        $beneficiariesData = ["name" => [], "document_type" => [], "document_number" => []];
        $insuredsData = ["name" => [], "document_type" => [], "document_number" => []];
        foreach ($beneficiaries as $beneficiary) {
            $beneficiariesData["name"][] = $beneficiary["name"];
            $beneficiariesData["document_type"][] = DocumentType::getDescription($beneficiary["document_type"]);
            $beneficiariesData["document_number"][] = $beneficiary["document_number"];
        }
        foreach ($insureds as $insured) {
            $insuredsData["name"][] = $insured["name"];
            $insuredsData["document_type"][] = DocumentType::getDescription($insured["document_type"]);
            $insuredsData["document_number"][] = $insured["document_number"];
        }
        return [
            $row->id,
            $row->requested_date,
            $row->customer->name,
            $row->customer->phone,
            $row->customer->email,
            DocumentType::getDescription($row->customer->document_type),
            $row->customer->document_number,
            $row->customer->birth_date,
            $row->customer->address,
            $row->customer->city,
            $row->customer->province,
            $row->customer->state,
            implode(" / ", $beneficiariesData["name"]),
            implode(" / ", $beneficiariesData["document_type"]),
            implode(" / ", $beneficiariesData["document_number"]),
            implode(" / ", $insuredsData["name"]),
            implode(" / ", $insuredsData["document_type"]),
            implode(" / ", $insuredsData["document_number"]),
            $row->commission_real,
            $row->activeName,
            SellType::getDescription($row->sell_type),
            $row->status->name,
            $row->broker->name,
            $row->assessor->name,
            $row->company->name,
            $row->sector->name,
            $row->product->name,
            $row->currency,
            $row->prime,
            PaymentType::getDescription($row->payment_type),
            $row->dues,
            PeriodType::getDescription($row->period),
            $row->code,
            $row->procedure_number,
            $row->release_date,
            $row->validity_date,
            $row->renewal_date,
            $row->delivery_date,
            $row->inspection ? 'Si' : 'No',
            $row->abidance ? 'Si' : 'No',
            $row->deadline,
            $row->insured_amount,
            $row->insurer_docs_date,
            $row->adjuster_docs_date,
            PolicyPaymentStatus::getDescription($row->payment_status),
            $row->comments
        ];
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID', 'Fecha de Solicitud', 'Contratante', 'Telefono', 'Correo', 'Documento Tipo', 'Documento Identidad', 'Cumpleaños', 'Direccion', 'Distrito',
            'Provincia', 'Departamento', 'Beneficiarios Nombre', 'Beneficiarios Tipo. Doc.', 'Beneficiarios Núm. Doc.', 'Asegurados Nombre', 'Asegurados Tipo. Doc.',
            'Asegurados Núm. Doc.', 'Comisión de Intermediación', 'Status de Poliza', 'Tipo de Venta', 'Estado', 'Corredor', 'Asesor', 'Compañia', 'Ramo',
            'Producto', 'Moneda', 'Prima Neta', 'Financiamiento', 'Cuotas', 'Periodo de poliza', 'Poliza', '# Tramite', 'Fecha de Emision', 'Inicio de Vigencia',
            'Fin de Vigencia/Renovación', 'Fecha Entrega Poliza', 'Con Ispecccion', 'Continuidad', 'Fecha de Entrega', 'Monto Asegurado', 'Fecha de Documentación Aseguradora',
            'Fecha de Documentación Ajustador', 'Estado de Pago', 'Observaciones'
        ];
    }
}
