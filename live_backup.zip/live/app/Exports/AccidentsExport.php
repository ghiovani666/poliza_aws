<?php

namespace App\Exports;

use App\Accident;
use App\Policy;
use App\Enums\AccidentState;
use App\Enums\AccidentType;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class AccidentsExport implements FromCollection, WithMapping, WithHeadings
{
    private Policy $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    /**
     * @return Collection
     */
    public function collection()
    {
        $data = collect();
        Accident::query()
            ->with(['policy', 'files'])
            ->where('policy_id', $this->policy->id)
            ->chunk(5000, function ($accidents) use (&$data) {
                $data = $data->merge($accidents);
            });

        return $data;
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        $files = $row->files()->get()->toArray();
        return [
            $row->id,
            $row->policy->code,
            $row->policy->id,
			AccidentType::getDescription($row->type),
			$row->happened_date,
			$row->broker_notification_date,
			$row->insurer_notification_date,
			$row->documentation_receipt_adjuster_date,
			$row->documentation_receipt_no_adjuster_date,
			$row->description,
			$row->place,
			$row->estimated_damage_amount,
			$row->consent_declared_date,
			$row->insurer_paid_date,
			AccidentState::getDescription($row->state),
			$row->resolution_date,
            $row->adicional_comments,
            implode(" / ", array_map(fn($b) => env("APP_URL") . $b["path"], $files))
        ];
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID', 'Póliza Nro.', 'Póliza ID', 'Tipo', 'Fecha del siniestro', 'Fecha de notificación al corredor', 'Fecha de notificación al asegurador',
			'Fecha de recepción de documentación (Con ajustador)', 'Fecha de recepción de documentación (Sin ajustador)', 'Descripción',
			'Lugar', 'Monto estimado de daños', 'Fecha en que la aseguradora declaró consentido el siniestro',
			'Fecha en que la aseguradora efectuó el pago del siniestro', 'Estado', 'Fecha de Resolución', 'Comentarios adicionales', 'Archivos'
        ];
    }
}
