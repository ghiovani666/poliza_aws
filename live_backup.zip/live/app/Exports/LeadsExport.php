<?php

namespace App\Exports;

use App\Enums\LeadProcess;
use App\Enums\LeadSource;
use App\Enums\LeadStage;
use App\Lead;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class LeadsExport implements FromCollection, WithMapping, WithHeadings
{
    /**
     * @return Collection
     */
    public function collection()
    {
        $data = collect();
        Lead::query()
            ->with(['assessor', 'supervisor'])
            ->chunk(1000, function ($leads) use (&$data) {
                $data = $data->merge($leads);
            });

        return $data;
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        return [
            $row->id,
            $row->name,
            $row->phone,
            $row->mail,
            $row->document_type,
            $row->documet_number,
            LeadSource::getDescription($row->source_id),
            LeadStage::getDescription($row->stage_id),
            $row->currency,
            $row->amount,
            $row->close_date,
            LeadProcess::getDescription($row->process_id),
            $row->supervisor->name,
            $row->assessor->name,
            $row->created_at,
            $row->updated_at,
        ];
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID', 'Nombre', 'Telefono', 'Email', 'Documento Tipo', 'Documento Numero', 'Origen', 'Etapa', 'Moneda', 'Importe',
            'Fecha de cierre estimada', 'Proceso', 'Supervisor', 'Asesor', 'Fecha Registro', 'Fecha Actualizacion'
        ];
    }
}
