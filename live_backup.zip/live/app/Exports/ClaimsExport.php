<?php

namespace App\Exports;

use App\Claim;
use App\Enums\ClaimResult;
use App\Policy;
use App\Enums\ClaimState;
use App\Enums\ClaimType;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ClaimsExport implements FromCollection, WithMapping, WithHeadings
{
    private Policy $policy;

    public function __construct(Policy $policy)
    {
        $this->policy = $policy;
    }

    /**
     * @return Collection
     */
    public function collection()
    {
        $data = collect();
        Claim::query()
            ->with(['policy', 'files'])
            ->where('policy_id', $this->policy->id)
            ->chunk(5000, function ($claims) use (&$data) {
                $data = $data->merge($claims);
            });

        return $data;
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        $files = $row->files()->get()->toArray();
        return [
            $row->id,
            $row->policy->code,
            $row->policy->id,
			ClaimType::getDescription($row->type),
			$row->submission_date,
			$row->reason,
			$row->money_amount_claimed,
			ClaimResult::getDescription($row->result),
			$row->resolution_date,
			ClaimState::getDescription($row->state),
            $row->adicional_comments,
            implode(" / ", array_map(fn($b) => env("APP_URL") . $b["path"], $files))
        ];
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID', 'Póliza Nro.', 'Póliza ID', 'Tipo', 'Fecha del reclamo', 'Motivo', 'Monto solicitado', 'Resultado', 'Fecha de Resolución', 'Estado',
            'Comentarios adicionales', 'Archivos'
        ];
    }
}
