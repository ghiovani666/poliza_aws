<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PolicyStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if (request()->get('refresh') == 1) {
            return [];
        }

        return [
            'requested_date' => 'date|nullable',
            'name' => 'required',
            'email' => 'required',
            'document_number' => 'required',
            'renewal_date' => 'date|nullable',
        ];
    }
}
