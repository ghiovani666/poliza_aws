<?php

namespace App\Http\Controllers;

use App\Imports\PayingImport;
use App\Paying;
use App\PayingItem;
use App\Setting;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

class PayingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $this->authorize('view-any', Paying::class);

        $payings = Paying::query()
            ->paginate();

        return view('payings.index', compact('payings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $this->authorize('create', Paying::class);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            // store
            $filePath = $request->file('file')->store('imports');

            // import
            $import = new PayingImport();
            Excel::import($import, $filePath);
            $countRowsOk = $import->rowSuccess;
            $countRowsBad = $import->rowFail;

            // update
            Paying::query()->where('status', 'Pendiente')->get()->each(function (Paying $paying) {
                $paying->calculateAmount();
                $paying->calculateRange();
                $paying->save();
            });

            DB::commit();

            flash('Arhivo importado correctamnete.<br><strong>' . $countRowsOk . '</strong> registros importados correctamente.<br><strong>' . $countRowsBad . '</strong> registros no procesados.')->success()->important();
        } catch (Exception $exception) {
            DB::rollBack();
            Log::error($exception->getMessage(), $exception->getTrace());
            flash($exception->getMessage())->error()->important();
        }

        return redirect()->route('payings.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Paying $paying
     * @return Response
     */
    public function show(Paying $paying)
    {
        $this->authorize('view', $paying);

        $items = PayingItem::query()
            ->where('paying_id', $paying->id)
            ->paginate();

        return view('payings.show', compact('paying', 'items'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Paying $paying
     * @return Response
     */
    public function edit(Paying $paying)
    {
        $this->authorize('edit', $paying);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Paying $paying
     * @return Response
     */
    public function update(Request $request, Paying $paying)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Paying $paying
     * @return Response
     */
    public function destroy(Paying $paying)
    {
        //
    }

    public function liquidate(Request $request)
    {
        $this->validate($request, [
            'abc' => 'required|array|min:1'
        ]);

        foreach ($request->get('abc') as $id) {
            $obj = Paying::find($id);
            $obj->status = 'Pagado';
            $obj->save();
        }

        flash('Liquidaciones realizadas correctamente.')->success()->important();

        return redirect()->route('payings.index');
    }

    public function report()
    {
        $setting = Setting::query()->where('key', 'SPREADSHEET_EMBED_BALANCE')->first();

        return view('payings.report', compact('setting'));
    }
}
