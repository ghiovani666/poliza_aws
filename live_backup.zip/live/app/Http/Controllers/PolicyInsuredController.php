<?php

namespace App\Http\Controllers;

use App\Http\Requests\PolicyInsuredStoreRequest;
use App\Http\Requests\PolicyInsuredUpdateRequest;
use App\Imports\PolicyInsuredsImport;
use App\Policy;
use App\PolicyInsured;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PolicyInsuredController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function index(Policy $policy)
    {
        $insureds = $policy->insureds()
            ->orderBy('name')
            ->paginate();

        return view('policies.insureds.index', compact('policy', 'insureds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function create(Policy $policy)
    {
        return view('policies.insureds.create', compact('policy'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyInsuredStoreRequest $request
     * @param Policy $policy
     * @return void
     */
    public function store(PolicyInsuredStoreRequest $request, Policy $policy)
    {
        $insured = new PolicyInsured();
        $insured->fill($request->all());

        $policy->insureds()->save($insured);

        flash('Asegurado registrado correctamente.')->success();

        return redirect()->to(route('policies.insureds.index', $policy) . '#insureds');
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @param PolicyInsured $insured
     * @return Response
     */
    public function show(Policy $policy, PolicyInsured $insured)
    {
        return view('policies.insureds.show', compact('policy', 'insured'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param PolicyInsured $insured
     * @return Response
     */
    public function edit(Policy $policy, PolicyInsured $insured)
    {
        return view('policies.insureds.edit', compact('policy', 'insured'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyInsuredUpdateRequest $request
     * @param Policy $policy
     * @param PolicyInsured $insured
     * @return void
     */
    public function update(PolicyInsuredUpdateRequest $request, Policy $policy, PolicyInsured $insured)
    {
        $insured->fill($request->all());
        $insured->save();

        flash('Asegurado actualizado correctamente.')->success();

        return redirect()->to(route('policies.insureds.index', $policy) . '#insureds');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @param PolicyInsured $insured
     * @return Response
     * @throws Exception
     */
    public function destroy(Policy $policy, PolicyInsured $insured)
    {
        //$insured->delete();
        $insured->fill(request()->all());
        $insured->enabled = false;
        $insured->save();

        flash('Asegurado eliminado correctamente.')->success();

        return redirect()->to(route('policies.insureds.index', $policy) . '#insureds');
    }

    public function import(Request $request, Policy $policy)
    {
        try {
            DB::beginTransaction();
            // store
            $filePath = $request->file('file')->store('imports');

            // import
            Excel::import(new PolicyInsuredsImport($policy), $filePath);

            flash('Archivo importado correctamente.')->success();

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();

            flash($exception->getMessage())->error();
        }

        return redirect()->to(route('policies.insureds.index', $policy) . '#insureds');
    }
}
