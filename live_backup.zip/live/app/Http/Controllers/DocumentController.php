<?php

namespace App\Http\Controllers;

use App\Document;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $documents = Document::query()->orderByDesc('id')->paginate();

        return view('documents.index', compact('documents'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('documents.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'url' => 'required',
        ]);

        $document = new Document();
        $document->user_id = Auth::id();
        $document->fill($request->all());
        $document->save();

        flash('Documento añadido correctamente.')->success()->important();

        return redirect()->route('documents.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Document $document
     * @return Response
     */
    public function show(Document $document)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Document $document
     * @return Response
     */
    public function edit(Document $document)
    {
        return view('documents.edit', compact('document'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Document $document
     * @return Response
     */
    public function update(Request $request, Document $document)
    {
        $request->validate([
            'name' => 'required',
            'url' => 'required',
        ]);

        $document->fill($request->all());
        $document->save();

        flash('Documento actualizado correctamente.')->success()->important();

        return redirect()->route('documents.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Document $document
     * @return RedirectResponse|Response
     */
    public function destroy(Document $document)
    {
        try {
            $document->delete();

            flash('Documento eliminado correctamente.')->success()->important();
        } catch (Exception $exception) {
            report($exception);
            flash('Error, no se pudo eliminar el documento.')->error()->important();
        }

        return redirect()->route('documents.index');
    }
}
