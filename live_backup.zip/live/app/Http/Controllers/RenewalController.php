<?php

namespace App\Http\Controllers;

use App\Policy;
use App\Setting;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RenewalController extends Controller
{
    public function index(Request $request)
    {
        $policies = Policy::query()
            ->with(['status', 'customer', 'assessor'])
            ->leftJoin('customers', 'customers.id', '=', 'policies.customer_id')
            ->select('policies.*', 'customers.name', 'customers.document_number')
            // ->where('active', 0)
            ->where('sell_type', 3)
            ->where('operation_status', 5)
            ->where('period', '<>', 99)
            ->when($request->filled('customer'), function (Builder $query) use ($request) {
                $query->where('customers.name', 'like', "%{$request->customer}%");
            })
            ->when($request->filled('document_number'), function (Builder $query) use ($request) {
                $query->where('customers.document_number', 'like', "%{$request->document_number}%");
            })
            ->when($request->filled('code'), function ($query) use ($request) {
                $query->where('policies.code', 'like', "%{$request->code}%");
            })
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->assessor_id);
            })
            ->when($request->filled('wish_renewal'), function ($query) use ($request) {
                $query->where('wish_renewal', (int)$request->wish_renewal);
            })
            ->when($request->filled('validity_date'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('validity_date'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0])->toDateString();
                $to = Carbon::createFromFormat('d/m/Y', $range[1])->toDateString();

                $query->whereBetween('validity_date', [$from, $to]);
            })
            ->when(Auth::user()->isAssessor, function ($query) {
                $query->where('assessor_id', Auth::user()->employee->id);
            })
            ->orderByDesc('id')
            ->paginate();

        return view('renewal.index', compact('policies'));
    }

    public function show(Policy $policy)
    {
        return view('renewal.show', compact('policy'));
    }

    public function update(Policy $policy, Request $request)
    {
        $request->validate(['wish_renewal']);

        $policy->post_sale_editable = false;
        $policy->wish_renewal = $request->get('wish_renewal');
        $policy->comments = $request->get('comments');
        $policy->save();

        flash('Renovacion actualizada correctamente.')->success()->important();

        return redirect()->route('renewal.index');
    }

    public function report()
    {
        $setting = Setting::query()->where('key', 'SPREADSHEET_EMBED_RENEWAL')->first();

        return view('renewal.report', compact('setting'));
    }
}
