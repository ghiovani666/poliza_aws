<?php

namespace App\Http\Controllers;

use App\Finance;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class FinanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $finances = Finance::query()
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->get('status'));
            })
            ->where('enabled', true)
            ->orderByDesc('id')
            ->paginate();

        $cboStatus = ['' => '-Todos-'] + dropdownData('FinanceStatuses');

        return view('finances.index', compact('finances','cboStatus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('finances.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate(['customer_id' => 'required']);

        $finance = new Finance();
        $finance->fill($request->all());
        $finance->user_id = Auth::id();
        $finance->save();

        flash('Nuevo financiamiento registrado correctamente')->success()->important();

        return redirect()->route('finances.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Finance $finance
     * @return Response
     */
    public function show(Finance $finance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Finance $finance
     * @return Response
     */
    public function edit(Finance $finance)
    {
        return view('finances.edit', compact('finance'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Finance $finance
     * @return Response
     */
    public function update(Request $request, Finance $finance)
    {
        $request->validate(['customer_id' => 'required']);

        $finance->fill($request->all());
        $finance->user_id = Auth::id();
        $finance->save();

        flash('Financiamiento actualizado correctamente')->success()->important();

        return redirect()->route('finances.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Finance $finance
     * @return Response
     * @throws Exception
     */
    public function destroy(Finance $finance)
    {
        $finance->delete();

        flash('Financiamiento eliminado correctamente')->success()->important();

        return redirect()->route('finances.index');
    }

    public function disabled(Request $request)
    {
        $finances = Finance::query()
            ->with(['customer', 'assessor'])
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->where('enabled', false)
            ->orderByDesc('id')
            ->paginate();

        return view('finances.disabled', compact('finances'));
    }

    public function disable(Finance $finance)
    {
        $this->authorize('disable', $finance);

        $finance->enabled = false;
        $finance->save();

        flash('Financiamiento eliminado correctamente')->success()->important();

        return redirect()->route('finances.index');
    }
}
