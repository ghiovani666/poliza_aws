<?php

namespace App\Http\Controllers;

use App\BankCheck;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class BankCheckController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index(Request $request)
    {
        $this->authorize('view-any', BankCheck::class);

        $bankChecks = BankCheck::query()
            ->with(['customer'])
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->where('enabled', true)
            ->orderByDesc('id')
            ->paginate();

        return view('bankcheks.index', compact('bankChecks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $this->authorize('create', BankCheck::class);

        return view('bankcheks.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $this->authorize('create', BankCheck::class);

        $request->validate([
            'customer_id' => 'required'
        ]);

        $bankCheck = new BankCheck();
        $bankCheck->fill($request->all());
        $bankCheck->user_id = Auth::id();
        $bankCheck->save();

        flash('Nuevo cheque registrado correctamente')->success()->important();

        return redirect()->route('bank_checks.index');
    }

    /**
     * Display the specified resource.
     *
     * @param BankCheck $bankCheck
     * @return Response
     */
    public function show(BankCheck $bankCheck)
    {
        $this->authorize('view', BankCheck::class);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param BankCheck $bankCheck
     * @return Response
     */
    public function edit(BankCheck $bankCheck)
    {
        $this->authorize('update', $bankCheck);

        return view('bankcheks.edit', compact('bankCheck'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param BankCheck $bankCheck
     * @return Response
     */
    public function update(Request $request, BankCheck $bankCheck)
    {
        $this->authorize('update', $bankCheck);

        $request->validate([
            'customer_id' => 'required'
        ]);

        $bankCheck->fill($request->all());
        $bankCheck->save();

        flash('Cheque actualizado correctamente')->success()->important();

        return redirect()->route('bank_checks.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param BankCheck $bankCheck
     * @return Response
     * @throws Exception
     */
    public function destroy(BankCheck $bankCheck)
    {
        $this->authorize('delete', $bankCheck);

        $bankCheck->delete();

        flash('Cheque eliminado correctamente')->success()->important();

        return redirect()->route('bank_checks.index');
    }

    public function disabled(Request $request)
    {
        $bankChecks = BankCheck::query()
            ->with(['customer'])
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->where('enabled', false)
            ->orderByDesc('id')
            ->paginate();

        return view('bankcheks.disabled', compact('bankChecks'));
    }

    public function disable(BankCheck $bankCheck)
    {
        $this->authorize('disable', $bankCheck);

        $bankCheck->enabled = false;
        $bankCheck->save();

        flash('Cheque eliminado correctamente')->success()->important();

        return redirect()->route('bank_checks.index');
    }
}
