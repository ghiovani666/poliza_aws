<?php

namespace App\Http\Controllers;

use App\Employee;
use App\EmployeeType;
use App\Http\Requests\EmployeeStoreRequest;
use App\Http\Requests\EmployeeUpdateRequest;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->authorize('view-any', Employee::class);

        $employees = Employee::query()
            ->with('job')
            ->withCount(['policies'])
            ->when($request->has('name') && !is_null($request->get('name')), function ($query) use ($request) {
                $query->where('name', 'like', "%{$request->name}%");
            })
            ->when($request->has('dni') && !is_null($request->get('dni')), function ($query) use ($request) {
                $query->where('dni', 'like', "%{$request->dni}%");
            })
            ->when($request->filled('type_id'), function ($query) use ($request) {
                $query->where('type', $request->type_id);
            })
            ->orderByDesc('id')
            ->paginate();

        return view('employees.index', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $this->authorize('create', Employee::class);

        $employeeTypes = EmployeeType::query()->orderBy('name')->pluck('name', 'id')->toArray();

        return view('employees.create', compact('employeeTypes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param EmployeeStoreRequest $request
     * @return void
     */
    public function store(EmployeeStoreRequest $request)
    {
        $this->authorize('create', Employee::class);

        $employee = new Employee();
        $employee->fill($request->all());
        $employee->save();

        flash('Nuevo empleado registrado correctamente.')->success();

        return redirect()->route('employees.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Employee $employee
     * @return Response
     */
    public function show(Employee $employee)
    {
        $this->authorize('view', $employee);

        return view('employees.show', compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Employee $employee
     * @return Response
     */
    public function edit(Employee $employee)
    {
        $this->authorize('update', $employee);

        $employeeTypes = EmployeeType::query()->orderBy('name')->pluck('name', 'id')->toArray();

        return view('employees.edit', compact('employee', 'employeeTypes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param EmployeeUpdateRequest $request
     * @param Employee $employee
     * @return void
     */
    public function update(EmployeeUpdateRequest $request, Employee $employee)
    {
        $this->authorize('update', $employee);

        $employee->fill($request->all());
        $employee->save();

        flash('Empleado actualizado correctamente.')->success();

        return redirect()->route('employees.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Employee $employee
     * @return Response
     * @throws Exception
     */
    public function destroy(Employee $employee)
    {
        $employee->delete();

        flash('Empleado eliminado correctamente.')->success();

        return redirect()->route('employees.index');
    }
}
