<?php

namespace App\Http\Controllers;

use App\Accident;
use App\AccidentFile;
use App\Company;
use App\Customer;
use App\Employee;
use App\Exports\AccidentsAllExport;
use App\Exports\AccidentsExport;
use App\Http\Requests\PolicyStoreRequest;
use App\Http\Requests\PolicyUpdateRequest;
use App\Policy;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class AccidentController extends Controller
{
    /**
     * @var Customer
     */
    private $customer;
    /**
     * @var Accident
     */
    private $accident;

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Policy $policy, Request $request)
    {
        $accidents = Accident::fetchAll($policy, $request)
            ->orderByDesc('id')
            ->paginate();

        return view('policies.accidents.index', compact('accidents', 'policy'));
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function show(Policy $policy)
    {
        return view('policies.show', compact('policy', 'helper'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create(Policy $policy)
    {
        $companies = [null => '- Seleccionar -'] + Company::query()->orderBy('name')->pluck('name', 'id')->toArray();
        $employees = Employee::query()->orderBy('name')->pluck('name', 'id');
        return view('policies.accidents.create', compact('companies', 'employees', 'policy'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param Accident $accident 
     * @return Response
     */
    public function edit(Policy $policy, Accident $accident)
    {
        return view('policies.accidents.edit', compact('policy', 'accident'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyStoreRequest $request
     * @return Response
     */
    public function store(Request $request, Policy $policy) // Request $request
    {
        $accident = $this->saveAccident($request);
        if ($request->file("files")) {
            foreach ($request->allFiles()["files"] as $file) {
                $fileName = uniqid(date('Ymdhisu')) . "." . $file->extension();
                $basePath = __DIR__ . "../../../../public";
                $filePath = "/uploads/policies/accidents/{$fileName}";
                file_put_contents($basePath . $filePath, file_get_contents($file->path()));
                $accidentFile = new AccidentFile();
                $accidentFile->accident_id = $accident->id;
                $accidentFile->name = $file->getClientOriginalName();
                $accidentFile->size = $file->getSize();
                $accidentFile->path = $filePath;
                $accidentFile->save();
            }
        }
        return redirect()->route('policies.accidents.index', $policy);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyUpdateRequest $request
     * @param Policy $policy
     * @return Response
     */
    public function update(Request $request, Policy $policy, Accident $accident)
    {
        try {
            // echo "<pre>"; var_dump($request->all()); exit;
            DB::beginTransaction();
            $this->saveAccident($request, $accident);
            DB::commit();
            flash('Siniestro actualizado correctamente.')->success();
        } catch (Exception $exception) {
            DB::rollBack();
            flash($exception->getMessage())->error();
        }
        // $policy->load('assessor');
        return redirect()->route('policies.accidents.index', $policy);
    }

    /**
     * @param Request $request
     * @param Policy|null $policy
     */
    private function saveAccident(Request $request, $accident = null)
    {
        if (is_null($accident)) {
            $accident = new Accident();
        }
        $accident->fill($request->except(['refresh', 'return', 'files']));
        $accident->policy_id = $request->get('policy_id');
        // $accident->customer_id = $this->customer->id;
        // $accident->commission_percentage = (int)$request->commission_percentage; // prevent error for empty value
        $accident->save();
        // $this->accident = $accident;
        return $accident;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @return void
     * @throws Exception
     */
    public function destroy(Policy $policy, Accident $accident)
    {
        $accident->delete();

        flash('Siniestro eiminado correctamente.')->success();

        return redirect()->route('policies.accidents.index', $policy);
    }

    public function exportAll()
    {
        return Excel::download(new AccidentsAllExport(), "Siniestros " . date("Y-m-d h:m") . ".xlsx");
    }

    public function export(Policy $policy)
    {
        return Excel::download(new AccidentsExport($policy), "Siniestros (Poliza Nro. {$policy->code} [ID {$policy->id}]).xlsx");
    }
}
