<?php

namespace App\Http\Controllers;

use App\Policy;
use Illuminate\Http\Request;

class PolicyAlertController extends Controller
{
    public function index(Policy $policy)
    {
        return view('policies.alerts.index', compact('policy'));
    }

    public function update(Request $request, Policy $policy)
    {
        $policy->fill($request->all());
        $policy->save();

        flash('Alertas actualizadas correctamente.')->success()->important();

        return redirect()->route('policies.alerts.index', $policy);
    }
}
