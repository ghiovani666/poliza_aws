<?php

namespace App\Http\Controllers;

use App\Company;
use App\Http\Requests\KeyStoreRequest;
use App\Http\Requests\KeyUpdateRequest;
use App\Key;
use App\Product;
use App\Sector;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class KeyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        $keys = Product::query()
            ->orderByDesc('id')
            ->paginate();

        return view('keys.index', compact('keys'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $companies = Company::query()->orderBy('name')->pluck('name', 'id');
        $sectors = Sector::query()->orderBy('name')->pluck('name', 'id');
        $products = Product::query()->orderBy('name')->pluck('name', 'id');

        return view('keys.create', compact('companies', 'sectors', 'products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param KeyStoreRequest $request
     * @return void
     */
    public function store(KeyStoreRequest $request)
    {
        $company = Company::find($request->company_id);
        $sector = Company::find($request->sector_id);
        $product = Company::find($request->product_id);

        $key = new Key();
        $key->fill($request->all());
        $key->name = $company->name . $sector->name . $product->name;
        $key->enabled = true;
        $key->save();

        flash('Nuevo key registrado correctamente.')->success();

        return redirect()->route('keys.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Key $key
     * @return Response
     */
    public function show(Key $key)
    {
        return view('keys.show', compact('key'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Key $key
     * @return Response
     */
    public function edit(Key $key)
    {
        $companies = Company::query()->orderBy('name')->pluck('name', 'id');
        $sectors = Sector::query()->orderBy('name')->pluck('name', 'id');
        $products = Product::query()->orderBy('name')->pluck('name', 'id');

        return view('keys.edit', compact('key', 'companies', 'sectors', 'products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Key $key
     * @return Response
     */
    public function update(KeyUpdateRequest $request, Key $key)
    {
        $company = Company::find($request->company_id);
        $sector = Company::find($request->sector_id);
        $product = Company::find($request->product_id);

        $key->fill($request->all());
        $key->name = $company->name . $sector->name . $product->name;
        $key->save();

        flash('Key actualizaco correctamente.')->success();

        return redirect()->route('keys.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Key $key
     * @return Response
     */
    public function destroy(Key $key)
    {
        //
    }
}
