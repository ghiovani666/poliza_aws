<?php

namespace App\Http\Controllers\Api;

use App\Company;
use App\Employee;
use App\EmployeeType;
use App\Enums\SellType;
use App\Http\Controllers\Controller;
use App\Product;
use App\Sector;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;

class ChartController extends Controller
{
    public function years()
    {
        $from = 2015;
        $to = (int)date('Y');
        $data = collect();

        for ($i = $to; $i >= $from; $i--) {
            $data->push(['id' => $i, 'name' => $i]);
        }

        return new JsonResource($data);
    }

    public function companies()
    {
        $companies = Company::query()
            ->orderBy('name')
            ->get();

        return new JsonResource($companies);
    }

    public function sectors()
    {
        $sectors = Sector::query()
            ->distinct()
            ->orderBy('name')
            ->get('name');

        $data = [];
        foreach ($sectors as $row) {
            $data[] = ['id' => $row['name'], 'name' => $row['name']];
        }

        return new JsonResource($data);
    }

    public function products()
    {
        $products = Product::query()
            ->distinct()
            ->select('id', 'name')
            ->orderBy('name')
            ->get();

        $data = [];
        foreach ($products as $row) {
            $data[] = ['id' => $row['id'], 'name' => $row['name']];
        }

        return new JsonResource($data);
    }

    public function sellTypes()
    {
        $types = SellType::toSelectArray();
        $data = [];
        foreach ($types as $index => $value) {
            $data[] = ['id' => $index, 'name' => $value];
        }

        return new JsonResource($data);
    }

    public function assessors()
    {
        $employee = Auth::user()->employee;
        $employees = Employee::query()
            ->select('id', 'name')
            ->whereType(1)
            ->when($employee->type == 6, function ($query) use ($employee) {
                $query->whereIn('id', $employee->supervise);
            })
            ->orderBy('name')
            ->get();

        return new JsonResource($employees);
    }

    public function employeeTypes()
    {
        $types = EmployeeType::query()
            ->select('id', 'name')
            ->orderBy('name')
            ->get();

        return new JsonResource($types);
    }

    public function employees(Request $request)
    {
        $employees = Employee::query()
            ->select('id', 'name')
            ->when($request->filled('type'), function ($query) use ($request) {
                $query->where('type', $request->get('type'));
            })
            ->orderBy('name')
            ->get();

        return new JsonResource($employees);
    }

    public function topTypes()
    {
        $data = collect([
            ['id' => 1, 'name' => 'Pólizas'],
            ['id' => 2, 'name' => 'Primas'],
        ]);

        return new JsonResource($data);
    }

    public function currencies()
    {
        $data = collect([
            ['id' => 'PEN', 'name' => 'S/'],
            ['id' => 'USD', 'name' => '$'],
        ]);

        return new JsonResource($data);
    }
}
