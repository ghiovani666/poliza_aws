<?php

namespace App\Http\Controllers\Api;

use App\Comment;
use App\Http\Controllers\Controller;
use App\Lead;
use App\Notifications\LeadWasCommentedNotificationToAssessor;
use App\Notifications\LeadWasCommentedNotificationToSupervisor;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return JsonResource
     */
    public function index(Request $request)
    {
        $comments = Comment::query()
            ->with('user:id,name')
            ->where('commentable_id', $request->source_id)
            ->where('commentable_type', $request->source_type)
            ->orderByDesc('created_at');

        return new JsonResource($comments->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $comment = new Comment();
        $comment->user_id = Auth::id();
        $comment->body = $request->filled('message') ? $request->message : '...';
        $comment->commentable_type = $request->source_type;
        $comment->commentable_id = $request->source_id;
        //$comment->actions = $request->actions;

        // check upload file
        if ($request->hasFile('file')) {
            $path = $request->file('file')->store('comments', ['disk' => 'public']);
            $comment->attachment = $path;
        }

        $comment->save();
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
