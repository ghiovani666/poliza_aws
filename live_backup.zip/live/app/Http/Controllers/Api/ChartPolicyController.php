<?php

namespace App\Http\Controllers\Api;

use App\Charts\TableCounter;
use App\Charts\TableTop;
use App\Employee;
use App\EmployeeType;
use App\Finance;
use App\Http\Controllers\Controller;
use App\PaymentApplication;
use App\PaymentCollection;
use App\Policy;
use App\Sector;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class ChartPolicyController extends Controller
{
    public function best(Request $request)
    {
        $data = ['labels' => [], 'values' => []];
        $year = $request->get('year', date('Y'));
        $currency = $request->get('currency', 'PEN');

        $company = $request->get('company');
        $sector = $request->get('sector');
        $product = $request->get('product');

        $assessors = Policy::query()
            ->with('assessor')
            ->select('assessor_id', DB::raw('SUM(prime) as total'))
            ->whereYear('validity_date', $year)
            ->where('currency', $currency)
            ->when(is_numeric($company), function ($query) use ($company) {
                $query->where('company_id', $company);
            })
            ->when(is_numeric($sector), function ($query) use ($sector) {
                $query->where('sector_id', $sector);
            })
            ->when(is_numeric($product), function ($query) use ($product) {
                $query->where('product_id', $product);
            })
            ->groupBy('assessor_id')
            ->orderByDesc('total')
            ->take(5)
            ->get();

        foreach ($assessors as $index => $assessor) {
            $data['labels'][] = $assessor->assessor->name;
            $data['values'][] = $assessor->total;
        }

        return new JsonResource($data);
    }

    public function year(Request $request)
    {
        $data = ['a' => [], 'b' => []];
        $fieldDate = $request->get('field_date', 'validity_date');

        $baseQuery = Policy::query()
            ->leftJoin('employees', 'employees.id', '=', 'policies.assessor_id')
            ->where('active', true)
            ->when($request->filled('year'), function ($query) use ($request) {
                $query->whereYear('validity_date', $request->year);
            })
            ->when($request->filled('sector'), function ($query) use ($request) {
                $sectors = Sector::query()->where('name', 'like', $request->get('sector'))->pluck('id');
                $query->whereIn('sector_id', $sectors);
            })
            ->when($request->filled('product_id'), function ($query) use ($request) {
                $query->where('product_id', $request->get('product_id'));
            })
            ->when($request->filled('employee_type'), function ($query) use ($request) {
                $roles = EmployeeType::find($request->employee_type)->hierarchy();
                $query->whereIn('employees.type', $roles);
            })
            ->when($request->filled('employee_id'), function ($query) use ($request) {
                $employees = [];
                foreach ($request->employee_id as $id) {
                    $employees = array_merge($employees, Employee::find($id)->hierarchy());
                }
                $query->whereIn('employees.id', $employees);
            });

        $fields = ['operation_status', 'period', 'active', 'assessor_id', 'sell_type', 'company_id'];
        foreach ($fields as $field) {
            $baseQuery->when($request->filled($field), function ($query) use ($field, $request) {
                if (is_array($request->get($field))) {
                    $query->whereIn($field, $request->get($field));
                } else {
                    $query->where($field, $request->get($field));
                }
            });
        }

        for ($month = 1; $month <= 12; $month++) {
            $data['a'][] = round((clone $baseQuery)->whereMonth($fieldDate, $month)->where('currency', 'PEN')->sum('prime'));
            $data['b'][] = round((clone $baseQuery)->whereMonth($fieldDate, $month)->where('currency', 'USD')->sum('prime'));
            $data['count_a'][] = (clone $baseQuery)->whereMonth($fieldDate, $month)->where('currency', 'PEN')->count();
            $data['count_b'][] = (clone $baseQuery)->whereMonth($fieldDate, $month)->where('currency', 'USD')->count();
        }

        return new JsonResource($data);
    }

    public function stock(Request $request)
    {
        $data = ['a' => [], 'b' => []];
        $year = $request->get('year', date('Y'));

        $total_pen = $total_usd = $count_pen = $count_usd = 0;

        for ($month = 1; $month <= 12; $month++) {
            $total_pen += Policy::fetchStock($year, $month, 'PEN')->sum('prime');
            $total_usd += Policy::fetchStock($year, $month, 'USD')->sum('prime');
            $data['a'][] = round($total_pen, 2);
            $data['b'][] = round($total_usd, 2);

            $count_pen += Policy::fetchStock($year, $month, 'PEN')->count();
            $count_usd += Policy::fetchStock($year, $month, 'USD')->count();
            $data['x'][] = $count_pen;
            $data['y'][] = $count_usd;
        }

        return new JsonResource($data);
    }

    public function stockTable(Request $request)
    {
        // base query 1
        $baseQuery1 = Policy::query()
            ->whereIn('active', [1])
            ->when($request->filled('company_id'), function ($query) use ($request) {
                $query->where('company_id', $request->get('company_id'));
            })
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->get('assessor_id'));
            });
        $baseQuery2 = Policy::query()
            ->when($request->filled('company_id'), function ($query) use ($request) {
                $query->where('company_id', $request->get('company_id'));
            })
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->get('assessor_id'));
            });
        $monthQuery1 = (clone $baseQuery1)
            ->whereYear('validity_date', date('Y'))
            ->whereMonth('validity_date', date('m'));
        $monthQuery2 = (clone $baseQuery2)
            ->whereYear('cancellation_date', date('Y'))
            ->whereMonth('cancellation_date', date('m'));

        $baseQuery1->when($request->filled('year'), function ($query) use ($request) {
            $query->whereYear('validity_date', $request->year);
        });

        setlocale(LC_ALL, 'es_PE');
        $now = Carbon::now();
        $data = [
            'current_month' => ucfirst($now->formatLocalized('%B %Y')),
            'pen' => [
                'stock_total' => number_format((clone $baseQuery1)->where('currency', 'PEN')->sum('prime'), 2),
                'stock_num_policies' => (clone $baseQuery1)->where('currency', 'PEN')->count(),
                'month_sell' => (clone $monthQuery1)->where('currency', 'PEN')->where('sell_type', 1)->count(),
                'month_agent' => (clone $monthQuery1)->where('currency', 'PEN')->where('sell_type', 2)->count(),
                'month_cancel' => (clone $monthQuery2)->where('currency', 'PEN')->where('operation_Status', 8)->count(),
            ],
            'usd' => [
                'stock_total' => number_format((clone $baseQuery1)->where('currency', 'USD')->sum('prime'), 2),
                'stock_num_policies' => (clone $baseQuery1)->where('currency', 'USD')->count(),
                'month_sell' => (clone $monthQuery1)->where('currency', 'USD')->where('sell_type', 1)->count(),
                'month_agent' => (clone $monthQuery1)->where('currency', 'USD')->where('sell_type', 2)->count(),
                'month_cancel' => (clone $monthQuery2)->where('currency', 'USD')->where('operation_Status', 8)->count(),
            ]
        ];

        return new JsonResource($data);
    }

    public function top(Request $request)
    {
        $type = $request->get('type', 2);
        $data = (new TableTop($request, $type))->run();

        return new JsonResource($data);
    }

    /**
     * @param Request $request
     * @return JsonResource
     */
    public function stair(Request $request)
    {
        $year = (int)$request->get('year', date('Y'));
        $years = [$year, $year - 1];
        $currencies = ['PEN', 'USD'];
        $sectors = Sector::query()->distinct()->select('name')->get();
        $data = [];

        foreach ($years as $index => $year) {
            $data[$index] = ['year' => $year];
            foreach ($currencies as $index2 => $currency) {
                $data[$index]['currencies'][$index2] = ['currency' => $currency];
                foreach ($sectors as $sector) {
                    $months = [];
                    for ($month = 1; $month <= 12; $month++) {
                        $months[] = Policy::query()
                            ->leftJoin('sectors', 'sectors.id', 'policies.sector_id')
                            ->whereYear('validity_date', $year)
                            ->whereMonth('validity_date', $month)
                            ->company($request->get('company_id'), $request->filled('company_id'))
                            ->sectorName($request->get('sector'), $request->filled('sector'))
                            ->sellType($request->get('sell_type'), $request->filled('sell_type'))
                            ->assessor($request->get('assessor_id'), $request->filled('assessor_id'))
                            ->where('currency', $currency)
                            ->where('sectors.name', $sector->name)
                            ->sum('prime');
                    }

                    if ($this->onceMonthNotZero($months)) {
                        $data[$index]['currencies'][$index2]['sectors'][] = ['sector' => $sector->name, 'months' => $months];
                    }
                }
            }
        }

        return new JsonResource($data);
    }

    private function onceMonthNotZero(array $months)
    {
        foreach ($months as $value) {
            if ((int)$value > 0) {
                return true;
            }
        }

        return false;
    }

    public function renewal(Request $request)
    {
        $data = [];
        $year = $request->get('year', date('Y'));
        $period = new CarbonPeriod('2021-01-01', '1 month', '2021-12-01');

        foreach ($period as $date) {
            $baseQuery = Policy::query()
                ->whereYear('validity_date', $year)
                ->whereMonth('validity_date', $date->month)
                ->renewals();
            $data[] = [
                'month' => ucfirst($date->locale('es')->monthName),
                'answer_yes' => (clone $baseQuery)->where('wish_renewal', 1)->count(),
                'answer_no' => (clone $baseQuery)->where('wish_renewal', 0)->count(),
                'answer_pending' => (clone $baseQuery)->where('wish_renewal', 2)->count(),
                'total' => (clone $baseQuery)->count(),
                'pending' => (clone $baseQuery)->whereNull('wish_renewal')->count(),
            ];
        }

        return $data;
    }

    public function yearStack(Request $request)
    {
        $data = [];
        $baseQuery = Policy::query()
            ->where('active', 1)
            ->when($request->filled('year'), function ($query) use ($request) {
                $query->whereYear('validity_date', $request->year);
            })
            ->where('period', 12);

        for ($month = 1; $month <= 12; $month++) {
            $baseQuery2 = (clone $baseQuery)->whereMonth('validity_date', $month);
            $data['status5_pen_counter'][] = (clone $baseQuery2)->where('operation_status', 5)->where('currency', 'PEN')->count();
            $data['status5_pen_sum'][] = round((clone $baseQuery2)->where('operation_status', 5)->where('currency', 'PEN')->sum('prime'));
            $data['status5_usd_counter'][] = (clone $baseQuery2)->where('operation_status', 5)->where('currency', 'USD')->count();
            $data['status5_usd_sum'][] = round((clone $baseQuery2)->where('operation_status', 5)->where('currency', 'USD')->sum('prime'));
            $data['status6_pen_counter'][] = (clone $baseQuery2)->where('operation_status', 6)->where('currency', 'PEN')->count();
            $data['status6_pen_sum'][] = round((clone $baseQuery2)->where('operation_status', 6)->where('currency', 'PEN')->sum('prime'));
            $data['status6_usd_counter'][] = (clone $baseQuery2)->where('operation_status', 6)->where('currency', 'USD')->count();
            $data['status6_usd_sum'][] = round((clone $baseQuery2)->where('operation_status', 6)->where('currency', 'USD')->sum('prime'));
        }

        return $data;
    }

    public function status(Request $request)
    {
        $year = (int)$request->get('year', date('Y'));
        $type = (int)$request->get('type', 2);
        $statuses = [
            ['name' => 'Ventas Nuevas', 'operation_status' => 2, 'date_mode' => TableCounter::MODE_VALIDITY],
            ['name' => 'Agenciamiento', 'operation_status' => 4, 'date_mode' => TableCounter::MODE_REQUEST],
            ['name' => 'Renovaciones', 'operation_status' => 6, 'date_mode' => TableCounter::MODE_VALIDITY],
            ['name' => 'Anulaciones', 'operation_status' => 9, 'date_mode' => TableCounter::MODE_DELIVERY],
            //['name' => 'Total', 'operation_status' => null, 'date_mode' => null],
        ];

        $data = [];

        foreach ($statuses as $key => $status) {
            $months = [];
            for ($month = 1; $month <= 12; $month++) {
                $request->merge(['operation_status' => $status['operation_status']]);

                $tableCounter = new TableCounter($request, $type, $status['date_mode']);

                $months[] = $tableCounter->setYear($year)->setMonth($month)->run();
            }

            //dd($months);

            $data[$key]['name'] = $status['name'];
            $data[$key]['rows'] = [
                'status' => $status['name'],
                'months' => $months,
                'total' => round(array_sum($months), 2),
            ];
        }

        return new JsonResource($data);
    }

    public function groupsTable(Request $request)
    {
        $year = (int)$request->get('year', date('Y'));

        $tables = [
            ['name' => 'CVC (Cambio de via cobro)', 'operation_status' => 2, 'model' => PaymentCollection::class],
            ['name' => 'Financiamientos', 'operation_status' => 4, 'model' => Finance::class],
            ['name' => 'Aplicaciones de pago', 'operation_status' => 6, 'model' => PaymentApplication::class],
        ];

        $statuses = [
            1 => 'Ok',
            2 => 'En proceso',
            3 => 'Cerrado',
            0 => 'Total',
        ];

        $data = [];

        foreach ($tables as $key => $table) {
            $rows = [];
            foreach ($statuses as $id => $status) {
                $months = [];
                for ($month = 1; $month <= 12; $month++) {
                    $model = new $table['model'];
                    $months[] = $model->query()
                        ->whereYear('created_at', $year)
                        ->whereMonth('created_at', $month)
                        ->when($id > 0, function ($query) use ($id) {
                            $query->whereStatus($id);
                        })
                        ->count();
                }
                $rows[] = [
                    'name' => $status,
                    'months' => $months,
                ];
            }

            $data[$key]['name'] = $table['name'];
            $data[$key]['rows'] = $rows;
        }

        return new JsonResource($data);
    }
}
