<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Lead;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class CalendarLeadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $startDate = Carbon::parse($request->start)->toDateString();
        $endDate = Carbon::parse($request->end)->toDateString();

        $data = [];
        $leads = Lead::query()
            ->whereBetween('close_date', [$startDate, $endDate])
            ->when(in_array(Auth::user()->employee->type, [1, 2]), function (Builder $query) use ($request) {
                $query->where('assessor_id', Auth::user()->employee->id);
            })
            ->when(Auth::user()->employee->type == 6, function (Builder $query) use ($request) {
                $query->where('supervisor_id', Auth::user()->employee->id);
            })
            ->get();

        foreach ($leads as $lead) {
            $data[] = [
                'id' => $lead->id,
                'title' => $lead->name . ' ' . $lead->currency . ' ' . $lead->amount,
                'start' => $lead->close_date->hour(13),
                'end' => $lead->close_date->addhour(1),
                'editable' => false,
                'backgroundColor' => '#f8d7da',
                'borderColor' => '#f5c6cb',
                'textColor' => '#721c24',
                'url' => route('leads.show', $lead)
            ];
        }

        return $data;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
