<?php

namespace App\Http\Controllers\Api;

use App\AccidentFile;
use App\ClaimFile;
use App\Customer;
use App\Http\Controllers\Controller;
use App\Http\Requests\PolicyStoreRequest;
use App\Policy;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

class PolicyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return JsonResource
     */
    public function index(Request $request)
    {
        $policies = Policy::query()
            ->orderByDesc('id')
            ->when($request->filled('customer_id'), function ($query) use ($request) {
                $query->where('customer_id', $request->get('customer_id'));
            })
            ->paginate();

        return new JsonResource($policies);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyStoreRequest $request
     * @return void
     */
    public function store(PolicyStoreRequest $request)
    {
        try {
            DB::beginTransaction();

            $this->addCustomer($request);
            $this->addPolicy($request);

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();
            dd($exception->getMessage());
        }

        return redirect()->route('policies.index');
    }

    private function addCustomer(Request $request)
    {
        $customer = New Customer();
        $customer->name = $request->get('name');
        $customer->phone = $request->get('phone');
        $customer->email = $request->get('email');
        $customer->dni_ruc = $request->get('dni_ruc');
        $customer->birth_date = $request->get('birth_date');
        $customer->address = $request->get('address');
        $customer->state = $request->get('state');
        $customer->province = $request->get('province');
        $customer->city = $request->get('city');
        $customer->save();

        $this->customer = $customer;
    }

    private function addPolicy(Request $request)
    {
        $policy = New Policy();
        $policy->customer_id = $this->customer->id;
        $policy->employee_id = 1;
        $policy->policy_code = $request->get('policy_code');
        $policy->validity = $request->get('policy_code');
        $policy->currency = $request->get('currency');
        $policy->prime = $request->get('prime');
        $policy->broker_id = $request->get('broker_id', 1);
        $policy->assessor_id = $request->get('assesor_id', 1);
        $policy->save();

        $this->policy = $policy;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function uploadFiles(Request $request) {
        $files = [];
        foreach ($request->allFiles()["files"] as $file) {
            $fileName = uniqid(date('Ymdhisu')) . "." . $file->extension();
            $basePath = __DIR__ . "../../../../../public";
            $filePath = "/uploads/policies/{$request->get('target')}/{$fileName}";
            file_put_contents($basePath . $filePath, file_get_contents($file->path()));
            $entityFile = null;
            if ($request->get("target") == "accidents") {
                $accidentFile = new AccidentFile();
                $accidentFile->accident_id = $request->get("entity_id");
                $accidentFile->name = $file->getClientOriginalName();
                $accidentFile->size = $file->getSize();
                $accidentFile->path = $filePath;
                $accidentFile->save();
                $entityFile = $accidentFile;
            } else {
                $claimFile = new ClaimFile();
                $claimFile->claim_id = $request->get("entity_id");
                $claimFile->name = $file->getClientOriginalName();
                $claimFile->size = $file->getSize();
                $claimFile->path = $filePath;
                $claimFile->save();
                $entityFile = $claimFile;
            }
            array_push($files, $entityFile);
        }
        return $files;
    }
}
