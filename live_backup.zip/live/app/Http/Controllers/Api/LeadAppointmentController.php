<?php

namespace App\Http\Controllers\Api;

use App\Employee;
use App\Http\Controllers\Controller;
use App\Lead;
use App\LeadAppointment;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class LeadAppointmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Lead $lead
     * @return Collection|JsonResource
     */
    public function index(Lead $lead)
    {
        $appointments = $lead->appointments()
            ->with('user')
            ->orderByDesc('id')
            ->get();
        return new JsonResource($appointments);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @param Lead $lead
     * @return LeadAppointment|Response
     */
    public function store(Request $request, Lead $lead)
    {
        $appointment = new LeadAppointment();
        $appointment->fill($request->except('time'));
        $appointment->date = Carbon::parse($request->date . ' ' . $request->time);
        $appointment->user_id = Auth::id();
        $lead->appointments()->save($appointment);

        return $appointment;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy(Lead $lead, LeadAppointment $appointment)
    {
        $appointment->delete();
    }

    public function status(Request $request, Lead $lead)
    {
        $data = [
            'number' => 1,
            'date' => Carbon::now()->format('Y-m-d'),
        ];

        if ($lead->appointments()->where('number', 2)->where('status', 2)->count() > 0) {
            $data['number'] = 3;
            return $data;
        }

        if ($lead->appointments()->where('number', 1)->where('status', 2)->count() > 0) {
            $data['number'] = 2;
            return $data;
        }

        return $data;
    }

    public function dashboardDetail(Request $request)
    {
        $employee = Employee::query()->with('user', 'job')->where('id', $request->employee_id)->first();
        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        if ($request->filled('month')) {
            $startDate = Carbon::create($year, $month)->startOfMonth();
            $endDate = (clone $startDate)->endOfMonth();
        }

        if ($request->filled('week')) {
            $startDate = Carbon::now()->setISODate($year, $request->week)->startOfWeek();
            $endDate = (clone $startDate)->endOfWeek();
        }

        if ($request->filled('day')) {
            $startDate = Carbon::parse($request->get('day'))->startOfDay();
            $endDate = (clone $startDate)->endOfDay();
        }

        $range = 'Desde ' . $startDate->format('d/m/Y') . ' hasta ' . $endDate->format('d/m/Y');
        $date = ['from' => $startDate, 'to' => $endDate];

        $appointments = LeadAppointment::countByQuery($date, $employee, $request)
            ->with('lead')
            ->get();

        return [
            'employee' => $employee,
            'range' => $range,
            'items' => $appointments,
        ];
    }
}
