<?php

namespace App\Http\Controllers\Api;

use App\Comment;
use App\Employee;
use App\Enums\LeadProcess;
use App\Http\Controllers\Controller;
use App\Lead;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ChartLeadController extends Controller
{
    public function counters(Request $request)
    {
        $employee = Auth::user()->employee;
        $leads = Lead::query()
            ->rangeDate($request, 'created_at')
            ->when($request->filled('assessor_id'), function (Builder $query) use ($request) {
                $query->whereAssessorId($request->get('assessor_id'));
            })
            ->when($employee->type == 6, function ($query) use ($employee) {
                $query->whereIn('assessor_id', $employee->supervise);
            });

        $comments = Comment::query()
            ->rangeDate($request, 'created_at')
            ->when($request->filled('assessor_id'), function (Builder $query) use ($request) {
                $query->byEmployee(Employee::find($request->get('assessor_id')));
            })
            ->when($employee->type == 6, function ($query) use ($employee) {
                $usersIds = Employee::query()->whereIn('id', $employee->supervise)->pluck('user_id')->toArray();
                $query->whereIn('user_id', $usersIds);
            })
            ->whereNotNull('actions')
            ->get();

        $actionsCount = 0;
        foreach ($comments as $comment) {
            $actionsCount += count($comment->actions);
        }

        return [
            ['name' => 'Leads Creados', 'total' => $leads->count()],
            ['name' => 'Acciones', 'total' => $actionsCount],
        ];
    }

    public function leadsActions(Request $request)
    {
        $employee = Auth::user()->employee;
        $employees = Employee::query()
            ->whereIn('type', [12, 13])
            ->select(['id', 'name', 'user_id'])
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->whereId($request->get('assessor_id'));
            })
            ->when($employee->type == 6, function ($query) use ($employee) {
                $query->whereIn('id', $employee->supervise);
            })
            ->get();
        $labels = $leads = $actions = [];

        foreach ($employees as $employee) {
            $labels[] = ucwords(strtolower($employee->name));
            $leads[] = Lead::query()->rangeDate($request)->whereAssessorId($employee->id)->count();
            $comments = Comment::query()->rangeDate($request)->where('user_id', $employee->user_id)->whereNotNull('actions')->get();

            $commentsCount = 0;
            foreach ($comments as $comment) {
                $commentsCount += count($comment->actions);
            }
            $actions[] = $commentsCount;
        }

        return [
            'labels' => $labels,
            'leads' => $leads,
            'actions' => $actions,
        ];
    }

    public function tableLeadsActions(Request $request)
    {
        $data = [];
        $employee = Auth::user()->employee;
        $employees = Employee::query()
            ->whereIn('type', [12, 13])
            ->select(['id', 'name', 'user_id'])
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('id', $request->get('assessor_id'));
            })
            ->when($employee->type == 6, function ($query) use ($employee) {
                $query->whereIn('id', $employee->supervise);
            })
            ->get();

        foreach ($employees as $employee) {
            $leadsBaseQuery = Lead::query()->rangeDate($request)->byAssessor($employee);
            $commentsBaseQuery = Comment::query()->rangeDate($request)->byEmployee($employee);

            $leadsWin = (clone $leadsBaseQuery)->byProcess(3)->count();
            $leadsInProgress = (clone $leadsBaseQuery)->whereIn('stage_id', [2, 3, 4])->count();
            $productivity = number_format($leadsWin / ($leadsInProgress === 0 ? 1 : $leadsInProgress) * 100, 2);

            $totalCount = 0;
            $comments = (clone $commentsBaseQuery)->whereNotNull('actions')->get();
            foreach ($comments as $comment) {
                $totalCount += count($comment->actions);
            }

            $data[] = [
                'id' => $employee->id,
                'name' => ucwords(strtolower($employee->name)),
                'call_success' => (clone $commentsBaseQuery)->withAction(1)->count(),
                'call_fail' => (clone $commentsBaseQuery)->withAction(2)->count(),
                'email' => (clone $commentsBaseQuery)->withAction(3)->count(),
                'meeting1' => (clone $commentsBaseQuery)->withAction(4)->count(),
                'meeting2' => (clone $commentsBaseQuery)->withAction(5)->count(),
                'meeting3' => (clone $commentsBaseQuery)->withAction(6)->count(),
                'total' => $totalCount,
                'created' => (clone $leadsBaseQuery)->count(),
                'pending' => (clone $leadsBaseQuery)->byProcess(1)->count(),
                'success' => (clone $leadsBaseQuery)->byProcess(3)->count(),
                'total_pen' => (float)(clone $leadsBaseQuery)->byProcess(3)->byCurrency('PEN')->sum('amount'),
                'total_usd' => (float)(clone $leadsBaseQuery)->byProcess(3)->byCurrency('USD')->sum('amount'),
                'productivity' => $productivity,
                'ratio_pen' => number_format((clone $leadsBaseQuery)->byProcess(3)->byCurrency('PEN')->avg('amount'), 2),
                'ratio_usd' => number_format((clone $leadsBaseQuery)->byProcess(3)->byCurrency('USD')->avg('amount'), 2)
            ];
        }

        return $data;
    }

    public function actions(Request $request)
    {
        return Comment::query()->rangeDate($request)
            ->with('user:id,name', 'commentable:id,name')
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $employee = Employee::find($request->get('assessor_id'));
                $query->where('user_id', $employee->user_id);
            })
            ->when($request->get('action', 0) > 0, function ($query) use ($request) {
                $query->whereJsonContains('actions', $request->action);
            })
            ->whereNotNull('actions')
            ->take(100)
            ->get();
    }

    public function index(Request $request)
    {
        return Lead::query()
            ->rangeDate($request)
            ->with('assessor:id,name')
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->get('assessor_id'));
            })
            ->when($request->get('process_id', 0) > 0, function ($query) use ($request) {
                $query->where('process_id', $request->get('process_id'));
            })
            ->get();
    }

    public function ratios(Request $request)
    {
        $employee = Auth::user()->employee;
        $leadsBaseQuery = Lead::query()
            ->when($request->filled('assessor_id'), function (Builder $query) use ($request) {
                $query->whereAssessorId($request->get('assessor_id'));
            })
            ->when($employee->type == 6, function ($query) use ($employee) {
                $query->whereIn('assessor_id', $employee->supervise);
            })
            ->rangeDate($request);

        $leadsWin = (clone $leadsBaseQuery)->byProcess(LeadProcess::Success)->count();
        $leadsInProgress = (clone $leadsBaseQuery)->whereIn('stage_id', [2, 3, 4])->count();
        $productivity = number_format($leadsWin / ($leadsInProgress === 0 ? 1 : $leadsInProgress) * 100, 2);

        Log::debug('global productivity calculate', [
            'win' => $leadsWin,
            'in_progress' => $leadsInProgress,
            'total' => $productivity
        ]);

        $leadsAvgPen = round((clone $leadsBaseQuery)->byProcess(3)->whereCurrency('PEN')->avg('amount'), 2);
        $leadsAvgUsd = round((clone $leadsBaseQuery)->byProcess(3)->whereCurrency('USD')->avg('amount'), 2);

        return [
            ['name' => 'Ratio Global de Efectividad (%)', 'total' => $productivity],
            ['name' => 'Ratio Global de Prima (PEN)', 'total' => $leadsAvgPen],
            ['name' => 'Ratio Global de Prima (USD)', 'total' => $leadsAvgUsd],
        ];
    }
}
