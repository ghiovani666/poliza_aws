<?php

namespace App\Http\Controllers\Api;

use App\CommentAction;
use App\Http\Controllers\Controller;
use App\Lead;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CommentActionController extends Controller
{
    /**
     *
     * @param Request $request
     * @return JsonResource
     */
    public function index(Request $request)
    {
        $actions = CommentAction::all();

        return new JsonResource($actions);
    }
}
