<?php

namespace App\Http\Controllers\Api;

use App\Appointment;
use App\Employee;
use App\Events\AppointmentCreatedEvent;
use App\Http\Controllers\Controller;
use App\LeadAppointment;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class CalendarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return ResourceCollection
     */
    public function index()
    {
        $employee = Auth::user()->employee;
        $appointments = Appointment::query()
            ->when($employee->type != 8 && $employee->type != 6, function ($query) {
                $query->where('user_id', Auth::id());
            })
            ->when($employee->type === 6, function ($query) use ($employee) {
                if (is_null($employee->supervise)) {
                    $employee->supervise = [];
                }
                $users = Employee::query()->whereIn('id', $employee->supervise)->pluck('user_id')->toArray();
                $query->whereIn('user_id', $users);
            })
            ->get();

        return $appointments;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return void
     * @throws ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'subject' => 'required',
            'date' => 'required',
            'from' => 'required',
            'to' => 'required',
        ]);

        $appointment = new Appointment();
        $appointment->fill($request->all());
        $appointment->user_id = Auth::id();
        $appointment->status = 1;
        $appointment->save();

        event(new AppointmentCreatedEvent($appointment, Auth::user()));
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return JsonResource
     */
    public function show($id)
    {
        $appointment = Appointment::query()
            ->with('user')
            ->where('id', $id)
            ->first();

        return new JsonResource($appointment);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return void
     * @throws ValidationException
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'subject' => 'required',
            'date' => 'required',
            'from' => 'required',
            'to' => 'required',
        ]);

        $appointment = Appointment::find($id);
        $appointment->fill($request->all());
        $appointment->user_id = Auth::id();
        $appointment->status = 1;
        $appointment->save();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function leadAppointment()
    {
        $data = [];

        /** @var Employee $employee */
        $employee = Auth::user()->employee;

        $users = Employee::query()->whereIn('id', $employee->hierarchy())->pluck('user_id')->toArray();

        $appointments = LeadAppointment::query()
            ->with('lead')
            ->whereIn('user_id', $users)
            ->get();

        foreach ($appointments as $appointment) {
            try {
                /** @var LeadAppointment $appointment */
                $data[] = [
                    'id' => $appointment->id,
                    'title' => $appointment->lead->name,
                    'start' => $appointment->date->toDateTimeString(),
                    'url' => route('leads.show', $appointment->lead_id),
                    'editable' => false,
                    'backgroundColor' => $appointment->getCalendarBackgroundColor(),
                    'borderColor' => $appointment->getCalendarBorderColor(),
                    'textColor' => $appointment->getCalendarTextColor(),
                ];
            } catch (Exception $exception) {
                report($exception);
                Log::debug('Lead appointment without lead', $appointment->toArray());
            }
        }

        return $data;
    }
}
