<?php

namespace App\Http\Controllers;

use App\Company;
use App\Sector;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;

class SectorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @param Company $company
     * @return Response
     */
    public function index(Request $request, Company $company)
    {
        $sectors = Sector::query()
            ->where('company_id', $company->id)
            ->withCount('products')
            ->orderByDesc('id')
            ->paginate();

        return view('companies.sectors.index', compact('company', 'sectors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Company $company
     * @param Sector $sector
     * @return Response
     */
    public function create(Company $company, Sector $sector)
    {
        return view('companies.sectors.create', compact('company', 'sector'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @param Company $company
     * @return Response
     * @throws ValidationException
     */
    public function store(Request $request, Company $company)
    {
        $this->validate($request, ['name' => 'required']);

        $sector = new Sector();
        $sector->fill($request->all());
        $company->sectors()->save($sector);

        flash('Nueva rama registrada correctamente')->success()->important();

        return redirect()->route('companies.sectors.index', [$company]);
    }

    /**
     * Display the specified resource.
     *
     * @param Sector $sector
     * @return Response
     */
    public function show(Sector $sector)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Company $company
     * @param Sector $sector
     * @return Response
     */
    public function edit(Company $company, Sector $sector)
    {
        return view('companies.sectors.edit', compact('company', 'sector'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Company $company
     * @param Sector $sector
     * @return void
     * @throws ValidationException
     */
    public function update(Request $request, Company $company, Sector $sector)
    {
        $this->validate($request, ['name' => 'required']);

        $sector->fill($request->all());
        $sector->save();

        flash('Rama actualizada correctamente')->success()->important();

        return redirect()->route('companies.sectors.index', [$company]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Company $company
     * @param Sector $sector
     * @return void
     * @throws Exception
     */
    public function destroy(Company $company, Sector $sector)
    {
        $sector->delete();

        flash('Rama eliminada correctamente')->success()->important();

        return redirect()->route('companies.sectors.index', [$company]);
    }
}
