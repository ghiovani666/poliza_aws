<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function edit()
    {
        $user = Auth::user();
        $employee = Employee::query()->where('user_id', $user->id)->first();

        return view('profile.edit', compact('user', 'employee'));
    }

    public function update(Request $request)
    {
        $user = Auth::user();
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|unique:users,email,' . $user->id,
            'password' => 'confirmed'
        ]);

        $employee = Employee::query()->where('user_id', $user->id)->first();
        $employee->fill($request->except(['password', 'password_confirmation']));
        $employee->save();

        $user->fill($request->except(['password', 'password_confirmation']));

        if ($request->filled('password')) {
            $user->password = bcrypt($request->get('password'));
        }

        $user->save();

        flash('Perfil actualizado correctamente.')->success()->important();

        return redirect()->route('profile.edit');
    }
}
