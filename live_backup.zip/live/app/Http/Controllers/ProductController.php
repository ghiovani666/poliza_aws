<?php

namespace App\Http\Controllers;

use App\Company;
use App\Product;
use App\Sector;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Company $company
     * @param Sector $sector
     * @return Response
     */
    public function index(Company $company, Sector $sector)
    {
        $products = Product::query()
            ->where('sector_id', $sector->id)
            ->orderByDesc('id')
            ->paginate();

        return view('companies.sectors.products.index', compact('company', 'sector', 'products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Company $company
     * @param Sector $sector
     * @return Response
     */
    public function create(Company $company, Sector $sector)
    {
        return view('companies.sectors.products.create', compact('company', 'sector'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @param Company $company
     * @param Sector $sector
     * @return void
     * @throws ValidationException
     */
    public function store(Request $request, Company $company, Sector $sector)
    {
        $this->validate($request, ['name' => 'required', 'commission' => 'required|numeric']);

        $product = new Product();
        $product->fill($request->all());
        $sector->products()->save($product);

        flash('Nuevo producto agregado correctamente.')->success()->important();

        return redirect()->route('companies.sectors.products.index', [$company, $sector]);
    }

    /**
     * Display the specified resource.
     *
     * @param Product $product
     * @return Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Company $company
     * @param Sector $sector
     * @param Product $product
     * @return Response
     */
    public function edit(Company $company, Sector $sector, Product $product)
    {
        return view('companies.sectors.products.edit', compact('company', 'sector', 'product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Company $company
     * @param Sector $sector
     * @param Product $product
     * @return void
     * @throws ValidationException
     */
    public function update(Request $request, Company $company, Sector $sector, Product $product)
    {
        $this->validate($request, ['name' => 'required', 'commission' => 'required']);

        $product->fill($request->all());
        $product->save();

        flash('Producto actualizado correctamente.')->success()->important();

        return redirect()->route('companies.sectors.products.index', [$company, $sector]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Company $company
     * @param Sector $sector
     * @param Product $product
     * @return void
     * @throws Exception
     */
    public function destroy(Company $company, Sector $sector, Product $product)
    {
        $product->delete();

        flash('Producto eliminado correctamente.')->success()->important();

        return redirect()->route('companies.sectors.products.index', [$company, $sector]);
    }
}
