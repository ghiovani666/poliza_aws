<?php

namespace App\Http\Controllers;

use App\PaymentDelayedImportLog;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PaymentDelayedImportLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        $logs = PaymentDelayedImportLog::query()
            ->where('failed', 1)
            ->orderByDesc('id')
            ->paginate();

        return view('payment_delayed.logs.index', compact('logs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param PaymentDelayedImportLog $paymentDelayedImportLog
     * @return Response
     */
    public function show(PaymentDelayedImportLog $paymentDelayedImportLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param PaymentDelayedImportLog $paymentDelayedImportLog
     * @return Response
     */
    public function edit(PaymentDelayedImportLog $paymentDelayedImportLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param PaymentDelayedImportLog $paymentDelayedImportLog
     * @return Response
     */
    public function update(Request $request, PaymentDelayedImportLog $paymentDelayedImportLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PaymentDelayedImportLog $paymentDelayedImportLog
     * @return Response
     */
    public function destroy(PaymentDelayedImportLog $paymentDelayedImportLog)
    {
        //
    }
}
