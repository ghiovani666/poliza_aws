<?php

namespace App\Http\Controllers;

use App\Policy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SurveyController extends Controller
{
    public function index(Request $request)
    {
        $policies = Policy::query()
            ->with(['status', 'customer', 'assessor'])
            ->leftJoin('customers', 'customers.id', '=', 'policies.customer_id')
            ->select('policies.*', 'customers.name', 'customers.document_number')
            ->when($request->has('customer'), function (Builder $query) use ($request) {
                $query->where('customers.name', 'like', "%{$request->customer}%");
            })
            ->when($request->has('code') && !is_null($request->code), function ($query) use ($request) {
                $query->where('code', 'like', "%{$request->code}%");
            })
            ->when($request->has('survey_answered') && !is_null($request->survey_answered), function ($query) use ($request) {
                $query->where('survey_answered', (int)$request->survey_answered);
            })
            ->when(Auth::user()->isAssessor, function ($query) {
                $query->where('assessor_id', Auth::user()->employee->id);
            })
            ->orderByDesc('id')
            ->paginate();

        return view('surveys.index', compact('policies'));
    }

    public function show(Policy $policy)
    {
        return view('surveys.show', compact('policy'));
    }

    public function update(Policy $policy, Request $request)
    {
        $policy->survey_editable = false;
        $policy->survey_answered = true;
        $policy->save();

        $answers = $request->get('answer');
        foreach (surveys() as $index => $survey) {
            $policy->surveys()->attach($survey->id, ['answer' => $answers[$index]]);
        }

        flash('Encuesta actualizada correctamente.')->success()->important();

        return redirect()->route('surveys.index');
    }
}
