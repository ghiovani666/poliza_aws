<?php

namespace App\Http\Controllers;

use App\Paying;
use App\PayingItem;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;

class PayingItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param PayingItem $payingItem
     * @return Response
     */
    public function show(PayingItem $payingItem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Paying $paying
     * @param PayingItem $item
     * @return Response
     */
    public function edit(Paying $paying, PayingItem $item)
    {
        return view('payings.items.edit', compact('paying', 'item'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Paying $paying
     * @param PayingItem $item
     * @return void
     * @throws ValidationException
     */
    public function update(Request $request, Paying $paying, PayingItem $item)
    {
        $this->validate($request, []);

        $item->fill($request->all());
        $item->save();

        $paying->calculateAmount();
        $paying->calculateRange();
        $paying->save();

        flash('Articulo en liquidacion atualizado correctamente.')->success()->important();

        return redirect()->route('payings.show', $paying);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PayingItem $payingItem
     * @return Response
     */
    public function destroy(PayingItem $payingItem)
    {
        //
    }
}
