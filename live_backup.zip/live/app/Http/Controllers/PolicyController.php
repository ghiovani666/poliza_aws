<?php

namespace App\Http\Controllers;

use App\Company;
use App\Customer;
use App\Employee;
use App\Exports\PoliciesExport;
use App\Http\Requests\PolicyStoreRequest;
use App\Http\Requests\PolicyUpdateRequest;
use App\Policy;
use App\Product;
use App\Sector;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PolicyController extends Controller
{
    /**
     * @var Customer
     */
    private $customer;
    /**
     * @var Policy
     */
    private $policy;

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $policies = Policy::fetchAll(Auth::user()->employee, $request)
            ->orderByDesc('id')
            ->paginate();

        return view('policies.index', compact('policies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $companies = [null => '- Seleccionar -'] + Company::query()->orderBy('name')->pluck('name', 'id')->toArray();
        $employees = Employee::query()->orderBy('name')->pluck('name', 'id');

        return view('policies.create', compact('companies', 'employees'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyStoreRequest $request
     * @return Response
     */
    public function store(PolicyStoreRequest $request)
    {
        if ($request->refresh == 1) {
            return $this->addCustomer($request);
        }

        if ($request->refresh == 9) {
            return $this->cleanCustomer($request);
        }

        $this->saveCustomer($request);
        $this->savePolicy($request);

        return redirect()->route('policies.documents.index', $this->policy);
    }

    private function addCustomer($request)
    {
        $customer = Customer::find($request->customer_id);

        $data = $request->all();
        $data['name'] = $customer->name;
        $data['phone'] = $customer->phone;
        $data['email'] = $customer->email;
        $data['document_type'] = $customer->document_type;
        $data['document_number'] = $customer->document_number;
        $data['birth_date'] = is_null($customer->birth_date) ? null : $customer->birth_date->format('Y-m-d');
        $data['address'] = $customer->address;
        $data['state'] = $customer->state;
        $data['province'] = $customer->province;
        $data['city'] = $customer->city;

        return redirect()->back()->withInput($data);
    }

    private function cleanCustomer($request)
    {
        $data = $request->all();
        $data['name'] = '';
        $data['phone'] = '';
        $data['email'] = '';
        $data['document_type'] = '';
        $data['document_number'] = '';
        $data['birth_date'] = '';
        $data['address'] = '';
        $data['state'] = '';
        $data['province'] = '';
        $data['city'] = '';

        return redirect()->back()->withInput($data);
    }

    private function saveCustomer(Request $request)
    {
        if ($request->customer_id == 0) {
            $customer = new Customer();
        } else {
            $customer = Customer::find($request->customer_id);
        }

        $customer->name = $request->get('name');
        $customer->phone = $request->get('phone');
        $customer->email = $request->get('email');
        $customer->document_type = $request->get('document_type');
        $customer->document_number = $request->get('document_number');
        $customer->birth_date = $request->get('birth_date');
        $customer->address = $request->get('address');
        $customer->state = $request->get('state');
        $customer->province = $request->get('province');
        $customer->city = $request->get('city');
        $customer->save();

        $this->customer = $customer;
    }

    /**
     * @param Request $request
     * @param Policy|null $policy
     */
    private function savePolicy(Request $request, $policy = null)
    {
        if (is_null($policy)) {
            $policy = new Policy();
        }
        $policy->fill($request->except(['name', 'phone', 'email', 'document_type', 'document_number', 'state', 'province', 'city', 'birth_date', 'address', 'refresh', 'return']));
        $policy->customer_id = $this->customer->id;
        $policy->commission_percentage = (int)$request->commission_percentage; // prevent error for empty value
        $policy->user_id = auth()->id();
        $policy->user_id = auth()->id();
        $policy->save();

        $this->policy = $policy;
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function show(Policy $policy)
    {
        return view('policies.show', compact('policy', 'helper'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function edit(Policy $policy)
    {
        $customers = Customer::query()->orderBy('name')->pluck('name', 'id');
        $customers = [0 => 'Nuevo Cliente'] + $customers->toArray();
        $companies = [null => '- Seleccionar -'] + Company::query()->orderBy('name')->pluck('name', 'id')->toArray();
        $sectors = Sector::query()->where('company_id', $policy->company_id)->orderBy('name')->pluck('name', 'id');
        $productsQuery = Product::query()->where('sector_id', $policy->sector_id)->orderBy('name');
        $productsResource = $productsQuery->get();
        $products = $productsQuery->pluck('name', 'id');
        $employees = Employee::query()->orderBy('name')->pluck('name', 'id');

        $customer = $policy->customer;
        $data = $policy->toArray() + $customer->toArray();

        if ($customer->hasBirthDate) {
            $data['birth_date'] = $customer->birth_date->format('Y-m-d');
        }


        return view('policies.edit', compact('data', 'policy', 'customers', 'companies', 'employees', 'sectors', 'products', 'productsResource'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyUpdateRequest $request
     * @param Policy $policy
     * @return Response
     */
    public function update(PolicyUpdateRequest $request, Policy $policy)
    {
        if ($request->refresh == 1) {
            return $this->addCustomer($request);
        }

        if ($request->refresh == 9) {
            return $this->cleanCustomer($request);
        }

        try {
            DB::beginTransaction();

            $this->saveCustomer($request);
            $this->savePolicy($request, $policy);

            // save cancellation date
            if ($policy->operation_status == 8) {
                $policy->cancellation_date = (Carbon::now())->toDateString();
                $policy->save();
            }

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();
        }

        flash('Poliza actualizada correctamente.')->success();

        if ($request->filled('return')) {
            return redirect()->route($request->get('return') . '.index');
        }

        return redirect()->route('policies.documents.index', $policy);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @return void
     * @throws Exception
     */
    public function destroy(Policy $policy)
    {
        $policy->delete();

        flash('Poliza eiminada correctamente.')->success();

        return redirect()->route('policies.index');
    }

    public function renew(Policy $policy)
    {
        // update current policy
        $policy->active = false;
        $policy->save();

        // create new
        $new = $policy->replicate();
        $new->active = true;
        $new->sell_type = 3;
        $new->operation_status = 5;
        $new->renew_id = $policy->id;
        $new->renew_count = $policy->renew_count + 1;
        $new->requested_date = Carbon::now();
        $new->validity_date = Carbon::now();
        $new->renewal_date = (Carbon::now())->addMonths($new->period);
        $new->save();

        flash('Poliza renovada correctamente.')->success();

        return redirect()->route('policies.index');
    }

    public function export()
    {
        return Excel::download(new PoliciesExport(), 'Polizas.xlsx');
    }

    public function print(Policy $policy)
    {
        return view('policies.print', compact('policy'));
    }
}
