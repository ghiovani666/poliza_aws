<?php

namespace App\Http\Controllers;

use App\Policy;

class SettingController extends Controller
{
    public function index()
    {
        $policies = Policy::query()->onlyTrashed()->get();

        return view('settings.index', compact('policies'));
    }

    public function restore($id)
    {
        Policy::withTrashed()->where('id', $id)->restore();

        return redirect()->route('settings.index');
    }
}
