<?php

namespace App\Http\Controllers;

use App\Http\Requests\PolicyVehicleStoreRequest;
use App\Http\Requests\PolicyVehicleUpdateRequest;
use App\Imports\PolicyVehiclesImport;
use App\Policy;
use App\PolicyVehicle;
use App\VehicleType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PolicyVehicleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function index(Policy $policy)
    {
        $vehicles = $policy->vehicles()->orderByDesc('id')->paginate();
        $vehicleTypes = VehicleType::query()->orderBy('name')->pluck('name', 'id');

        return view('policies.vehicles.index', compact('policy', 'vehicles', 'vehicleTypes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function create(Policy $policy)
    {
        return view('policies.vehicles.create', compact('policy'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyVehicleStoreRequest $request
     * @param Policy $policy
     * @param PolicyVehicle $vehicle
     * @return void
     */
    public function store(PolicyVehicleStoreRequest $request, Policy $policy, PolicyVehicle $vehicle)
    {
        $vehicle = new PolicyVehicle();
        $vehicle->fill($request->all());
        $policy->vehicles()->save($vehicle);

        flash('Vehiculo registrado correctamente.')->success();

        return redirect()->to(route('policies.vehicles.index', $policy) . '#vehicles');
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @param PolicyVehicle $vehicle
     * @return Response
     */
    public function show(Policy $policy, PolicyVehicle $vehicle)
    {
        return view('policies.vehicles.show', compact('policy', 'vehicle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param PolicyVehicle $vehicle
     * @return Response
     */
    public function edit(Policy $policy, PolicyVehicle $vehicle)
    {
        return view('policies.vehicles.edit', compact('policy', 'vehicle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyVehicleUpdateRequest $request
     * @param Policy $policy
     * @param PolicyVehicle $vehicle
     * @return void
     */
    public function update(PolicyVehicleUpdateRequest $request, Policy $policy, PolicyVehicle $vehicle)
    {
        $vehicle->fill($request->all());
        $vehicle->save();

        flash('Vehiculo actualizaco correctamente')->success();

        return redirect()->to(route('policies.vehicles.index', $policy) . '#vehicles');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @param PolicyVehicle $vehicle
     * @return void
     * @throws Exception
     */
    public function destroy(Policy $policy, PolicyVehicle $vehicle)
    {
        $vehicle->delete();

        flash('Vehiculo eliminado correctamente')->success();

        return redirect()->to(route('policies.vehicles.index', $policy) . '#vehicles');
    }

    public function import(Request $request, Policy $policy)
    {
        try {
            DB::beginTransaction();
            // store
            $filePath = $request->file('file')->store('imports');

            // import
            Excel::import(new PolicyVehiclesImport($policy), $filePath);

            flash('Archivo importado correctamente.')->success();

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();

            flash($exception->getMessage())->error();
        }

        return redirect()->to(route('policies.vehicles.index', $policy) . '#vehicles');
    }
}
