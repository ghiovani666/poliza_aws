<?php

namespace App\Http\Controllers;

use App\PaymentCollection;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PaymentCollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $paymentCollections = PaymentCollection::query()
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->get('status'));
            })
            ->where('enabled', true)
            ->orderByDesc('id')
            ->paginate();

        $cboStatus = ['' => '-Todos-'] + dropdownData('PaymentCollectionStatuses');

        return view('payment_collections.index', compact('paymentCollections', 'cboStatus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('payment_collections.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate(['customer_id' => 'required']);

        $paymentCollection = new PaymentCollection();
        $paymentCollection->fill($request->all());
        $paymentCollection->user_id = Auth::id();
        $paymentCollection->save();

        flash('Nuevo cobro registrado correctamente.')->success()->important();

        return redirect()->route('payment_collections.index');
    }

    /**
     * Display the specified resource.
     *
     * @param PaymentCollection $paymentCollection
     * @return Response
     */
    public function show(PaymentCollection $paymentCollection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param PaymentCollection $paymentCollection
     * @return Response
     */
    public function edit(PaymentCollection $paymentCollection)
    {
        return view('payment_collections.edit', compact('paymentCollection'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param PaymentCollection $paymentCollection
     * @return Response
     */
    public function update(Request $request, PaymentCollection $paymentCollection)
    {
        $request->validate(['customer_id' => 'required']);

        $paymentCollection->fill($request->all());
        $paymentCollection->save();

        flash('Cobro registrado correctamente.')->success()->important();

        return redirect()->route('payment_collections.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PaymentCollection $paymentCollection
     * @return Response
     * @throws Exception
     */
    public function destroy(PaymentCollection $paymentCollection)
    {
        $paymentCollection->delete();

        flash('Cobro eliminado correctamente.')->success()->important();

        return redirect()->route('payment_collections.index');
    }

    public function disabled(Request $request)
    {
        $paymentCollections = PaymentCollection::query()
            ->with(['customer', 'assessor'])
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->where('enabled', false)
            ->orderByDesc('id')
            ->paginate();

        return view('payment_collections.disabled', compact('paymentCollections'));
    }

    public function disable(PaymentCollection $paymentCollection)
    {
        $this->authorize('disable', $paymentCollection);

        $paymentCollection->enabled = false;
        $paymentCollection->save();

        flash('Via cobro eliminado correctamente')->success()->important();

        return redirect()->route('payment_collections.index');
    }
}
