<?php

namespace App\Http\Controllers;

use App\Http\Requests\PolicyBeneficiaryStoreRequest;
use App\Http\Requests\PolicyBeneficiaryUpdateRequest;
use App\Imports\PolicyBeneficiariesImport;
use App\Imports\PolicyDocumentsImport;
use App\Policy;
use App\PolicyBeneficiary;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PolicyBeneficiaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Policy $policy
     * @return void
     */
    public function index(Policy $policy)
    {
        $beneficiaries = $policy->beneficiaries()->paginate();

        return view('policies.beneficiaries.index', compact('policy', 'beneficiaries'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function create(Policy $policy)
    {
        $documentTypes = [
            1 => 'DNI',
            2 => 'RUC',
            3 => 'Pasaporte'
        ];

        return view('policies.beneficiaries.create', compact('policy', 'documentTypes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyBeneficiaryStoreRequest $request
     * @param Policy $policy
     * @return Response
     */
    public function store(PolicyBeneficiaryStoreRequest $request, Policy $policy)
    {
        $beneficiary = new PolicyBeneficiary();
        $beneficiary->fill($request->all());
        $policy->beneficiaries()->save($beneficiary);

        flash('Beneficiario registrado correctamente.')->success();

        return redirect()->to(route('policies.beneficiaries.index', $policy) . '#beneficiaries');
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @param PolicyBeneficiary $beneficiary
     * @return Response
     */
    public function show(Policy $policy, PolicyBeneficiary $beneficiary)
    {
        return view('policies.beneficiaries.show', compact('policy', 'beneficiary'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param PolicyBeneficiary $beneficiary
     * @return Response
     */
    public function edit(Policy $policy, PolicyBeneficiary $beneficiary)
    {
        return view('policies.beneficiaries.edit', compact('policy', 'beneficiary'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyBeneficiaryUpdateRequest $request
     * @param Policy $policy
     * @param PolicyBeneficiary $beneficiary
     * @return Response
     */
    public function update(PolicyBeneficiaryUpdateRequest $request, Policy $policy, PolicyBeneficiary $beneficiary)
    {
        $beneficiary->fill($request->all());
        $beneficiary->save();

        flash('Beneficiario actualizaco correctamente.')->success();

        return redirect()->to(route('policies.beneficiaries.index', $policy) . '#beneficiaries');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @param PolicyBeneficiary $beneficiary
     * @return void
     * @throws Exception
     */
    public function destroy(Policy $policy, PolicyBeneficiary $beneficiary)
    {
        $beneficiary->delete();

        flash('Beneficiario eliminado correctamente.')->success();

        return redirect()->to(route('policies.beneficiaries.index', $policy) . '#beneficiaries');
    }

    public function import(Request $request, Policy $policy)
    {
        try {
            DB::beginTransaction();
            // store
            $filePath = $request->file('file')->store('imports');

            // import
            Excel::import(new PolicyBeneficiariesImport($policy), $filePath);

            flash('Archivo importado correctamente.')->success();

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();

            flash($exception->getMessage())->error();
        }

        return redirect()->to(route('policies.beneficiaries.index', $policy) . '#beneficiaries');
    }
}
