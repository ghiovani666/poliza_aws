<?php

namespace App\Http\Controllers;

use App\Company;
use App\Imports\PaymentDelayedImport;
use App\PaymentDelayed;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PaymentDelayedController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $paymentDelayeds = PaymentDelayed::query()
            ->when($request->filled('company_id'), function ($query) use ($request) {
                $query->where('company_id', $request->get('company_id'));
            })
            ->when($request->filled('customer_id'), function ($query) use ($request) {
                $query->where('customer_id', $request->get('customer_id'));
            })
            ->when($request->filled('policy_id'), function ($query) use ($request) {
                $query->where('policy_id', $request->get('policy_id'));
            })
            ->when(Auth::user()->isAssessor, function ($query) {
                $query->where('assessor_id', Auth::user()->employee->id);
            })
            ->orderByDesc('id')
            ->paginate();

        return view('payment_delayed.index', compact('paymentDelayeds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            // get company
            $company = Company::find($request->company_id);

            // clean all records for this company
            PaymentDelayed::query()->where('company_id', $company->id)->delete();

            // store
            $filePath = $request->file('file')->store('imports');

            // import
            $import = new PaymentDelayedImport($company);
            Excel::import($import, $filePath);
            $countRowsOk = $import->rowSuccess;
            $countRowsBad = $import->rowFail;

            flash('Arhivo importado correctamnete.<br><strong>' . $countRowsOk . '</strong> registros importados correctamente.<br><strong>' . $countRowsBad . '</strong> registros no procesados.')->success()->important();

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();

            flash($exception->getMessage())->error();
        }

        return redirect()->route('payment_delayeds.index');
    }

    /**
     * Display the specified resource.
     *
     * @param PaymentDelayed $paymentDelayed
     * @return Response
     */
    public function show(PaymentDelayed $paymentDelayed)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param PaymentDelayed $paymentDelayed
     * @return Response
     */
    public function edit(PaymentDelayed $paymentDelayed)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param PaymentDelayed $paymentDelayed
     * @return Response
     */
    public function update(Request $request, PaymentDelayed $paymentDelayed)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PaymentDelayed $paymentDelayed
     * @return Response
     */
    public function destroy(PaymentDelayed $paymentDelayed)
    {
        //
    }
}
