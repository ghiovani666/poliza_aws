<?php

namespace App\Http\Controllers;

use App\Claim;
use App\ClaimFile;
use App\Policy;
use App\Company;
use App\Employee;
use App\Exports\ClaimsAllExport;
use App\Exports\ClaimsExport;
use App\Http\Requests\PolicyStoreRequest;
use App\Http\Requests\PolicyUpdateRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Exception;

class ClaimController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Policy $policy, Request $request)
    {
        $claims = Claim::fetchAll($policy, $request)
            ->orderByDesc('id')
            ->paginate();

        return view('policies.claims.index', compact('claims', 'policy'));
    }

    /**
     * Display the specified resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function show(Policy $policy)
    {
        return view('policies.show', compact('policy', 'helper'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create(Policy $policy)
    {
        $companies = [null => '- Seleccionar -'] + Company::query()->orderBy('name')->pluck('name', 'id')->toArray();
        $employees = Employee::query()->orderBy('name')->pluck('name', 'id');
        return view('policies.claims.create', compact('companies', 'employees', 'policy'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param Claim $claim
     * @return Response
     */
    public function edit(Policy $policy, Claim $claim)
    {
        return view('policies.claims.edit', compact('policy', 'claim'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PolicyStoreRequest $request
     * @return Response
     */
    public function store(Request $request, Policy $policy) // Request $request
    {
        // var_dump($request->allFiles()); exit;
        $claim = $this->saveClaim($request);
        if ($request->file("files")) {
            foreach ($request->allFiles()["files"] as $file) {
                $fileName = uniqid(date('Ymdhisu')) . "." . $file->extension();
                $basePath = __DIR__ . "../../../../public";
                $filePath = "/uploads/policies/claims/{$fileName}";
                file_put_contents($basePath . $filePath, file_get_contents($file->path()));
                $claimFile = new ClaimFile();
                $claimFile->claim_id = $claim->id;
                $claimFile->name = $file->getClientOriginalName();
                $claimFile->size = $file->getSize();
                $claimFile->path = $filePath;
                $claimFile->save();
            }
        }
        return redirect()->route('policies.claims.index', $policy);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PolicyUpdateRequest $request
     * @param Policy $policy
     * @return Response
     */
    public function update(Request $request, Policy $policy, Claim $claim)
    {
        try {
            DB::beginTransaction();
            $this->saveClaim($request, $claim);
            DB::commit();
            flash('Reclamo actualizado correctamente.')->success();
        } catch (Exception $exception) {
            DB::rollBack();
            flash($exception->getMessage())->error();
        }
        return redirect()->route('policies.claims.index', $policy);
    }

    /**
     * @param Request $request
     * @param Policy|null $policy
     */
    private function saveClaim(Request $request, $claim = null)
    {
        if (is_null($claim)) {
            $claim = new Claim();
        }
        $claim->fill($request->except(['refresh', 'return', 'files']));
        $claim->policy_id = $request->get('policy_id');
        // $claim->customer_id = $this->customer->id;
        // $claim->commission_percentage = (int)$request->commission_percentage; // prevent error for empty value
        $claim->save();
        // $this->claim = $claim;
        return $claim;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @return void
     * @throws Exception
     */
    public function destroy(Policy $policy, Claim $claim)
    {
        $claim->delete();
        flash('Siniestro eiminado correctamente.')->success();
        return redirect()->route('policies.claims.index', $policy);
    }

    public function exportAll()
    {
        return Excel::download(new ClaimsAllExport(), 'Reclamos ' . date('Y-m-d h_m') . '.xlsx');
    }

    public function export(Policy $policy)
    {
        return Excel::download(new ClaimsExport($policy), "Reclamos (Poliza Nro. {$policy->code} [ID {$policy->id}]).xlsx");
    }
}
