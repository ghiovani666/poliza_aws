<?php

namespace App\Http\Controllers;

use App\Product;
use App\Sector;
use App\Setting;
use App\User;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @param Request $request
     * @return Renderable
     */
    public function index(Request $request)
    {
        $roleId = Auth::user()->employee->type;
        $setting = Setting::query()->where('key', 'SPREADSHEET_EMBED')->first();

        return view('home', compact('roleId','setting'));
    }

    private function years()
    {
        return [2015 => 2015, 2016 => 2016, 2017 => 2017, 2018 => 2018, 2019 => 2019, 2020 => 2020, 2021 => 2021];
    }

    private function companies()
    {
        return ['all' => '- Todas -'] + dropdownData('Companies');
    }

    private function sectors($company)
    {
        $data = Sector::query()
            ->when(is_numeric($company), function ($query) use ($company) {
                $query->where('company_id', $company);
            })
            ->orderBy('name')
            ->pluck('name', 'id')
            ->toArray();

        return ['all' => '- Todos -'] + $data;
    }

    private function products($sector)
    {
        $data = Product::query()
            ->when(is_numeric($sector), function ($query) use ($sector) {
                $query->where('sector_id', $sector);
            })
            ->orderBy('name')
            ->pluck('name', 'id')
            ->toArray();

        return ['all' => '- Todos -'] + $data;
    }
}
