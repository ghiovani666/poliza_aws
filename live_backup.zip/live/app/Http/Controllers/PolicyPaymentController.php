<?php

namespace App\Http\Controllers;

use App\PaymentDelayed;
use App\Policy;
use App\PolicyPayment;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PolicyPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Policy $policy
     * @return void
     */
    public function index(Policy $policy)
    {
        $payments = $policy->payments()
            ->orderBy('id')
            ->paginate();

        return view('policies.payments.index', compact('policy', 'payments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param PolicyPayment $policyPayment
     * @return Response
     */
    public function show(PolicyPayment $policyPayment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param PolicyPayment $policyPayment
     * @return Response
     */
    public function edit(PolicyPayment $policyPayment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param PolicyPayment $policyPayment
     * @return Response
     */
    public function update(Request $request, PolicyPayment $policyPayment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PolicyPayment $policyPayment
     * @return Response
     */
    public function destroy(PolicyPayment $policyPayment)
    {
        //
    }
}
