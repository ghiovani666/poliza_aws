<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Notifications\UserCreated;
use App\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $employees = Employee::query()
            ->when($request->filled('name'), function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->name . '%');
            })
            ->when($request->filled('email'), function ($query) use ($request) {
                $query->where('email', 'like', '%' . $request->email . '%');
            })
            ->when($request->filled('type_id'), function ($query) use ($request) {
                $query->where('type', $request->type_id);
            })
            ->orderByDesc('id')
            ->paginate();
        return view('users.index', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param User $user
     * @return Response
     */
    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param User $user
     * @return Response
     * @throws ValidationException
     */
    public function update(Request $request, User $user)
    {
        $this->validate($request, ['password' => 'required|confirmed']);

        $user->password = bcrypt($request->get('password'));
        $user->save();

        flash('Usuario actualizado correctamente.')->success()->important();

        return redirect()->route('users.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy(User $user)
    {
        $this->authorize('delete', $user);

        $user->delete();

        flash()->success('Usuario eliminado correctamente');

        return redirect()->route('users.index');
    }

    public function migrate(Employee $employee)
    {
        if ($employee->hasUser) {
            flash('El empleado ya tiene un usuario registrado.')->error()->important();
            return redirect()->back();
        }

        $password = Str::random(6);

        $user = new User();
        $user->name = $employee->name;
        $user->email = $employee->email;
        $user->remember_token = Str::random(10);
        $user->api_token = Str::random(64);
        $user->password = bcrypt($password);
        $user->markEmailAsVerified();
        $user->save();

        $employee->user_id = $user->id;
        $employee->save();

        flash('Se registro el usuario correctamente. Se le envio un correo con la contraseña: ' . $password)->success()->important();

        try {
            $user->notify(new UserCreated($password));
        } catch (Exception $exception) {
            report($exception);
            flash('Ups! No se pudo enviar el correo de notificacion.')->error()->important();
        }

        return redirect()->back();
    }
}
