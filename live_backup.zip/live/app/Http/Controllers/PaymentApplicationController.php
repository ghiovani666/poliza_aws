<?php

namespace App\Http\Controllers;

use App\PaymentApplication;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PaymentApplicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $paymentApplications = PaymentApplication::query()
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->get('status'));
            })
            ->where('enabled', true)
            ->orderByDesc('id')
            ->paginate();

        $cboStatus = ['' => '-Todos-'] + dropdownData('PaymentCollectionStatuses');

        return view('payment_applications.index', compact('paymentApplications','cboStatus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('payment_applications.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate(['customer_id' => 'required']);

        $paymentApplication = new PaymentApplication();
        $paymentApplication->user_id = Auth::id();
        $paymentApplication->fill($request->all());
        $paymentApplication->save();

        flash('Nueva aplicacion de cobro registrada correctamente.')->success()->important();

        return redirect()->route('payment_applications.index');
    }

    /**
     * Display the specified resource.
     *
     * @param PaymentApplication $paymentApplication
     * @return Response
     */
    public function show(PaymentApplication $paymentApplication)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param PaymentApplication $paymentApplication
     * @return Response
     */
    public function edit(PaymentApplication $paymentApplication)
    {
        return view('payment_applications.edit', compact('paymentApplication'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param PaymentApplication $paymentApplication
     * @return Response
     */
    public function update(Request $request, PaymentApplication $paymentApplication)
    {
        $request->validate(['customer_id' => 'required']);

        $paymentApplication->user_id = Auth::id();
        $paymentApplication->fill($request->all());
        $paymentApplication->save();

        flash('Aplicacion de pago registrada correctamente.')->success()->important();

        return redirect()->route('payment_applications.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param PaymentApplication $paymentApplication
     * @return Response
     * @throws Exception
     */
    public function destroy(PaymentApplication $paymentApplication)
    {
        $paymentApplication->delete();

        flash('Aplicacion de pago eliminada correctamente.')->success()->important();

        return redirect()->route('payment_applications.index');
    }

    public function disabled(Request $request)
    {
        $paymentApplications = PaymentApplication::query()
            ->with(['customer', 'assessor'])
            ->when($request->filled('document_number'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $number = request('document_number');
                    $query->where('document_number', 'like', "%{$number}%");
                });
            })
            ->when($request->filled('customer'), function ($query) {
                $query->whereHas('customer', function ($query) {
                    $name = request('customer');
                    $query->where('name', 'like', "%{$name}%");
                });
            })
            ->when($request->filled('dates'), function ($query) {
                $dates = explode('to', request('dates'));
                $query->whereBetween(DB::raw('date(created_at)'), [trim($dates[0]), trim($dates[1])]);
            })
            ->where('enabled', false)
            ->orderByDesc('id')
            ->paginate();

        return view('payment_applications.disabled', compact('paymentApplications'));
    }

    public function disable(PaymentApplication $paymentApplication)
    {
        $this->authorize('disable', $paymentApplication);

        $paymentApplication->enabled = false;
        $paymentApplication->save();

        flash('Aplicacion eliminada correctamente')->success()->important();

        return redirect()->route('payment_applications.index');
    }
}
