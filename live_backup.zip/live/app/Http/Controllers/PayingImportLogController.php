<?php

namespace App\Http\Controllers;

use App\PayingImportLog;
use Illuminate\Http\Request;

class PayingImportLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        $logs = PayingImportLog::query()
            ->where('failed', 1)
            ->orderByDesc('id')
            ->paginate();

        return view('payings.logs.index', compact('logs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param \App\PayingImportLog $payingImportLog
     * @return \Illuminate\Http\Response
     */
    public function show(PayingImportLog $payingImportLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\PayingImportLog $payingImportLog
     * @return \Illuminate\Http\Response
     */
    public function edit(PayingImportLog $payingImportLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\PayingImportLog $payingImportLog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PayingImportLog $payingImportLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\PayingImportLog $payingImportLog
     * @return \Illuminate\Http\Response
     */
    public function destroy(PayingImportLog $payingImportLog)
    {
        //
    }
}
