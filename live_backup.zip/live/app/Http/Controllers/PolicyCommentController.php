<?php

namespace App\Http\Controllers;

use App\Policy;

class PolicyCommentController extends Controller
{
    public function index(Policy $policy)
    {
        return view('policies.comments.index', compact('policy'));
    }
}
