<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Enums\LeadProcess;
use App\Enums\LeadStage;
use App\Exports\LeadsExport;
use App\Lead;
use Carbon\Carbon;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Facades\Excel;

class LeadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $leadsGroup = [];
        $mode = $request->get('mode', 3);

        /** @var Employee $employee */
        $employee = Auth::user()->employee;

        $baseQuery = Lead::query()
            ->with('assessor')
            ->orderByDesc('created_at')
            ->whereIn('assessor_id', $employee->hierarchy())
            ->when(!$request->filled('created_at'), function ($query) {
                $query->whereDate('created_at', '>', Carbon::now()->subDays(7)->toDateString());
            })
            ->when($request->filled('created_at'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('created_at'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0])->toDateString();
                $to = Carbon::createFromFormat('d/m/Y', $range[1])->toDateString();

                $query->whereBetween(DB::raw('date(created_at)'), [$from, $to]);
            })
            ->when($request->filled('close_date'), function ($query) use ($request) {
                $range = explode(' a ', $request->get('close_date'));
                $from = Carbon::createFromFormat('d/m/Y', $range[0])->toDateString();
                $to = Carbon::createFromFormat('d/m/Y', $range[1])->toDateString();

                $query->whereBetween(DB::raw('date(close_date)'), [$from, $to]);
            })
            ->when($request->filled('assessor_id'), function ($query) use ($request) {
                $query->where('assessor_id', $request->get('assessor_id'));
            })
            ->when($request->filled('process_id'), function ($query) use ($request) {
                $query->where('process_id', $request->get('process_id'));
            })
            ->when($request->filled('stage_id'), function ($query) use ($request) {
                $query->where('stage_id', $request->get('stage_id'));
            })
            ->when($request->filled('last_action'), function ($query) use ($request) {
                $query->where('last_action', 'like', '%' . $request->get('last_action') . '%');
            })
            ->when($request->filled('name'), function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->get('name') . '%');
            });

        $leads = $baseQuery->get();
        $totalAmountInPEN = (clone $baseQuery)->where('currency', 'PEN')->sum('amount');
        $totalAmountInUSD = (clone $baseQuery)->where('currency', 'USD')->sum('amount');

        $totalAmountSuccessInPen = (clone $baseQuery)->where('currency', 'PEN')->where('process_id', LeadProcess::Success)->sum('amount');
        $totalAmountSuccessInUSD = (clone $baseQuery)->where('currency', 'USD')->where('process_id', LeadProcess::Success)->sum('amount');

        if ($mode == 3) {
            $leadsGroup = [];
            foreach (LeadStage::toSelectArray() as $stageId => $stageName) {
                $leadsGroup[] = [
                    'stage_id' => $stageId,
                    'stage_name' => $stageName,
                    'total' => (clone $baseQuery)->byStage($stageId)->count(),
                    'amount_pen' => (clone $baseQuery)->byStage($stageId)->where('currency', 'PEN')->sum('amount'),
                    'amount_usd' => (clone $baseQuery)->byStage($stageId)->where('currency', 'USD')->sum('amount'),
                    'leads' => (clone $baseQuery)->byStage($stageId)->get()
                ];
            }
        }

        return view('leads.index', compact('mode', 'leads', 'totalAmountInPEN', 'totalAmountInUSD', 'baseQuery', 'leadsGroup', 'totalAmountSuccessInPen', 'totalAmountSuccessInUSD'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('leads.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return RedirectResponse
     * @throws ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => ['required', Rule::unique('leads', 'name')->ignore(4, 'process_id')],
            'phone' => 'required',
            'source_id' => 'required',
            //'email' => 'required',
            //'amount' => 'required|numeric|max:9999999.99',
            //'close_date' => 'required|date'
        ]);

        $lead = new Lead();
        $lead->fill($request->all());
        $lead->assessor_id = Auth::user()->employee->id;
        $lead->supervisor_id = Employee::find(Auth::user()->employee->id)->getSupervisor();
        $lead->save();

        return redirect()->route('leads.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Lead $lead
     * @return Response
     * @throws AuthorizationException
     */
    public function show(Lead $lead)
    {
        $this->authorize('view', $lead);

        return view('leads.show', compact('lead'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Lead $lead
     * @return Response
     * @throws AuthorizationException
     */
    public function edit(Lead $lead)
    {
        $this->authorize('update', $lead);

        return view('leads.edit', compact('lead'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Lead $lead
     * @return Response
     */
    public function update(Request $request, Lead $lead)
    {
        $this->validate($request, [
            'name' => 'required',
            'phone' => 'required',
            'source_id' => 'required',
            //'email' => 'required',
            //'amount' => 'required|numeric|max:9999999.99',
            //'close_date' => 'required|date'
        ]);

        if ($request->assessor_id > 0) {
            $lead->supervisor_id = Employee::find($request->assessor_id)->getSupervisor();
        }

        $lead->fill($request->all());
        $lead->save();

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Lead $lead
     * @return Response
     * @throws Exception
     */
    public function destroy(Lead $lead)
    {
        $lead->delete();

        return redirect()->route('leads.index');
    }

    public function export()
    {
        return Excel::download(new LeadsExport(), 'Leads.xlsx');
    }

    public function dashboard()
    {
        return view('leads.dashboard');
    }
}
