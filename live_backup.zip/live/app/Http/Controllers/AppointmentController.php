<?php

namespace App\Http\Controllers;

use App\Appointment;
use App\Employee;
use App\Http\Requests\AppointmentStoreRequest;
use App\Http\Requests\AppointmentUpdateRequest;
use App\LeadAppointment;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class AppointmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        return view('appointments.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('appointments.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param AppointmentStoreRequest $request
     * @return Response
     */
    public function store(AppointmentStoreRequest $request)
    {
        $appointment = new Appointment();
        $appointment->fill($request->all());

        $appointment->user_id = Auth::id();
        $appointment->status = 1;
        $appointment->save();

        return redirect()->route('appointments.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Appointment $appointment
     * @return Response
     */
    public function show(Appointment $appointment)
    {
        return view('appointments.show', compact('appointment'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Appointment $appointment
     * @return Response
     */
    public function edit(Appointment $appointment)
    {
        return view('appointments.edit', compact('appointment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param AppointmentUpdateRequest $request
     * @param Appointment $appointment
     * @return Response
     */
    public function update(AppointmentUpdateRequest $request, Appointment $appointment)
    {
        $appointment->fill($request->all());
        $appointment->save();

        return redirect()->route('appointments.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Appointment $appointment
     * @return Response
     * @throws Exception
     */
    public function destroy(Appointment $appointment)
    {
        $appointment->delete();

        return redirect()->route('appointments.index');
    }

    public function dashboard(Request $request)
    {
        $types = [
            ['id' => 0, 'name' => 'Citas'],
            ['id' => 1, 'name' => 'Cierre'],
        ];
        $type = $request->get('type', 0);
        $typeSelected = collect($types)->search(function ($data) use ($request) {
            return $data['id'] == $request->type;
        });
        $typeSelected = $types[$typeSelected];

        $statuses = [
            ['id' => 1, 'name' => 'Agendada'],
            ['id' => 2, 'name' => 'Efectiva'],
            ['id' => 3, 'name' => 'No Efectiva'],
            ['id' => 4, 'name' => 'Reprogramada'],
        ];
        $status = $request->get('status', 2);
        $request->merge(['status' => $status]);
        $statusSelected = collect($statuses)->search(function ($data) use ($request) {
            return $data['id'] == $request->status;
        });
        $statusSelected = $statuses[$statusSelected];

        $years = [2021, 2020];
        $year = $request->get('year', date('Y'));
        $yearSelected = $year;

        $months = [
            ['id' => 1, 'name' => 'Enero'],
            ['id' => 2, 'name' => 'Febrero'],
            ['id' => 3, 'name' => 'Marzo'],
            ['id' => 4, 'name' => 'Abril'],
            ['id' => 5, 'name' => 'Mayo'],
            ['id' => 6, 'name' => 'Junio'],
            ['id' => 7, 'name' => 'Julio'],
            ['id' => 8, 'name' => 'Agosto'],
            ['id' => 9, 'name' => 'Septiembre'],
            ['id' => 10, 'name' => 'Octubre'],
            ['id' => 11, 'name' => 'Noviembre'],
            ['id' => 12, 'name' => 'Diciembre'],
        ];
        $month = $request->get('month', date('n'));
        $monthSelected = collect($months)->search(function ($data) use ($month) {
            return $data['id'] == $month;
        });
        $monthSelected = $months[$monthSelected];

        $now = Carbon::now()->tz('America/Lima');
        $firstDayOfMonth = Carbon::create($year, $month);
        $lastDayOfMonth = Carbon::create($year, $month)->lastOfMonth();
        $weeksInMonth = $lastDayOfMonth->weekNumberInMonth;
        $weeks = [];
        $week = $request->get('week', $now->weekOfYear);

        for ($i = $firstDayOfMonth->weekOfYear; $i < $firstDayOfMonth->weekOfYear + $weeksInMonth; $i++) {
            $weeks[] = $i;
        }

        if (!in_array($week, $weeks)) {
            $week = $firstDayOfMonth->weekOfYear;
        }

        $weekSelected = $week;

        $firstDayOfWeek = Carbon::now()->setISODate($year, $week);
        $lastDayOfWeek = (clone $firstDayOfWeek)->endOfWeek();
        $weekDays = new CarbonPeriod($firstDayOfWeek, '1 day', $lastDayOfWeek);
        $days = [];
        foreach ($weekDays as $day) {
            $days[$day->day] = ucfirst($day->dayName);
        }

        $admins = Employee::query()
            ->select('id', 'name')
            ->whereIn('type', [1])
            ->orderBy('name')
            ->get()
            ->toArray();
        $adminSelected = $request->filled('admin') ? collect($admins)->filter(function ($data) use ($request) {
            return in_array($data['id'], $request->admin);
        })->toArray() : [];
        $adminSelected = array_values($adminSelected);

        $supervisors = Employee::query()
            ->select('id', 'name')
            ->whereIn('type', [12])
            ->orderBy('name')
            ->get()
            ->toArray();
        $supervisorSelected = $request->filled('supervisor') ? collect($supervisors)->filter(function ($data) use ($request) {
            return in_array($data['id'], $request->supervisor);
        })->toArray() : [];
        $supervisorSelected = array_values($supervisorSelected);

        $assessors = Employee::query()
            ->select('id', 'name')
            ->whereIn('type', [13])
            ->orderBy('name')
            ->get()
            ->toArray();
        $assessorSelected = $request->filled('assessor') ? collect($assessors)->filter(function ($data) use ($request) {
            return in_array($data['id'], $request->assessor);
        })->toArray() : [];
        $assessorSelected = array_values($assessorSelected);

        $hierarchy = Auth::user()->employee->hierarchy();
        $employees = Employee::query()
            ->with('job')
            ->whereIn('type', [13])
            ->whereIn('id', $hierarchy)
            ->when($request->filled('admin'), function ($query) use ($request) {
                $employees = [];
                foreach ($request->admin as $id) {
                    $employees = array_merge($employees, Employee::find($id)->hierarchy());
                }
                $query->whereIn('employees.id', $employees);
            })
            ->when($request->filled('supervisor'), function ($query) use ($request) {
                $employees = [];
                foreach ($request->supervisor as $id) {
                    $employees = array_merge($employees, Employee::find($id)->hierarchy());
                }
                $query->whereIn('employees.id', $employees);
            })
            ->when($request->filled('assessor'), function ($query) use ($request) {
                $query->whereIn('employees.id', $request->assessor);
            })
            ->orderBy('name')
            ->get();

        return view('dashboards.appointments', compact(
            'types', 'type', 'typeSelected',
            'statuses', 'status', 'statusSelected',
            'years', 'year', 'yearSelected',
            'months', 'month', 'monthSelected',
            'weeks', 'week', 'weekSelected',
            'weekDays', 'days',
            'admins', 'adminSelected',
            'supervisors', 'supervisorSelected',
            'assessors', 'assessorSelected',
            'employees'
        ));
    }

    public function dashboardDetail(Request $request)
    {
        $employee = Employee::query()->with('user', 'job')->where('id', $request->employee_id)->first();

        if ($request->filled('month')) {
            $startDate = Carbon::create($request->year, $request->month)->startOfMonth();
            $endDate = (clone $startDate)->endOfMonth();
        }

        if ($request->filled('week')) {
            $startDate = Carbon::now()->setISODate($request->year, $request->week)->startOfWeek();
            $endDate = (clone $startDate)->endOfWeek();
        }

        if ($request->filled('day')) {
            $startDate = Carbon::create($request->year, $request->month, $request->day)->startOfDay();
            $endDate = (clone $startDate)->endOfDay();
        }

        $range = 'Desde ' . $startDate->format('d/m/Y') . ' hasta ' . $endDate->format('d/m/Y');

        $appointments = LeadAppointment::query()
            ->where('user_id', $employee->user_id)
            ->whereBetween('date', [$startDate, $endDate])
            ->when($request->filled('number'), function ($query) use ($request) {
                $query->where('number', $request->number);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->status);
            })
            ->when($request->get('type') == 1, function ($query) {
                $query->whereHas('lead', function (Builder $query) {
                    $query->where('stage_id', 5); // ganado
                });
            })
            ->get();

        return view('dashboards.appointments_detail', compact('employee', 'appointments', 'range'));
    }
}
