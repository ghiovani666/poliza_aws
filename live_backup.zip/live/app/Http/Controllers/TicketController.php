<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Customer;
use App\Employee;
use App\Http\Requests\TicketStoreRequest;
use App\Http\Requests\TicketUpdateRequest;
use App\Notifications\TicketCreated;
use App\Ticket;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->authorize('view-any', Ticket::class);

        $tickets = Ticket::query()
            ->when($request->filled('ticket_id'), function ($query) use ($request) {
                $query->where('id', 'like', "%{$request->get('ticket_id')}%");
            })
            ->when($request->filled('customer_id'), function ($query) use ($request) {
                $query->where('customer_id', 'like', "%{$request->get('customer_id')}%");
            })
            ->when($request->filled('created_at'), function ($query) use ($request) {
                $date = Carbon::parse($request->get('created_at'), 'America/Lima')->tz('UTC');
                $query->where('created_at', 'like', "%{$request->get('created_at')}%");
            })
            ->orderByDesc('id')
            ->paginate();

        return view('tickets.index', compact('tickets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $this->authorize('create', Ticket::class);
        $customers = [];

        $employees = Employee::query()
            ->orderBy('name')
            ->pluck('name', 'id');

        return view('tickets.create', compact('customers', 'employees'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param TicketStoreRequest $request
     * @return void
     */
    public function store(TicketStoreRequest $request)
    {
        $this->authorize('create', Ticket::class);

        $ticket = new Ticket();
        $ticket->fill($request->all());
        $ticket->user_id = auth()->id();
        $ticket->copy_to = is_array($request->get('copy_to')) ? $request->get('copy_to') : [];
        $ticket->save();

        $comment = new Comment();
        $comment->user_id = Auth::id();
        $comment->body = $request->get('body');
        $ticket->comments()->save($comment);

        flash('Nuevo ticket creado correctamente.')->success();

        $ticket->employee->notify(new TicketCreated($ticket));

        return redirect()->route('tickets.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Ticket $ticket
     * @return Response
     */
    public function show(Ticket $ticket)
    {
        $this->authorize('view', $ticket);

        return view('tickets.show', compact('ticket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Ticket $ticket
     * @return Response
     */
    public function edit(Ticket $ticket)
    {
        $this->authorize('update', $ticket);

        $customers = Customer::query()
            ->orderBy('name')
            ->pluck('name', 'id');

        $employees = Employee::query()
            ->orderBy('name')
            ->pluck('name', 'id');

        return view('tickets.edit', compact('ticket', 'customers', 'employees'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Ticket $ticket
     * @return Response
     */
    public function update(TicketUpdateRequest $request, Ticket $ticket)
    {
        $this->authorize('update', $ticket);

        $ticket->fill($request->all());
        $ticket->save();

        flash('Ticket actualizado correctamente')->success();

        return redirect()->route('tickets.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Ticket $ticket
     * @return Response
     */
    public function destroy(Ticket $ticket)
    {
        $this->authorize('delete', $ticket);

        $ticket->delete();

        flash('Ticket fue eliminado correctamente.')->success();

        return redirect()->route('tickets.index');
    }
}