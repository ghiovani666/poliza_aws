<?php

namespace App\Http\Controllers;

use App\Company;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $companies = Company::query()
            ->with(['sectors'])
            ->withCount(['sectors'])
            ->orderByDesc('id')
            ->paginate();

        return view('companies.index', compact('companies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('companies.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     * @throws ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request, ['name' => 'required']);

        $company = new Company();
        $company->fill($request->except('company_id'));
        $company->save();

        flash('Nueva empresa registrada correctamente.')->success()->important();

        return redirect()->route('companies.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Company $company
     * @return Response
     */
    public function show(Company $company)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Company $company
     * @return Response
     */
    public function edit(Company $company)
    {
        return view('companies.edit', compact('company'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Company $company
     * @return Response
     * @throws ValidationException
     */
    public function update(Request $request, Company $company)
    {
        $this->validate($request, ['name' => 'required']);

        $company->fill($request->all());
        $company->save();

        flash('Empresa actualizada correctamente.')->success()->important();

        return redirect()->route('companies.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Company $company
     * @return Response
     * @throws Exception
     */
    public function destroy(Company $company)
    {
        $company->delete();

        flash('Empresa eliminada correctamente.')->success()->important();

        return redirect()->route('companies.index');
    }
}
