<?php

namespace App\Http\Controllers;

use App\Imports\PolicyDocumentsImport;
use App\Policy;
use App\PolicyDocument;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PolicyDocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function index(Policy $policy)
    {
        $documents = $policy->documents()
            ->paginate();

        return view('policies.documents.index', compact('policy', 'documents'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Policy $policy
     * @return Response
     */
    public function create(Policy $policy)
    {
        return view('policies.documents.create', compact('policy'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @param Policy $policy
     * @return Response
     */
    public function store(Request $request, Policy $policy)
    {
        $request->validate([
            'name' => 'required',
            'url' => 'required'
        ]);

        $document = new PolicyDocument();
        $document->fill($request->all());

        $policy->documents()->save($document);

        flash('Nuevo documento registrado correctamente.')->success();

        return redirect()->to(route('policies.documents.index', $policy) . '#documents');
    }

    /**
     * Display the specified resource.
     *
     * @param PolicyDocument $policyDocument
     * @return Response
     */
    public function show(PolicyDocument $policyDocument)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Policy $policy
     * @param PolicyDocument $document
     * @return Response
     */
    public function edit(Policy $policy, PolicyDocument $document)
    {
        return view('policies.documents.edit', compact('policy', 'document'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Policy $policy
     * @param PolicyDocument $document
     * @return Response
     */
    public function update(Request $request, Policy $policy, PolicyDocument $document)
    {
        $request->validate([
            'name' => 'required',
            'url' => 'required'
        ]);

        $document->fill($request->all());

        $policy->documents()->save($document);

        flash('Documento actualizado correctamente.')->success();

        return redirect()->to(route('policies.documents.index', $policy) . '#documents');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Policy $policy
     * @param PolicyDocument $document
     * @return Response
     * @throws Exception
     */
    public function destroy(Policy $policy, PolicyDocument $document)
    {
        $document->delete();

        flash('Documento eliminado correctamente')->success();

        return redirect()->to(route('policies.documents.index', $policy) . '#documents');
    }

    public function import(Request $request, Policy $policy)
    {
        try {
            DB::beginTransaction();
            // store
            $filePath = $request->file('file')->store('imports');

            // import
            Excel::import(new PolicyDocumentsImport($policy), $filePath);

            flash('Archivo importado correctamente.')->success();

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();

            flash($exception->getMessage())->error();
        }

        return redirect()->to(route('policies.documents.index', $policy) . '#documents');
    }
}
