<?php

namespace App\Http\Controllers;

use App\Policy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoyaltyController extends Controller
{
    public function index(Request $request)
    {
        $this->authorize('view-loyalty', Policy::class);

        $policies = Policy::query()
            ->with(['status', 'customer', 'assessor'])
            ->leftJoin('customers', 'customers.id', '=', 'policies.customer_id')
            ->select('policies.*', 'customers.name', 'customers.document_number')
            ->when($request->has('customer'), function (Builder $query) use ($request) {
                $query->where('customers.name', 'like', "%{$request->customer}%");
            })
            ->when($request->has('code') && !is_null($request->code), function ($query) use ($request) {
                $query->where('code', 'like', "%{$request->code}%");
            })
            ->when($request->has('is_service_ok') && !is_null($request->is_service_ok), function ($query) use ($request) {
                $query->where('is_service_ok', (int)$request->is_service_ok);
            })
            ->when(Auth::user()->isAssessor, function ($query) {
                $query->where('assessor_id', Auth::user()->employee->id);
            })
            ->orderByDesc('id')
            ->paginate();

        return view('loyalties.index', compact('policies'));
    }

    public function show(Policy $policy)
    {
        return view('loyalties.show', compact('policy'));
    }

    public function update(Policy $policy, Request $request)
    {
        $request->validate(['is_service_ok']);

        $policy->loyalty_editable = false;
        $policy->is_service_ok = $request->get('is_service_ok');
        $policy->comments = $request->get('comments');
        $policy->save();

        flash('Fidelizacion actualizada correctamente.')->success()->important();

        return redirect()->route('loyalties.index');
    }
}
