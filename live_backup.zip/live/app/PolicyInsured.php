<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PolicyInsured extends Model
{
    protected $guarded = [];
}
