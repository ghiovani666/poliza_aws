<?php

namespace App;

use App\Enums\LeadProcess;
use App\Traits\DateTimeHelper;
use Carbon\Carbon;
use Collective\Html\Eloquent\FormAccessible;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;

/**
 * Class Lead
 * @package App
 * @property Carbon close_date
 * @property int process_id
 * @property int stage_id
 */
class Lead extends Model
{
    use SoftDeletes, FormAccessible, DateTimeHelper;

    protected $guarded = [];
    protected $dates = ['close_date', 'win_date'];
    protected $casts = ['last_action' => 'array'];
    protected $appends = ['processName'];

    public function scopeByStage($query, $stageId)
    {
        return $query->where('stage_id', $stageId);
    }

    public function daysToClose()
    {
        $date = $this->close_date;
        $now = Carbon::now();
        return $now->diffInDays($date);
    }

    public function formCloseDateAttribute()
    {
        return Carbon::parse($this->close_date)->format('Y-m-d');
    }

    public function comments()
    {
        return $this->morphMany(Comment::class, 'commentable');
    }

    public function assessor()
    {
        return $this->belongsTo(Employee::class, 'assessor_id')->withDefault(['name' => 'No asignado']);
    }

    public function supervisor()
    {
        return $this->belongsTo(Employee::class, 'supervisor_id')->withDefault(['name' => 'No asignado']);
    }

    public function getAlertTypeAttribute()
    {
        if ($this->process_id == 3) return 'alert-primary';
        if ($this->process_id == 4) return 'alert-danger';
        if ($this->process_id == 5) return 'alert-warning';

        return null;
    }

    public function scopeByAssessor(Builder $query, Employee $employee)
    {
        return $query->where('assessor_id', $employee->id);
    }

    public function scopeByProcess(Builder $query, $id)
    {
        return $query->where('process_id', $id);
    }

    public function scopeByCurrency(Builder $query, $currency)
    {
        return $query->where('currency', $currency);
    }

    public function getProcessNameAttribute()
    {
        return LeadProcess::getDescription($this->process_id);
    }

    public function scopeRangeDate(Builder $query, Request $request, $field = 'created_at')
    {
        $query->when($request->filled($field), function (Builder $query) use ($request, $field) {
            $dates = explode(' - ', $request->get($field));
            $fromDate = Carbon::parse($dates[0])->utc()->toDateTimeString();
            $toDate = Carbon::parse($dates[1])->utc()->addHours(24)->toDateTimeString();

            $query->whereBetween($field, [$fromDate, $toDate]);
        });
    }

    public function appointments()
    {
        return $this->hasMany(LeadAppointment::class);
    }
}
