<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property float amount
 * @property int id
 * @property string range
 */
class Paying extends Model
{
    protected $guarded = [];

    public function assessor()
    {
        return $this->belongsTo(Employee::class)->withDefault();
    }

    public function calculateAmount()
    {
        $this->amount = PayingItem::query()
            ->where('paying_id', $this->id)
            ->sum('commission_assessor_real');
        return $this;
    }

    public function calculateRange()
    {
        $first = PayingItem::query()
            ->where('paying_id', $this->id)
            ->orderBy('created_at')
            ->first();

        $last = PayingItem::query()
            ->where('paying_id', $this->id)
            ->orderByDesc('created_at')
            ->first();

        $this->range = $first->created_at->format('d/m/Y') . ' - ' . $last->created_at->format('d/m/Y');
        return $this;
    }
}
