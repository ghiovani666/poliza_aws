<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class AccidentState extends Enum
{
    const OPEN = 1;
    const RESOLVED = 2;
    const CLOSED = 3;
    const REJECTED = 4;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::OPEN:
                return 'Abierto';
                break;
            case self::RESOLVED:
                return 'Resuelto';
                break;
            case self::CLOSED:
                return 'Cerrado';
                break;
            case self::REJECTED:
                return 'Rechazado';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
