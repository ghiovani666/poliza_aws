<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class LeadStage extends Enum
{
    const ToContact = 1;
    const Contacted = 2;
    const ProposalSent = 3;
    const Negotiation = 4;
    const Win = 5;

    public static function getDescription($value): string
    {
        switch ($value) {
            case 1:
                return 'Por Contactar (20%)';
            case 2:
                return 'Contactado (40%)';
            case 3:
                return 'Propuesta enviada (60%)';
            case 4:
                return 'Negociación (80%)';
            case 5:
                return 'Ganado (100%)';
            default:
                return '---';
        }
    }
}
