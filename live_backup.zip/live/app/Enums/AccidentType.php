<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class AccidentType extends Enum
{
    const ACCIDENT = 1;
    const HEIST = 2;
    const FIRE = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::ACCIDENT:
                return 'Accidente';
                break;
            case self::HEIST:
                return 'Robo';
                break;
            case self::FIRE:
                return 'Incendio';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
