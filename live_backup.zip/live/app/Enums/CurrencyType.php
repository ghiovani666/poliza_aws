<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class CurrencyType extends Enum
{
    const USD = 'USD';
    const PEN = 'PEN';

    public static function toArray(): array
    {
        $array = [];
        foreach (static::getConstants() as $index => $value) {
            $array[$value] = static::getDescription($value);
        }

        return $array;
    }

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::USD:
                return 'Dolares (USD)';
                break;
            case self::PEN:
                return 'Soles (PEN)';
                break;
        }
    }
}
