<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class ClaimResult extends Enum
{
    const APPROVED_AMOUNT = 1;
    const REJECTION_REASONS = 2;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::APPROVED_AMOUNT:
                return 'Monto Aprobado';
                break;
            case self::REJECTION_REASONS:
                return 'Razones de Rechazo';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
