<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class PaymentType extends Enum
{
    const ACCOUNT_CHARGE = 1;
    const COUPON = 2;
    const CASH = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::ACCOUNT_CHARGE:
                return 'CC (cargo a cuenta)';
                break;
            case self::COUPON:
                return 'CP (cupón)';
                break;
            case self::CASH:
                return 'Contado';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
