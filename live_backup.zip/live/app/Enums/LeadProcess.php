<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class LeadProcess extends Enum
{
    const Pending = 1;
    const StandBy = 2;
    const Success = 3;
    const Lose = 4;
    const Cancel = 5;

    public static function getDescription($value): string
    {
        switch ($value) {
            case 1:
                return 'Pendiente';
            case 2:
                return 'Stand By';
            case 3:
                return 'Ganado';
            case 4:
                return 'Perdido';
            case 5:
                return 'Cancelado';
            default:
                return '---';
        }
    }
}
