<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class FinanceStatuses extends Enum
{
    const FINANCE = 1;
    const IN_PROGRESS = 2;
    const CLOSED = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::FINANCE:
                return 'Financiado';
                break;
            case self::IN_PROGRESS:
                return 'En proceso';
                break;
            case self::CLOSED:
                return 'Cerrado';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
