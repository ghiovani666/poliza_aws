<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class PeriodType extends Enum
{
    const MONTHLY = 1;
    const BIMONTHLY = 2;
    const QUARTER = 3;
    const SEMIANNUAL = 6;
    const ANNUAL = 12;
    const UNLIMITED = 99;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::MONTHLY:
                return 'Mensual';
                break;
            case self::BIMONTHLY:
                return 'Bimestral';
                break;
            case self::QUARTER:
                return 'Trimestral';
                break;
            case self::SEMIANNUAL:
                return 'Semestral';
                break;
            case self::ANNUAL:
                return 'Anual';
                break;
            case self::UNLIMITED:
                return 'A término';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
