<?php


namespace App\Enums;


trait Search
{
    public static function search($name)
    {
        if (is_null($name) || strlen($name) == 0) {
            return null;
        }

        $data = self::toSelectArray();
        return array_search($name, $data);
    }
}
