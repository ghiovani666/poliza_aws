<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class PolicyActiveType extends Enum
{
    use Search;

    const Active = 1;
    const Inactive = 0;
    const Error = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::Active:
                return 'Vigente';
                break;
            case self::Inactive:
                return 'No Vigente';
                break;
            case self::Error:
                return 'Error';
                break;
        }
    }
}
