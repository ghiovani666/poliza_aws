<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class PolicyPaymentStatus extends Enum {
    const PAID = 1;
    const OVERDUE = 2;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::PAID:
                return 'Pagado';
                break;
            case self::OVERDUE:
                return 'Vencido';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
