<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class DocumentType extends Enum
{
    const DNI = 1;
    const RUC = 2;
    const PASSPORT = 3;
    const FOREIGN_CARD = 4;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::DNI:
                return 'DNI';
                break;
            case self::RUC:
                return 'RUC';
                break;
            case self::PASSPORT:
                return 'Pasaporte';
                break;
            case self::FOREIGN_CARD:
                return 'Carnet de extranjeria';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
