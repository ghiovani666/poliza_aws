<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * Class LeadSource
 * @package App\Enums
 */
final class LeadSource extends Enum
{
    const Referred = 1;
    const Prospect = 2;
    const Survey = 3;
    const Other = 4;

    public static function getDescription($value): string
    {
        switch ($value) {
            case 1:
                return 'Referido';
            case 2:
                return 'Prospección';
            case 3:
                return 'Redes Sociales';
            case 4:
                return 'Otro';
            default:
                return '---';
        }
    }
}
