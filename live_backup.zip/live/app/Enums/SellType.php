<?php

namespace App\Enums;

use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

final class SellType extends Enum implements LocalizedEnum
{
    use Search;

    const NEW_SALE = 1;
    const AGENCY = 2;
    const RENEWAL = 3;
    const ENDORSEMENT = 4;

    public static function getDateMode($id)
    {
        switch ($id) {
            case self::NEW_SALE:
            case self::RENEWAL:
            case self::ENDORSEMENT:
                return 'validity_date';
            case self::AGENCY:
                return 'requested_date';
        }
    }
}
