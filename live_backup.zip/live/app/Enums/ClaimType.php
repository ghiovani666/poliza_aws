<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class ClaimType extends Enum
{
    const DAMAGE = 1;
    const INDEMNIFICATION = 2;
    const SERVICE = 3;
    const COVERAGE = 4;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::DAMAGE:
                return 'Accidente';
                break;
            case self::INDEMNIFICATION:
                return 'Indemnización';
                break;
            case self::SERVICE:
                return 'Servicio';
                break;
            case self::COVERAGE:
                return 'Cobertura';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
