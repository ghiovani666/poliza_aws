<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class EPSType extends Enum
{
    const BASE = 1;
    const ADITIONAL1 = 2;
    const ADITIONAL2 = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::BASE:
                return 'Base';
                break;
            case self::ADITIONAL1:
                return 'Adicional 1';
                break;
            case self::ADITIONAL2:
                return 'Adicional 2';
                break;
            default:
                return '';
                break;
        }
    }
}
