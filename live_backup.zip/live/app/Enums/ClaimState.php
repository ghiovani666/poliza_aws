<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class ClaimState extends Enum
{
    const UNDER_REVISION = 1;
    const APPROVED = 2;
    const REJECTED = 3;

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::UNDER_REVISION:
                return 'En Revisión';
                break;
            case self::APPROVED:
                return 'Aprobado';
                break;
            case self::REJECTED:
                return 'Rechazado';
                break;
            default:
                return 'Desconocido';
                break;
        }
    }
}
