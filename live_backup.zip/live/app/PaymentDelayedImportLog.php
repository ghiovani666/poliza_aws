<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentDelayedImportLog extends Model
{
    //
}
