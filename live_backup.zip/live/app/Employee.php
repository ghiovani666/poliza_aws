<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;

/**
 * @property int id
 * @property int type
 * @property array supervise
 */
class Employee extends Model
{
    use Notifiable, SoftDeletes;

    protected $guarded = [];

    protected $casts = ['type' => 'int', 'supervise' => 'array'];

    public static function add(Request $request)
    {
        $employee = new self();

        return self::addTo($employee, $request);
    }

    public static function addTo($employee, Request $request)
    {
        $employee->fill($request->all());

        return $employee;
    }

    public function job()
    {
        return $this->belongsTo(EmployeeType::class, 'type')->withDefault(['name' => 'Desconocido']);
    }

    public function getHasUserAttribute()
    {
        return $this->user()->exists();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function policies()
    {
        return $this->hasMany(Policy::class, 'assessor_id');
    }

    public function addSubordinates(...$employees)
    {
        foreach ($employees as $employee) {
            $this->addSubordinate($employee);
        }

        return $this;
    }

    public function addSubordinate(Employee $employee)
    {
        $options = $this->supervise;
        $options[] = $employee->id;

        $this->supervise = $options;

        return $this;
    }

    public function removeSubordinates(...$employees)
    {
        foreach ($employees as $employee) {
            $this->removeSubordinate($employee);
        }

        return $this;
    }

    public function removeSubordinate(Employee $employee)
    {
        $options = $this->supervise;
        unset($options[array_search($employee->id, $options)]);

        $this->supervise = $options;

        return $this;
    }

    public function getIsAssessorAttribute()
    {
        return in_array($this->type, [13, 17]);
    }

    public function getIsSupervisorAttribute()
    {
        return in_array($this->type, [12]);
    }

    public function getSupervisor()
    {
        foreach (self::query()->whereNotNull('supervise')->get() as $supervisor) {
            if (in_array($this->id, $supervisor->supervise)) {
                return $supervisor->id;
            }
        }

        return null;
    }

    public function hierarchy()
    {
        $employees = [$this->id];
        $data = $this->supervise;
        while (is_array($data) && count($data) > 0) {
            $current = $data;
            $data = [];

            foreach ($current as $value) {
                $employees[] = $value;
                $rows = Employee::find($value);

                if (is_null($rows)) {
                    continue;
                }

                if (is_array($rows->supervise)) {
                    $data = array_merge($data, $rows->supervise);
                }
            }
        }
        return $employees;
    }
}
