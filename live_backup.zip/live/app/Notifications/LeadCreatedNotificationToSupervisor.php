<?php

namespace App\Notifications;

use App\Lead;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class LeadCreatedNotificationToSupervisor extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @param Lead $lead
     */
    public function __construct(Lead $lead)
    {
        $this->lead = $lead;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        $data = [
            'name' => $notifiable->name,
            'lead' => $this->lead,
        ];

        return (new MailMessage)
            ->subject('#' . $this->lead->id . ' - Nuevo lead registrado')
            ->markdown('_mails.lead-created-notification-to-assessor', $data);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
