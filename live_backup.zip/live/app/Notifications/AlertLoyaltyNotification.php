<?php

namespace App\Notifications;

use App\Policy;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AlertLoyaltyNotification extends Notification
{
    use Queueable;

    /**
     * @var Collection
     */
    public $policies;

    /**
     * @var Carbon
     */
    public $now;

    /**
     * Create a new notification instance.
     *
     * @param Collection $policies
     */
    public function __construct(Collection $policies)
    {
        $this->policies = $policies;
        $this->now = Carbon::now();
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        if ($this->policies->count() > 0) {
            return ['mail'];
        }

        return [];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('MORGAN INTRANET > Lista de clientes pendientes de fidelización ' . $this->now->format('d/m/Y'))
            ->line('Esta es la lista de los clientes pendientes de fidelización para el día de hoy ' . $this->now->format('d/m/Y'))
            ->action('Ver lista', url('/loyalties'));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
