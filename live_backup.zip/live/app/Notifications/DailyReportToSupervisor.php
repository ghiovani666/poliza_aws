<?php

namespace App\Notifications;

use App\Enums\LeadStage;
use App\Lead;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class DailyReportToSupervisor extends Notification
{
    use Queueable;

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        $data = $this->toArray($notifiable);

        return (new MailMessage)
            ->subject('Leads: Reporte diario.')
            ->markdown('_mails.daily-report-to-supervisor', $data);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        $now = Carbon::now();
        $previous = Carbon::now()->subMonth();

        return [
            'name' => $notifiable->name,
            'today' => $now->format('d/m/Y'),
            'currentMonth' => $now->format('m/Y'),
            'previousMonth' => $previous->format('m/Y'),
            'currentMonthData' => $this->getMonthData($now, $notifiable),
            'previousMonthData' => $this->getMonthData($previous, $notifiable),
            'pipelineData' => $this->getPipelineData($notifiable),
        ];
    }

    private function getMonthData(Carbon $date, $notifiable)
    {
        $baseQuery = Lead::query()
            ->whereIn('assessor_id', $notifiable->supervise)
            ->whereMonth('created_at', $date->month)
            ->whereYear('created_at', $date->year);

        $pending = (clone $baseQuery)->where('process_id', 1)->count();
        $lost = (clone $baseQuery)->where('process_id', 4)->count();
        $win = (clone $baseQuery)->where('process_id', 3)->count();
        $pen = (clone $baseQuery)->where('process_id', 3)->where('currency', 'PEN')->sum('amount');
        $usd = (clone $baseQuery)->where('process_id', 3)->where('currency', 'USD')->sum('amount');

        return [
            'pending' => $pending,
            'lost' => $lost,
            'win' => $win,
            'win_pen' => $pen,
            'win_usd' => $usd,
        ];
    }

    private function getPipelineData($notifiable)
    {
        $baseQuery = Lead::query()->whereIn('assessor_id', $notifiable->supervise);

        $stageToContact = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->where('currency', 'USD')->sum('amount'),
        ];

        $stageContacted = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->where('currency', 'USD')->sum('amount'),
        ];

        $stageProposalSent = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->where('currency', 'USD')->sum('amount'),
        ];

        $stageNegotiation = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->where('currency', 'USD')->sum('amount'),
        ];

        return [
            LeadStage::ToContact => $stageToContact,
            LeadStage::Contacted => $stageContacted,
            LeadStage::ProposalSent => $stageProposalSent,
            LeadStage::Negotiation => $stageNegotiation,
        ];
    }
}
