<?php

namespace App\Notifications;

use App\Employee;
use App\Enums\LeadProcess;
use App\Enums\LeadStage;
use App\Lead;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class DailyReportToAssessor extends Notification
{
    use Queueable;

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        $data = $this->toArray($notifiable);

        return (new MailMessage)
            ->subject('Resumen de actividad diaria - Morgan Intranet')
            ->markdown('_mails.daily-report-to-assessor', $data);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        $now = Carbon::today();
        $previous = Carbon::today()->subMonth();
        $supervisor = Employee::find($notifiable->getSupervisor());
        $baseQuery = Lead::query()
            ->select('id', 'name', 'close_date', 'process_id')
            ->where('assessor_id', $notifiable->id)
            ->where('process_id', LeadProcess::Pending);

        $todayQuery = (clone $baseQuery)
            ->whereDate('close_date', Carbon::today()->toDateString())
            ->get();

        $pendingQuery = (clone $baseQuery)
            ->whereDate('close_date', '<', Carbon::today()->toDateString())
            ->get();

        $today = [
            'total' => $todayQuery->count(),
            'leads' => $this->parseCollection($todayQuery),
        ];

        $pending = [
            'total' => $pendingQuery->count(),
            'leads' => $this->parseCollection($pendingQuery),
        ];

        return [
            'name' => $notifiable->name,
            'nameSupervisor' => is_null($supervisor) ? 'No Asignado' : $supervisor->name,
            'today' => $today,
            'pending' => $pending,
            'currentMonth' => $now->format('m/Y'),
            'previousMonth' => $previous->format('m/Y'),
            'currentMonthData' => $this->getMonthData($now, $notifiable),
            'previousMonthData' => $this->getMonthData($previous, $notifiable),
            'pipelineData' => $this->getPipelineData($notifiable)
        ];
    }

    private function parseCollection($collection)
    {
        $data = [];

        foreach ($collection as $lead) {
            $data[] = [
                'id' => $lead->id,
                'name' => $lead->name,
                'close_date' => $lead->close_date->day . ' de ' . $lead->close_date->locale('es')->monthName
            ];
        }

        return $data;
    }

    private function getMonthData(Carbon $date, $notifiable)
    {
        $baseQuery = Lead::query()
            ->where('assessor_id', $notifiable->id)
            ->whereMonth('created_at', $date->month)
            ->whereYear('created_at', $date->year);

        $pending = (clone $baseQuery)->where('process_id', 1)->count();
        $win = (clone $baseQuery)->where('process_id', 3)->count();
        $pen = (clone $baseQuery)->where('process_id', 3)->where('currency', 'PEN')->sum('amount');
        $usd = (clone $baseQuery)->where('process_id', 3)->where('currency', 'USD')->sum('amount');

        return [
            'pending' => $pending,
            'win' => $win,
            'win_pen' => $pen,
            'win_usd' => $usd,
        ];
    }

    private function getPipelineData($notifiable)
    {
        $baseQuery = Lead::query()->where('assessor_id', $notifiable->id);

        $stageToContact = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::ToContact)->where('currency', 'USD')->sum('amount'),
        ];

        $stageContacted = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::Contacted)->where('currency', 'USD')->sum('amount'),
        ];

        $stageProposalSent = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::ProposalSent)->where('currency', 'USD')->sum('amount'),
        ];

        $stageNegotiation = [
            'count' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->count(),
            'pen' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->where('currency', 'PEN')->sum('amount'),
            'usd' => (clone $baseQuery)->where('stage_id', LeadStage::Negotiation)->where('currency', 'USD')->sum('amount'),
        ];

        return [
            LeadStage::ToContact => $stageToContact,
            LeadStage::Contacted => $stageContacted,
            LeadStage::ProposalSent => $stageProposalSent,
            LeadStage::Negotiation => $stageNegotiation,
        ];
    }
}
