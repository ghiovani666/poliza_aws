<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\SlackMessage;
use Illuminate\Notifications\Notification;
use Laravel\Telescope\IncomingEntry;

class EntryNotification extends Notification
{
    use Queueable;
    /**
     * @var IncomingEntry
     */
    private $entry;

    /**
     * Create a new notification instance.
     *
     * @param IncomingEntry $entry
     */
    public function __construct(IncomingEntry $entry)
    {
        $this->entry = $entry;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['slack', 'mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('The introduction to the notification.')
            ->action('Notification Action', url('/'))
            ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }

    public function toSlack($notifiable)
    {

        return (new SlackMessage)
            ->error()
            ->content($this->entry->content['message'])
            ->attachment(function ($attachment) {
                $attachment->title('Exception')
                    ->fields([
                        'File' => $this->entry->content['file'],
                        'Line' => $this->entry->content['line'],
                        'User Name' => $this->entry->content['user']['name'],
                        'User Email' => $this->entry->content['user']['email'],
                    ]);
            });
    }
}
