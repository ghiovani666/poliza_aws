<?php

namespace App\Notifications;

use App\Comment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class LeadWasCommentedNotificationToSupervisor extends Notification
{
    use Queueable;

    /**
     * @var Comment
     */
    public $comment;

    /**
     * Create a new notification instance.
     *
     * @param Comment $comment
     */
    public function __construct(Comment $comment)
    {
        $this->comment = $comment;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        $user = $this->comment->user;
        $lead = $this->comment->commentable;
        $assessor = $lead->assessor;
        $subject = sprintf('%s registro un comentario en el lead #%s', $user->name, $this->comment->commentable->id);
        $data = [
            'user' => $user,
            'supervisor' => $notifiable,
            'assessor' => $assessor,
            'lead' => $lead,
        ];

        return (new MailMessage)
            ->subject($subject)
            ->markdown('_mails.lead-commented-notification-to-supervisor', $data);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
