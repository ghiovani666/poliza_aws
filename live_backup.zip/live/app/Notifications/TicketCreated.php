<?php

namespace App\Notifications;

use App\Employee;
use App\Ticket;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class TicketCreated extends Notification
{
    use Queueable;
    /**
     * @var Ticket
     */
    private $ticket;

    /**
     * Create a new notification instance.
     *
     * @param Ticket $ticket
     */
    public function __construct(Ticket $ticket)
    {
        $this->ticket = $ticket;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        $mailMessage = (new MailMessage)
            ->subject('[Morgan&Asociados] Nuevo Ticket registrado (ID:' . $this->ticket->id . ')')
            ->line('Un nuevo ticket a sido registrado.')
            ->action('Ver Ticket', url('/tickets/' . $this->ticket->id));

        // copy to
        if (is_array($this->ticket->copy_to)) {
            $emails = [];
            foreach ($this->ticket->copy_to as $employeeId) {
                $emails[] = Employee::find($employeeId)->email;
            }

            $mailMessage->cc($emails);
        }

        return $mailMessage;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
