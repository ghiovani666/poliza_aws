<?php

namespace App\Notifications;

use App\Appointment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AppointmentCreatedNotification extends Notification
{
    use Queueable;
    /**
     * @var Appointment
     */
    public $appointment;
    /**
     * @var array
     */
    public $cc;

    /**
     * Create a new notification instance.
     *
     * @param Appointment $appointment
     */
    public function __construct(Appointment $appointment)
    {
        $this->appointment = $appointment;
        $this->cc = [$this->appointment->client_email];
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('MORGAN INTRANET > Morgan & Asociados - Se ha concertado una cita el ' . date('d/m/Y'))
            ->cc($this->cc)
            ->line('Se ha concertado una cita con un representante de Morgan & Asociados con la siguiente información:')
            //->action('Notification Action', url('/'))
            ->line('Dia: ' . $this->appointment->date)
            ->line('Hora: ' . $this->appointment->from)
            ->line('Comentarios: ' . $this->appointment->comment);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
