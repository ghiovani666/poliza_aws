<?php

namespace App\Listeners;

use App\Events\LeadWasCommented;
use App\Notifications\LeadWasCommentedNotificationToAssessor;

class NotifyToAssessorLeadWasCommented
{
    /**
     * Handle the event.
     *
     * @param LeadWasCommented $event
     * @return void
     */
    public function handle(LeadWasCommented $event)
    {
        $lead = $event->comment->commentable;
        $assessor = $lead->assessor;
        $user = $event->comment->user;

        if ($user->employee->id != $assessor->id) {
            $assessor->notify(new LeadWasCommentedNotificationToAssessor($event->comment));
        }
    }
}
