<?php

namespace App\Listeners;

use App\Events\AppointmentCreatedEvent;
use App\Notifications\AppointmentCreatedNotification;
use Illuminate\Support\Facades\Notification;

class AppointmentCreatedListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param object $event
     * @return void
     */
    public function handle(AppointmentCreatedEvent $event)
    {
        Notification::route('mail', $event->appointment->user->email)
            ->notify(new AppointmentCreatedNotification($event->appointment));
    }
}
