<?php

namespace App\Listeners;

use App\Notifications\LeadWasCommentedNotificationToSupervisor;
use Illuminate\Support\Facades\Auth;

class NotifyToSupervisorLeadWasCommented
{
    /**
     * Handle the event.
     *
     * @param object $event
     * @return void
     */
    public function handle($event)
    {
        $lead = $event->comment->commentable;
        $supervisor = $lead->supervisor;
        $user = $event->comment->user;

        if ($supervisor->exists && $user->employee->id != $supervisor->id) {
            $supervisor->notify(new LeadWasCommentedNotificationToSupervisor($event->comment));
        }
    }
}
