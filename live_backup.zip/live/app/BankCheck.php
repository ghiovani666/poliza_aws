<?php

namespace App;

use App\Traits\DateTimeHelper;
use Illuminate\Database\Eloquent\Model;

class BankCheck extends Model
{
    use DateTimeHelper;

    protected $guarded = [];

    public function company()
    {
        return $this->belongsTo(Company::class)->withDefault(['name' => 'No seleccionado']);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withDefault(['name' => 'No seleccionado']);
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class)->withDefault(['name' => 'No seleccionado']);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
