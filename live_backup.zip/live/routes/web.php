<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Comment;
use App\Lead;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::group(['middleware' => 'auth'], function () {
    Route::get('/', 'HomeController@index')->name('home');
    Route::get('settings', 'SettingController@index')->name('settings.index');
    Route::get('settings/restore/{id}', 'SettingController@restore')->name('settings.restore');

    Route::get('policies/{policy}/renew', 'PolicyController@renew')->name('policies.renew');
    Route::post('policies/{policy}/documents/import', 'PolicyDocumentController@import')->name('policies.documents.import');
    Route::post('policies/{policy}/beneficiaries/import', 'PolicyBeneficiaryController@import')->name('policies.beneficiaries.import');
    Route::post('policies/{policy}/insureds/import', 'PolicyInsuredController@import')->name('policies.insureds.import');
    Route::post('policies/{policy}/vehicles/import', 'PolicyVehicleController@import')->name('policies.vehicles.import');
    Route::get('policies/export', 'PolicyController@export')->name('policies.export');
    Route::get('policies/{policy}/alerts', 'PolicyAlertController@index')->name('policies.alerts.index');
    Route::put('policies/{policy}/alerts', 'PolicyAlertController@update')->name('policies.alerts.update');
    Route::get('policies/{policy}/print', 'PolicyController@print')->name('policies.print');

    /* Accidents */
    Route::get('policies/{policy}/accidents', 'AccidentController@index')->name('policies.accidents.index');
    Route::get('policies/{policy}/accidents/create', 'AccidentController@create')->name('policies.accidents.create');
    Route::get('policies/{policy}/accidents/{accident}/edit', 'AccidentController@edit')->name('policies.accidents.edit');
    Route::post('policies/{policy}/accidents/store', 'AccidentController@store')->name('policies.accidents.store');
    Route::put('policies/{policy}/accidents/{accident}/update', 'AccidentController@update')->name('policies.accidents.update');
    Route::delete('policies/{policy}/accidents/{accident}/delete', 'AccidentController@destroy')->name('policies.accidents.destroy');
    Route::get('policies/accidents/export', 'AccidentController@exportAll')->name('policies.accidents.export_all');
    Route::get('policies/{policy}/accidents/export', 'AccidentController@export')->name('policies.accidents.export');

    /* Claims */
    Route::get('policies/{policy}/claims', 'ClaimController@index')->name('policies.claims.index');
    Route::get('policies/{policy}/claims/create', 'ClaimController@create')->name('policies.claims.create');
    Route::get('policies/{policy}/claims/{claim}/edit', 'ClaimController@edit')->name('policies.claims.edit');
    Route::post('policies/{policy}/claims/store', 'ClaimController@store')->name('policies.claims.store');
    Route::put('policies/{policy}/claims/{claim}/update', 'ClaimController@update')->name('policies.claims.update');
    Route::delete('policies/{policy}/claims/{claim}/delete', 'ClaimController@destroy')->name('policies.claims.destroy');
    Route::get('policies/claims/export', 'ClaimController@exportAll')->name('policies.claims.export_all');
    Route::get('policies/{policy}/claims/export', 'ClaimController@export')->name('policies.claims.export');

    Route::get('renewal', 'RenewalController@index')->name('renewal.index');
    Route::get('renewal/report', 'RenewalController@report')->name('renewal.report');
    Route::get('renewal/{policy}', 'RenewalController@show')->name('renewal.show');
    Route::put('renewal/{policy}', 'RenewalController@update')->name('renewal.update');

    Route::get('loyalties', 'LoyaltyController@index')->name('loyalties.index');
    Route::get('loyalties/{policy}', 'LoyaltyController@show')->name('loyalties.show');
    Route::put('loyalties/{policy}', 'LoyaltyController@update')->name('loyalties.update');

    Route::get('surveys', 'SurveyController@index')->name('surveys.index');
    Route::get('surveys/{policy}', 'SurveyController@show')->name('surveys.show');
    Route::put('surveys/{policy}', 'SurveyController@update')->name('surveys.update');

    Route::get('bank_checks/recycle-bin', 'BankCheckController@disabled')->name('bank_checks.disabled');
    Route::put('bank_checks/{bank_check}/disable', 'BankCheckController@disable')->name('bank_checks.disable');

    Route::get('payment_collections/recycle-bin', 'PaymentCollectionController@disabled')->name('payment_collections.disabled');
    Route::put('payment_collections/{payment_collection}/disable', 'PaymentCollectionController@disable')->name('payment_collections.disable');

    Route::get('finances/recycle-bin', 'FinanceController@disabled')->name('finances.disabled');
    Route::put('finances/{finance}/disable', 'FinanceController@disable')->name('finances.disable');

    Route::get('payment_applications/recycle-bin', 'PaymentApplicationController@disabled')->name('payment_applications.disabled');
    Route::put('payment_applications/{payment_application}/disable', 'PaymentApplicationController@disable')->name('payment_applications.disable');

    Route::get('users/migrate/{employee}', 'UserController@migrate')->name('users.migrate');

    Route::get('profile', 'ProfileController@edit')->name('profile.edit');
    Route::post('profile', 'ProfileController@update')->name('profile.update');

    Route::get('profile/change-password', 'ChangePasswordController@edit')->name('password.edit');
    Route::put('profile/change-password', 'ChangePasswordController@update')->name('password.update');

    Route::post('payings/liquidate', 'PayingController@liquidate')->name('payings.liquidate');
    Route::get('payings/balance', 'PayingController@report')->name('payings.balance');

    Route::get('auth/login-as/{id}', 'AuthController@loginAs')->name('auth.loginAs');

    Route::get('leads/export', 'LeadController@export')->name('leads.export');
    Route::get('leads/dashboard', 'LeadController@dashboard')->name('leads.dashboard');

    Route::get('appointments/dashboard', 'AppointmentController@dashboard')->name('appointments.dashboard');
    Route::get('appointments/dashboard/detail', 'AppointmentController@dashboardDetail')->name('appointments.dashboard.detail');

    Route::resource('appointments', 'AppointmentController');
    Route::resource('bank_checks', 'BankCheckController');
    Route::resource('comments', 'CommentController');
    Route::resource('customers', 'CustomerController');
    Route::resource('employees', 'EmployeeController');
    Route::resource('finances', 'FinanceController');
    Route::resource('companies', 'CompanyController');
    Route::resource('companies.sectors', 'SectorController');
    Route::resource('companies.sectors.products', 'ProductController');
    Route::resource('payment_applications', 'PaymentApplicationController');
    Route::resource('payment_collections', 'PaymentCollectionController');
    Route::resource('payment_delayeds', 'PaymentDelayedController');
    Route::resource('payment-delayed-log', 'PaymentDelayedImportLogController');
    Route::resource('policies.beneficiaries', 'PolicyBeneficiaryController');
    Route::resource('policies.insureds', 'PolicyInsuredController');
    Route::resource('policies.vehicles', 'PolicyVehicleController');
    Route::resource('policies.documents', 'PolicyDocumentController');
    Route::resource('policies.comments', 'PolicyCommentController');
    Route::resource('policies.payments', 'PolicyPaymentController');
    Route::resource('policies', 'PolicyController');
    // Route::resource('accidents', 'AccidentController');
    Route::resource('tickets', 'TicketController');
    Route::resource('documents', 'DocumentController');
    Route::resource('settings/users', 'UserController');
    Route::resource('settings/spreadsheet', 'SettingSpreadsheetController');
    Route::resource('payings', 'PayingController');
    Route::resource('payings.items', 'PayingItemController');
    Route::resource('payings-log', 'PayingImportLogController');
    Route::resource('leads', 'LeadController');
});


Route::get('leads-update', function () {
    $leads = Lead::all();
    $leads->each(function (Lead $lead) {
        $supervisor = $lead->assessor->getSupervisor();
        if ($supervisor > 0) {
            $lead->setAttribute('supervisor_id', $supervisor)->save();
        }
    });
});

Route::get('leads-last-action-update', function () {
    $comments = Comment::query()->where('commentable_type', 'App\Lead')->whereNotNull('actions');
    $comments->each(function (Comment $comment) {
        $lead = Lead::query()->find($comment->commentable_id);
        $lead->last_action = $comment->actions;
        $lead->save();
    });
});
