<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'auth:api', 'namespace' => 'Api'], function () {
    Route::post('payings/import', 'PayingController@import');

    Route::resource('calendar', 'CalendarController');
    Route::resource('calendar-leads', 'CalendarLeadController');
    Route::get('calendar-lead-appointments', 'CalendarController@leadAppointment');
    Route::resource('companies', 'CompanyController');
    Route::resource('customers', 'CustomerController');
    Route::resource('employees', 'EmployeeController');
    Route::resource('keys', 'KeyController');
    Route::resource('policies', 'PolicyController');
    Route::resource('products', 'ProductController');
    Route::resource('sectors', 'SectorController');
    Route::resource('payings', 'PayingController');
    Route::resource('comments', 'CommentController');
    Route::resource('comment-actions', 'CommentActionController');

    Route::post('policies/files/upload', 'PolicyController@uploadFiles');

    Route::get('chart/policies/best', 'ChartPolicyController@best');
    Route::get('chart/policies/year', 'ChartPolicyController@year');
    Route::get('chart/policies/year-stack', 'ChartPolicyController@yearStack');
    Route::get('chart/policies/stock', 'ChartPolicyController@stock');
    Route::get('chart/policies/stock-table', 'ChartPolicyController@stockTable');
    Route::get('chart/policies/status', 'ChartPolicyController@status');
    Route::get('chart/policies/groups-table', 'ChartPolicyController@groupsTable');
    Route::get('chart/currencies', 'ChartController@currencies');
    Route::get('chart/years', 'ChartController@years');
    Route::get('chart/companies', 'ChartController@companies');
    Route::get('chart/sectors', 'ChartController@sectors');
    Route::get('chart/products', 'ChartController@products');
    Route::get('chart/sell-types', 'ChartController@sellTypes');
    Route::get('chart/employees/types', 'ChartController@employeeTypes');
    Route::get('chart/employees', 'ChartController@employees');
    Route::get('chart/assessors', 'ChartController@assessors');
    Route::get('chart/policies/top', 'ChartPolicyController@top');
    Route::get('chart/policies/stair', 'ChartPolicyController@stair');
    Route::get('chart/policies/renewals', 'ChartPolicyController@renewal');
    Route::get('chart/leads/counters', 'ChartLeadController@counters');
    Route::get('chart/leads/ratios', 'ChartLeadController@ratios');
    Route::get('chart/leads/leads-actions', 'ChartLeadController@leadsActions');
    Route::get('chart/leads/table-leads-actions', 'ChartLeadController@tableLeadsActions');
    Route::get('chart/leads/actions', 'ChartLeadController@actions');
    Route::get('chart/leads', 'ChartLeadController@index');
    Route::get('chart/top-types', 'ChartController@topTypes');

    Route::group([], function () {
        Route::get('crm/dashboard/details', 'LeadAppointmentController@dashboardDetail')->name('api.appointments.dashboard.detail');
        Route::get('crm/leads/{lead}/appointments/status', 'LeadAppointmentController@status');
        Route::resource('crm/leads/{lead}/appointments', 'LeadAppointmentController');
    });
});

