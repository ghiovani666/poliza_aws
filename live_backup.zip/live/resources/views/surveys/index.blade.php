@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Encuesta</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Encuesta</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <div class="mb-2">
                            {{ Form::open(['url' => route('surveys.index'), 'method' => 'GET']) }}
                            <label>Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Numero de poliza</label>
                            {{ Form::text('code', request('code'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Encuesta</label>
                            {{ Form::select('survey_answered', [1=>'Si', 0=>'No'], request('survey_answered'), ['class' => 'form-control', 'style' => 'width: 120px; display: inline', 'placeholder' => '- Seleccionar -']) }}

                            <button class="btn btn-primary">Buscar</button>
                            <a href="/surveys" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Contratante</th>
                                <th>Poliza</th>
                                <th>Vigencia</th>
                                <th>Compañia</th>
                                <th>Moneda</th>
                                <th>Prima Neta</th>
                                <th>Tipo de venta</th>
                                <th>Asesor</th>
                                <th>Status</th>
                                <th>Encuesta</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($policies as $policy)
                                <tr>
                                    <td>{{ $policy->id }}</td>
                                    <td>
                                        {{ $policy->customer->name }}
                                        <div class="d-inline" data-toggle="modal"
                                             data-target="#quickModal{{ $policy->id }}"
                                             style="cursor: pointer; color: blue">
                                            <i class="fas fa-eye"></i>
                                        </div>
                                    </td>
                                    <td>{{ $policy->code }}</td>
                                    <td>{{ $policy->validity_date }}</td>
                                    <td>{{ $policy->id }}</td>
                                    <td>{{ $policy->currency === 0 ? 'Soles':'Dolares'  }}</td>
                                    <td>{{ $policy->prime }}</td>
                                    <td>{{ \App\Enums\SellType::getDescription($policy->sell_type) }}</td>
                                    <td>{{ $policy->assessor->name }}</td>
                                    <td>{{ $policy->status->name }}</td>
                                    <td>{{ $policy->surveyAnswer }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        <a class="btn btn-secondary btn-sm"
                                           href="{{ route('surveys.show',$policy) }}">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $policies->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
