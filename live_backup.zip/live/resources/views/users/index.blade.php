@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Usuarios</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Usuarios</li>
                    </ol>
                </nav>
                <div class="float-right"></div>
                <div class="card">
                    <div class="card-body">
                        <form method="get">
                            <div class="mb-2">
                                <div class="d-inline mr-4">
                                    <label class="mr-2">Nombre</label>
                                    <div class="d-md-inline-block" style="width: 200px">
                                        <input class="form-control" name="name" value="{{ request('name') }}">
                                    </div>
                                </div>
                                <div class="d-inline mr-4">
                                    <label class="mr-2">Email</label>
                                    <div class="d-md-inline-block" style="width: 200px">
                                        <input class="form-control" name="email" value="{{ request('email') }}">
                                    </div>
                                </div>
                                <div class="d-inline mr-4">
                                    <label class="mr-2">Tipo</label>
                                    <div class="d-md-inline-block" style="width: 200px">
                                        {{ Form::select('type_id', dropdownData('EmployeeType'), request('type_id'), ['class' => 'form-control', 'placeholder' => '- Todos -']) }}
                                    </div>
                                </div>
                                <div class="d-inline mr-4">
                                    <button class="btn btn-primary">Buscar</button>
                                    <a class="btn btn-secondary" href="/settings/users">Resetear</a>
                                </div>
                            </div>
                        </form>

                        @include('flash::message')

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Tipo</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($employees as $employee)
                                <tr>
                                    <td>{{ $employee->id }}</td>
                                    <td>{{ $employee->name }}</td>
                                    <td>{{ $employee->email }}</td>
                                    <td>{{ $employee->job->name }}</td>
                                    <td>{{ $employee->hasUser ? 'Si' : 'No' }}</td>
                                    <td class="text-right">
                                        @if($employee->hasUser && Auth::user()->can('loginAs'))
                                            <a href="{{ route('auth.loginAs', $employee->user->id) }}" title="login as"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-sign-in-alt"></i></a>
                                        @endif
                                        @if(!$employee->hasUser && Auth::user()->can('migrate', $employee))
                                            <a href="{{ route('users.migrate', $employee) }}" title="Crear Usuario"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-user"></i></a>
                                        @endif
                                        @if($employee->hasUser && Auth::user()->can('update', $employee))
                                            <a href="{{ route('users.edit', $employee->user->id) }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        @endif
                                        @if($employee->hasUser && Auth::user()->can('delete', $employee))
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $employee->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $employees->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($employees as $employee)
        @if($employee->hasUser)
            <div class="modal fade" id="deleteModal{{$employee->id}}" tabindex="-1" role="dialog"
                 aria-labelledby="deleteModalLongTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="h4 text-center mb-3">¿Seguro que desea eliminar el usuario?</div>
                        </div>
                        <div class="modal-footer">
                            {{ Form::open(['url' => route('users.destroy', $employee->user_id), 'method' => 'DELETE']) }}
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-danger">Si, eliminar</button>
                            {{ Form::close() }}
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endforeach
@endsection
