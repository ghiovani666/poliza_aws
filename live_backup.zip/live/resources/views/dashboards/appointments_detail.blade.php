@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Citas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="/appointments/dashboard">Dashboard</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Detalles</li>
                    </ol>
                </nav>

                <div class="card mb-3">
                    <div class="card-body">
                        <div class="card-title">{{ $employee->job->name }} : {{ $employee->name }}</div>

                        <div class="my-2">{{ $range }}</div>

                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Cliente</th>
                                <th>Numero de cita</th>
                                <th>Telefono</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($appointments as $appointment)
                                <tr>
                                    <td>{{ $appointment->lead->name }}</td>
                                    <td>{{ $appointment->numberName }}</td>
                                    <td>{{ $appointment->lead->phone }}</td>
                                    <td>{{ $appointment->date->format('d/m/Y') }}</td>
                                    <td>{{ $appointment->date->format('h:i A') }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="5">No se encontraron registros</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
