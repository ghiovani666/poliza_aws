<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-counter :type="1" filter-year-enabled filter-company-enabled></chart-counter>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <chart-filters :with-assessor="false"></chart-filters>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-bar-year name="abc" title="Grafico 1" type="1"></chart-bar-year>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-table-top
                        label="Grafico 2 - Top 10 {{ date('F Y') }}"
                        currency="PEN"
                        :ignore-global-filters="true"
                    ></chart-table-top>

                    <chart-table-top
                        label="Grafico 2 - Top 10 {{ date('F Y') }}"
                        currency="USD"
                        :ignore-global-filters="true"
                    ></chart-table-top>
                </div>
            </div>
        </div>
    </div>
</div>
