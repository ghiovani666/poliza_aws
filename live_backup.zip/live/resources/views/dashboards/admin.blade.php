<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-counter filter-year-enabled filter-company-enabled></chart-counter>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-bar-year name="abc" title="Grafico 1" type="8"></chart-bar-year>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-table-counter></chart-table-counter>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-table-top currency="PEN"></chart-table-top>

                    <chart-table-top currency="USD" class="mt-5"></chart-table-top>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-table-year currency="PEN"></chart-table-year>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <chart-table-groups></chart-table-groups>
                </div>
            </div>
        </div>
    </div>
</div>

@if(!is_null($setting))
    <div class="container-fluid mb-4">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        {!! str_replace('<iframe','<iframe width="100%" height="600px" style="border:none;" ',$setting->value) !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif
