<div id="chart-page" class="container-fluid mb-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="mb-3">
                <chart-filter name="year" label="Año" endpoint="chart/years"></chart-filter>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <chart-bar-year-stack name="AnualPEN" title="Renovaciones Anuales PEN" currency="PEN" type="5"></chart-bar-year-stack>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <chart-bar-year-stack name="AnualUSD" title="Renovaciones Anuales USD" currency="USD" type="5"></chart-bar-year-stack>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <chart-table-renew></chart-table-renew>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <chart-bar-year name="abc" title="Monto Polizas Anuladas" type="5"></chart-bar-year>
                </div>
            </div>
        </div>
    </div>
</div>
