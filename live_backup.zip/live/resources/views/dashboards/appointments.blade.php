@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Citas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Citas</li>
                    </ol>
                </nav>

                <crm-dashboard-filters
                        :type-options="{{ json_encode($types) }}"
                        :type-selected=" {{ json_encode($typeSelected) }}"
                        :status-options="{{ json_encode($statuses) }}"
                        :status-selected=" {{ json_encode($statusSelected) }}"
                        :year-options="{{ json_encode($years) }}"
                        :year-selected="{{ $yearSelected }}"
                        :month-options="{{ json_encode($months) }}"
                        :month-selected="{{ json_encode($monthSelected) }}"
                        :week-options="{{ json_encode($weeks) }}"
                        :week-selected="{{ $weekSelected }}"
                        :admin-options="{{ json_encode($admins) }}"
                        :admin-selected="{{ json_encode($adminSelected) }}"
                        :supervisor-options="{{ json_encode($supervisors) }}"
                        :supervisor-selected="{{ json_encode($supervisorSelected) }}"
                        :assessor-options="{{ json_encode($assessors) }}"
                        :assessor-selected="{{ json_encode($assessorSelected) }}"
                ></crm-dashboard-filters>

                @if(request('filters') === 'execute')
                    <div class="h3">{{ $year }} - {{ $monthSelected['name'] }} - Semana {{ $weekSelected }}</div>

                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="card-title">Semana: {{ $weekSelected }}</div>
                            <table class="table table-striped table-striped-columns table-appointments">
                                <thead>
                                <tr>
                                    <th rowspan="3" style="vertical-align: middle">Asesor</th>
                                    <th rowspan="3" style="vertical-align: middle">Tipo de usuario</th>
                                    <th colspan="21" class="text-center">Fecha</th>
                                </tr>
                                <tr>
                                    @foreach($days as $index => $day)
                                        <th colspan="3" class="text-center">{{ $day }} {{ $index }}</th>
                                    @endforeach
                                </tr>
                                <tr>
                                    @foreach($days as $index => $day)
                                        <th>1ra</th>
                                        <th>2ra</th>
                                        <th>3ra</th>
                                    @endforeach
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($employees as $employee)
                                    <tr>
                                        <td>{{ $employee->name }}</td>
                                        <td>{{ $employee->job->name }}</td>
                                        @foreach($weekDays as $day)
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByDay($day, $employee, request(), 1) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', request()->query() + ['employee_id' => $employee, 'day' => $day->toDateString()]) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByDay($day, $employee, request(),2) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', request()->query() + ['employee_id' => $employee, 'day' => $day->toDateString()]) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByDay($day, $employee, request(),3) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', request()->query() + ['employee_id' => $employee, 'day' => $day->toDateString()]) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                        @endforeach
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="card-title">Mes: {{ $monthSelected['name'] }}</div>
                            <table class="table table-striped table-striped-columns table-appointments">
                                <thead>
                                <tr>
                                    <th rowspan="2" style="vertical-align: middle">Asesor</th>
                                    <th rowspan="2" style="vertical-align: middle">Tipo de usuario</th>
                                    @foreach($weeks as $week)
                                        <th colspan="3" class="text-center">{{ $week }}</th>
                                    @endforeach
                                </tr>
                                <tr>
                                    @foreach($weeks as $week)
                                        <th>1ra</th>
                                        <th>2ra</th>
                                        <th>3ra</th>
                                    @endforeach
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($employees as $employee)
                                    <tr>
                                        <td>{{ $employee->name }}</td>
                                        <td>{{ $employee->job->name }}</td>
                                        @foreach($weeks as $week)
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByWeek($year, $week, $employee, request(),1) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => $week])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByWeek($year, $week, $employee, request(),2) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => $week])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByWeek($year, $week, $employee, request(),3) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => $week])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                        @endforeach
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="card-title">Año: {{ $year }}</div>
                            <table class="table table-striped table-striped-columns table-appointments">
                                <thead>
                                <tr>
                                    <th rowspan="2" style="vertical-align: middle">Asesor</th>
                                    <th rowspan="2" style="vertical-align: middle">Tipo de usuario</th>
                                    @foreach($months as $month)
                                        <th colspan="3" class="text-center">{{ $month['name'] }}</th>
                                    @endforeach
                                </tr>
                                <tr>
                                    @foreach($months as $month)
                                        <th>1ra</th>
                                        <th>2ra</th>
                                        <th>3ra</th>
                                    @endforeach
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($employees as $employee)
                                    <tr>
                                        <td>{{ $employee->name }}</td>
                                        <td>{{ $employee->job->name }}</td>
                                        @foreach($months as $month)
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByMonth($year, $month['id'], $employee, request(),1) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => '','month' => $month['id']])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByMonth($year, $month['id'], $employee, request(),2) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => '','month' => $month['id']])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                            <td>
                                                <link-to-modal
                                                        text="{{ \App\LeadAppointment::countByMonth($year, $month['id'], $employee, request(),3) }}"
                                                        url="{{ route('api.appointments.dashboard.detail', array_merge(request()->query(),['employee_id' => $employee, 'week' => '','month' => $month['id']])) }}"
                                                        modal-title="Detalles"
                                                >
                                                </link-to-modal>
                                            </td>
                                        @endforeach
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                @else
                    <div class="alert alert-info text-center font-weight-bold" style="font-size: 1.5rem">Use el boton "APLICAR FILTROS" para mostrar las citas.</div>
                @endif
            </div>
        </div>
    </div>

@endsection
@push('scripts')
    <script>
        window.addEventListener('DOMContentLoaded', (event) => {
        });
    </script>
@endpush
