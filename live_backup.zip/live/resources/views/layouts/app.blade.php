<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- API Token -->
    <meta name="api-token" content="{{ auth()->check() ? auth()->user()->api_token : null }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ mix('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ mix('css/app.css') }}" rel="stylesheet">
    @stack('styles')

    <script src="https://kit.fontawesome.com/b6ca2eeb80.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>

    @auth
        <script>window.User = @json(auth()->user());</script>
    @endauth
</head>
<body>
<div id="app">
    @include('layouts._navigation_top')

    <main class="py-4">
        @yield('content')
    </main>
    <footer class="text-center">
        <div>Morgan Web Application Beta 9.7</div>
        <div class="text-muted">This is a software powered by Laravel and developed by ABC LLC for Morgan y Asociados
        </div>
        <div class="text-muted">Todos los derechos reservados a Morgan & Asociados 2019</div>
    </footer>
</div>
@stack('scripts')
</body>
</html>
