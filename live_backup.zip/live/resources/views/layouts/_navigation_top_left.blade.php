<!-- Left Side Of Navbar -->
@if (auth()->check())
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-item nav-link" href="/">Inicio</a>
        </li>
        @can('view-any',\App\Employee::class)
            <li class="nav-item">
                <a class="nav-item nav-link" href="{{ route('employees.index') }}">Empleados</a>
            </li>
        @endcan
        @can('view-any',\App\Paying::class)
            <!-- Disable payment module
            <li class="nav-item">
                <a class="nav-item nav-link" href="{{ route('payings.index') }}">Liquidaciones</a>
            </li>
            -->
        @endcan
        @can('view-any',\App\Ticket::class)
            <!-- Disable ticket module
            <li class="nav-item">
                <a class="nav-item nav-link" href="{{ route('tickets.index') }}">Tickets</a>
            </li>
            -->
        @endcan
        @if (Auth::user()->can('view-any', \App\Policy::class) || Auth::user()->can('view-any', \App\Customer::class))
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle"
                   href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                   aria-expanded="false" v-pre>
                    Cartera de clientes <span class="caret"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @can('view-any',\App\Customer::class)
                        <a class="dropdown-item" href="{{ route('customers.index') }}">Clientes</a>
                    @endcan
                    @can('view-any',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('policies.index') }}">Polizas: Todas </a>
                    @endcan
                    @can('view-any',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('policies.index', ['status_id' => 1]) }}">
                            Polizas: En emisión
                        </a>
                    @endcan
                    @can('view-any',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('policies.index', ['status_id' => 3]) }}">
                            Polizas: En Agenciamiento
                        </a>
                    @endcan
                </div>
            </li>
        @endif
        @canany(['view-loyalty','view-survey','view-renewal','view-renewal-report'],\App\Policy::class)
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle" href="#"
                   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    Post-venta <span class="caret"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @can('view-loyalty',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('loyalties.index') }}">Fidelizacion</a>
                    @endcan
                    @can('view-survey',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('surveys.index') }}">Encuesta</a>
                    @endcan
                    @can('view-renewal',\App\Policy::class)
                        <a class="dropdown-item" href="{{ route('renewal.index') }}">Renovacion</a>
                    @endcan
                    @can('view-renewal-report',\App\Policy::class)
                        <!--
                        <a class="dropdown-item" href="{{ route('renewal.report') }}">Reporte</a>
                        -->
                    @endcan
                </div>
            </li>
        @endcanany

        @if (Auth::user()->can('view-any', \App\BankCheck::class)
            || Auth::user()->can('view-any', \App\PaymentCollection::class)
            || Auth::user()->can('view-any', \App\Finance::class)
            || Auth::user()->can('view-any', \App\PaymentApplication::class)
            || Auth::user()->can('view-any', \App\PaymentDelayed::class)
            || Auth::user()->can('report', \App\Paying::class)
        )
            <!--
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle" href="#"
                   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    Cobranzas <span class="caret"></span>
                </a>

                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @can('view-any',\App\BankCheck::class)
                        <a class="dropdown-item" href="{{ route('bank_checks.index') }}">Cheques</a>
                    @endcan
                    @can('view-any',\App\PaymentCollection::class)
                        <a class="dropdown-item" href="{{ route('payment_collections.index') }}">
                            Cambio de via cobro
                        </a>
                    @endcan
                    @can('view-any',\App\Finance::class)
                        <a class="dropdown-item" href="{{ route('finances.index') }}">Financiamientos</a>
                    @endcan
                    @can('view-any',\App\PaymentApplication::class)
                        <a class="dropdown-item" href="{{ route('payment_applications.index') }}">
                            Aplicaciones de pago
                        </a>
                    @endcan
                    @can('view-any',\App\PaymentDelayed::class)
                        <a class="dropdown-item" href="{{ route('payment_delayeds.index') }}"> Deudas</a>
                    @endcan
                    @can('report',\App\Paying::class)
                        <a class="dropdown-item" href="{{ route('payings.balance') }}"> Reporte</a>
                    @endcan
                </div>
            </li>
            -->
        @endif

        @if (Auth::user()->can('view-any', \App\Lead::class)
            || Auth::user()->can('dashboard', \App\Lead::class)
            || Auth::user()->can('view-any', \App\Appointment::class)
            || Auth::user()->can('dashboard', \App\Appointment::class)
            )
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle" href="#"
                   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    CRM <span class="caret"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @can('dashboard',\App\Lead::class)
                        <a class="dropdown-item" href="{{ route('leads.dashboard') }}">Dashboard</a>
                    @endcan
                    @can('view-any',\App\Lead::class)
                        <a class="dropdown-item" href="{{ route('leads.index') }}">Leads</a>
                    @endcan
                    @can('dashboard',\App\Appointment::class)
                        <a class="dropdown-item" href="{{ route('appointments.dashboard') }}">Citas</a>
                    @endcan
                    @can('view-any',\App\Appointment::class)
                        <a class="dropdown-item" href="{{ route('appointments.index') }}">Calendario</a>
                    @endcan
                </div>
            </li>
        @endif
        <li class="nav-item">
            <a class="nav-item nav-link" href="{{ route('documents.index') }}">Documentos</a>
        </li>
        @can('settings',\App\User::class)
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle" href="#"
                   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    Configuraciones <span class="caret"></span>
                </a>

                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @can('view-any',\App\User::class)
                        <a class="dropdown-item" href="{{ route('users.index') }}">Usuarios</a>
                    @endcan
                    @can('view-any',\App\Company::class)
                        <a class="dropdown-item" href="{{ route('companies.index') }}">Keys</a>
                    @endcan
                    @can('spreadsheet',\App\Appointment::class)
                        <a class="dropdown-item" href="{{ route('spreadsheet.index') }}">Google Sheet</a>
                    @endcan
                    @can('view-any',\App\Setting::class)
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="{{ route('settings.index') }}">Papelera</a>
                    @endcan
                </div>
            </li>
        @endcan

        <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link d-md-inline-block dropdown-toggle" href="#"
               role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                Reportes <span class="caret"></span>
            </a>

            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                @can('view-renewal-report',\App\Policy::class)
                    <a class="dropdown-item" href="{{ route('renewal.report') }}">Reporte Post-Venta</a>
                @endcan
                @can('report',\App\Paying::class)
                    <a class="dropdown-item" href="{{ route('payings.balance') }}"> Reporte Cobranzas</a>
                @endcan
            </div>
        </li>
    </ul>
@endif