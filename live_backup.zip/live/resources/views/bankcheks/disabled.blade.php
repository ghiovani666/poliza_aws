@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Queques</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('bank_checks.index') }}">Cheques</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Eliminados</li>
                    </ol>
                </nav>
                <div class="float-right"></div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="mb-2">
                            {{ Form::open(['url' => route('bank_checks.index'), 'method' => 'GET']) }}
                            <label>Documento (#)</label>
                            {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="{{ request('dates') }}" style="width: 200px">

                            <button class="btn btn-primary">Buscar</button>
                            <a href="{{ route('bank_checks.disabled') }}" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Contratante</th>
                                <th>Banco</th>
                                <th>Cheque</th>
                                <th>Cuenta de ahorro</th>
                                <th>Moneda</th>
                                <th>Monto</th>
                                <th>Depositado</th>
                                <th>Cargo de recepcion</th>
                                <th>Comments</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($bankChecks as $bankCheck)
                                <tr class="table-danger">
                                    <td>{{ $bankCheck->id }}</td>
                                    <td>{{ $bankCheck->createdDateTime }}</td>
                                    <td>{{ $bankCheck->company->name }}</td>
                                    <td>{{ $bankCheck->customer->name }}</td>
                                    <td>{{ $bankCheck->bank->name }}</td>
                                    <td>{{ $bankCheck->name }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->currency }}</td>
                                    <td>{{ $bankCheck->amount }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->comments }}</td>
                                    <td>{{ $bankCheck->user->name }}</td>
                                    <td class="text-right"></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $bankChecks->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="dates"]').daterangepicker({
                "autoApply": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
            }, function (start, end, label) {
                $('input[name="dates"]').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
            });
        };
    </script>
@endpush
