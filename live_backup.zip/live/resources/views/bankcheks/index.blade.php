@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Cheques</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Cheques</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('create',\App\BankCheck::class)
                        <a class="btn btn-primary" href="{{ route('bank_checks.create') }}"><i
                                class="fas fa-plus mr-2"></i>Nuevo</a>
                    @endcan
                    @can('view-deleted',\App\BankCheck::class)
                        <a class="btn btn-danger" href="{{ route('bank_checks.disabled') }}"><i
                                class="fas fa-trash-alt mr-2"></i>Eliminados</a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="mb-2">
                            {{ Form::open(['url' => route('bank_checks.index'), 'method' => 'GET']) }}
                            <label>Documento (#)</label>
                            {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="{{ request('dates') }}" style="width: 200px">

                            <button class="btn btn-primary">Buscar</button>
                            <a href="/bank_checks" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Contratante</th>
                                <th>Banco</th>
                                <th>Cheque</th>
                                <th>Cuenta de ahorro</th>
                                <th>Moneda</th>
                                <th>Monto</th>
                                <th>Depositado</th>
                                <th>Cargo de recepcion</th>
                                <th>Comments</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($bankChecks as $bankCheck)
                                <tr>
                                    <td>{{ $bankCheck->id }}</td>
                                    <td>{{ $bankCheck->createdDateTime }}</td>
                                    <td>{{ $bankCheck->company->name }}</td>
                                    <td>{{ $bankCheck->customer->name }}</td>
                                    <td>{{ $bankCheck->bank->name }}</td>
                                    <td>{{ $bankCheck->name }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->currency }}</td>
                                    <td>{{ $bankCheck->amount }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->account_number }}</td>
                                    <td>{{ $bankCheck->comments }}</td>
                                    <td>{{ $bankCheck->user->name }}</td>
                                    <td class="text-right" style="white-space: nowrap">
                                        @can('update',$bankCheck)
                                            <a href="{{ route('bank_checks.edit', $bankCheck) }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        @endcan
                                        @can('delete',$bankCheck)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $bankCheck->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $bankChecks->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($bankChecks as $bankCheck)
        <div class="modal fade" id="deleteModal{{$bankCheck->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el cheque?</div>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('bank_checks.disable', $bankCheck), 'method' => 'PUT']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="dates"]').daterangepicker({
                "autoApply": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
            }, function (start, end, label) {
                $('input[name="dates"]').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
            });
        };
    </script>
@endpush
