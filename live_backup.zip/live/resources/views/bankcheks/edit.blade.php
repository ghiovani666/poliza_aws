@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Cheques</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('bank_checks.index') }}">Cheques</a></li>
                        <li class="breadcrumb-item"><a
                                href="{{ route('bank_checks.edit',$bankCheck) }}">{{ $bankCheck->name }}</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Actualizar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::model($bankCheck,['url' => route('bank_checks.update', $bankCheck), 'method' => 'PUT']) }}
                        @include('bankcheks._form')
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        let company_id = @json($bankCheck->company_id);
        let sector_id = @json($bankCheck->sector_id);
        let product_id = @json($bankCheck->product_id);

        window.onload = function () {
            $('select[name=company_id]').select2();
            $('select[name=sector_id]').select2();
            $('select[name=product_id]').select2();
            $('select[name=customer_id]').select2();
            $('select[name=bank_id]').select2();

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                fetchSectors(company_id);
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                fetchProducts(sector_id);
            });

            fetchSectors(company_id);
            fetchProducts(sector_id);
        };

        function fetchSectors(company_id) {
            axios.get('/api/sectors?company_id=' + company_id).then((response) => {
                $('select[name=sector_id]').empty();
                response.data.data.forEach(function (sector) {
                    $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    if (sector_id > 0) {
                        $('select[name=sector_id]').val(sector_id);
                    }
                });
            });
        }

        function fetchProducts(sector_id) {
            axios.get('/api/products?sector_id=' + sector_id).then((response) => {
                $('select[name=product_id]').empty();
                response.data.data.forEach(function (sector) {
                    $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                    if (product_id > 0) {
                        $('select[name=product_id]').val(product_id);
                    }
                });
            });
        }
    </script>
@endpush
