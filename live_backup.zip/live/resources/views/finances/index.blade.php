@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Financiamiento</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Financiamientos</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('create', \App\Finance::class)
                        <a class="btn btn-primary" href="{{ route('finances.create') }}"><i
                                class="fas fa-plus mr-2"></i>Nuevo</a>
                    @endcan
                    @can('view-disabled', \App\Finance::class)
                        <a class="btn btn-danger" href="{{ route('finances.disabled') }}"><i
                                class="fas fa-trash-alt mr-2"></i>Eliminados</a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="mb-2">
                            {{ Form::open(['url' => route('finances.index'), 'method' => 'GET']) }}
                            <label>Documento (#)</label>
                            {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="{{ request('dates') }}" style="width: 200px">

                            <label class="ml-3">Status</label>
                            {{ Form::select('status', $cboStatus, request('status'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <button class="btn btn-primary ml-3">Buscar</button>
                            <a href="{{ route('finances.index') }}" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Ticket</th>
                                <th>Asesor</th>
                                <th>Cliente</th>
                                <th>Poliza</th>
                                <th>Producto</th>
                                <th>Cuotas (#)</th>
                                <th>TIpo de doc</th>
                                <th>Financiamiento</th>
                                <th>Status</th>
                                <th>Observaciones</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($finances as $finance)
                                <tr>
                                    <td>{{ $finance->id }}</td>
                                    <td>{{ $finance->createdDateTime }}</td>
                                    <td>{{ $finance->company->name }}</td>
                                    <td>{{ $finance->ticket }}</td>
                                    <td>{{ $finance->assessor->name }}</td>
                                    <td>{{ $finance->customer->name }}</td>
                                    <td>{{ $finance->policy->code }}</td>
                                    <td>{{ $finance->product->name }}</td>
                                    <td>{{ $finance->dues }}</td>
                                    <td>{{ $finance->paymentTypeName }}</td>
                                    <td>{{ $finance->finance }}</td>
                                    <td>{{ $finance->statusName }}</td>
                                    <td>{{ $finance->comments }}</td>
                                    <td>{{ $finance->user->name }}</td>
                                    <td class="text-right" style="white-space: nowrap">
                                        @can('update', $finance)
                                            <a href="{{ route('finances.edit', $finance) }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        @endcan
                                        @can('disable', $finance)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $finance->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $finances->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($finances as $finance)
        <div class="modal fade" id="deleteModal{{$finance->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el financiamiento?</div>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('finances.disable', $finance), 'method' => 'PUT']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="dates"]').daterangepicker({
                "autoApply": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
            }, function (start, end, label) {
                $('input[name="dates"]').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
            });
        };
    </script>
@endpush
