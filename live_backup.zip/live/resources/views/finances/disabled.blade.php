@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Financiamiento</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('finances.index') }}">Financiamiento</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Eliminados</li>
                    </ol>
                </nav>
                <div class="float-right"></div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="mb-2">
                            {{ Form::open(['url' => route('finances.disabled'), 'method' => 'GET']) }}
                            <label>Documento (#)</label>
                            {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="{{ request('dates') }}" style="width: 200px">

                            <button class="btn btn-primary">Buscar</button>
                            <a href="{{ route('finances.disabled') }}" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Ticket</th>
                                <th>Asesor</th>
                                <th>Cliente</th>
                                <th>Poliza</th>
                                <th>Producto</th>
                                <th>Cuotas (#)</th>
                                <th>TIpo de doc</th>
                                <th>Financiamiento</th>
                                <th>Status</th>
                                <th>Observaciones</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($finances as $finance)
                                <tr class="table-danger">
                                    <td>{{ $finance->id }}</td>
                                    <td>{{ $finance->createdDateTime }}</td>
                                    <td>{{ $finance->company->name }}</td>
                                    <td>{{ $finance->ticket }}</td>
                                    <td>{{ $finance->assessor->name }}</td>
                                    <td>{{ $finance->customer->name }}</td>
                                    <td>{{ $finance->policy->code }}</td>
                                    <td>{{ $finance->product->name }}</td>
                                    <td>{{ $finance->dues }}</td>
                                    <td>{{ $finance->paymentTypeName }}</td>
                                    <td>{{ $finance->finance }}</td>
                                    <td>{{ $finance->statusName }}</td>
                                    <td>{{ $finance->comments }}</td>
                                    <td>{{ $finance->user->name }}</td>
                                    <td class="text-right"></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $finances->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="dates"]').daterangepicker({
                "autoApply": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
            }, function (start, end, label) {
                $('input[name="dates"]').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
            });
        };
    </script>
@endpush
