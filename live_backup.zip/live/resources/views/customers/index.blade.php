@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Clientes</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Clientes</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('create', \App\Customer::class)
                        <a class="btn btn-primary" href="{{ route('customers.create') }}">
                            <i class="fas fa-plus"></i>Nuevo
                        </a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">
                        <form method="get">
                            <div class="mb-2">
                                <div class="d-inline mr-4">
                                    <label class="mr-2">Nombre</label>
                                    <div class="d-md-inline-block" style="width: 200px">
                                        <input class="form-control" name="name" value="{{ request('name') }}">
                                    </div>
                                </div>
                                <div class="d-inline mr-4">
                                    <label class="mr-2">DNI</label>
                                    <div class="d-md-inline-block" style="width: 200px">
                                        <input class="form-control" name="dni" value="{{ request('dni') }}">
                                    </div>
                                </div>
                                <div class="d-inline mr-4">
                                    <button class="btn btn-primary">Buscar</button>
                                    <a class="btn btn-secondary" href="/customers">Resetear</a>
                                </div>
                            </div>
                        </form>

                        @include('flash::message')

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Documento (#)</th>
                                <th>Polizas (#)</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($customers as $customer)
                                <tr>
                                    <td>{{ $customer->id }}</td>
                                    <td>{{ $customer->name }}</td>
                                    <td>{{ $customer->document_number }}</td>
                                    <td>{{ $customer->policies_count }}</td>
                                    <td>{{ $customer->phone }}</td>
                                    <td>{{ $customer->email }}</td>
                                    <td class="text-right">
                                        @can('view', $customer)
                                            <a href="{{ route('customers.show', $customer) }}"
                                               class="btn btn-secondary btn-sm">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('update', $customer)
                                            <a href="{{ route('customers.edit', $customer) }}"
                                               class="btn btn-secondary btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @endcan
                                        @can('delete', $customer)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $customer->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $customers->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($customers as $customer)
        <div class="modal fade" id="deleteModal{{$customer->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar el cliente?</div>
                        <table class="table">
                            <tr>
                                <td>Cliente</td>
                                <td>{{ $customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Documento (#)</td>
                                <td>{{ $customer->document_number }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('customers.destroy', $customer), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
