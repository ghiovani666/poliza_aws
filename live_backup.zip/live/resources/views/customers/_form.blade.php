<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Teléfono</label>
            <div class="col">
                {{ Form::text('phone', null, ['class' => 'form-control'.($errors->has('phone') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('phone') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Correo electronico</label>
            <div class="col">
                {{ Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('email') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de documento</label>
            <div class="col">
                {{ Form::select('document_type', dropdownData('DocumentTypes'), null, ['class' => 'form-control'.($errors->has('document_type') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('document_type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Numero de documento</label>
            <div class="col">
                {{ Form::text('document_number', null, ['class' => 'form-control'.($errors->has('document_number') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('document_number') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de nacimiento</label>
            <div class="col">
                {{ Form::date('birth_date', null, ['class' => 'form-control'.($errors->has('birth_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('birth_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Direccion</label>
            <div class="col">
                {{ Form::text('address', null, ['class' => 'form-control'.($errors->has('address') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('address') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Departamento</label>
            <div class="col">
                {{ Form::text('state', null, ['class' => 'form-control'.($errors->has('state') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('state') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Provincia</label>
            <div class="col">
                {{ Form::text('province', null, ['class' => 'form-control'.($errors->has('province') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('province') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Distrito</label>
            <div class="col">
                {{ Form::text('city', null, ['class' => 'form-control'.($errors->has('city') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('city') }}</div>
            </div>
        </div>
    </div>
    <div class="col"></div>
</div>
