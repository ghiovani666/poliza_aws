@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="h2 d-inline-block text-uppercase">Clientes</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('customers.index') }}">Clientes</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $customer->name }}</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Informacion</div>
                        <div class="row">
                            <div class="col-2 text-center">
                                <i class="fas fa-user-circle mt-2" style="font-size: 5rem;"></i>
                            </div>
                            <div class="col">
                                <table class="table table-borderless table-sm table-hover">
                                    <tr>
                                        <td>Nombre</td>
                                        <td>{{ $customer->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Tipo de documento</td>
                                        <td>{{ $customer->documentTypeName }}</td>
                                    </tr>
                                    <tr>
                                        <td>Numero de documento</td>
                                        <td>{{ $customer->document_number }}</td>
                                    </tr>
                                    <tr>
                                        <td>Direccion</td>
                                        <td>{{ $customer->address }}</td>
                                    </tr>
                                    <tr>
                                        <td>Telefono</td>
                                        <td>{{ $customer->phone }}</td>
                                    </tr>
                                    <tr>
                                        <td>Correo electronico</td>
                                        <td>{{ $customer->email }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col">
                                <table class="table table-borderless table-sm table-hover">
                                    <tr>
                                        <td>Departamento</td>
                                        <td>{{ $customer->state }}</td>
                                    </tr>
                                    <tr>
                                        <td>Provincia</td>
                                        <td>{{ $customer->province }}</td>
                                    </tr>
                                    <tr>
                                        <td>Distrito</td>
                                        <td>{{ $customer->city }}</td>
                                    </tr>
                                    <tr>
                                        <td>Fecha de nacimiento</td>
                                        <td>{{ $customer->birthDateString }}</td>
                                    </tr>
                                    <tr>
                                        <td>Fecha de registro</td>
                                        <td>{{ $customer->createdDateTime }}</td>
                                    </tr>
                                </table>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="card-title">Polizas</div>
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>Poliza</th>
                                        <th>Empresa</th>
                                        <th>Ramo</th>
                                        <th>Producto</th>
                                        <th>Broker</th>
                                        <th>Asesor</th>
                                        <th>F. Registro</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($customer->policies as $policy)
                                        <tr>
                                            <td>{{ $policy->code }}</td>
                                            <td>{{ $policy->company->name }}</td>
                                            <td>{{ $policy->sector->name }}</td>
                                            <td>{{ $policy->product->name }}</td>
                                            <td>{{ $policy->broker->name }}</td>
                                            <td>{{ $policy->assessor->name }}</td>
                                            <td>{{ $policy->createdDateTime }}</td>
                                            <td class="text-right">
                                                <a href="{{ route('policies.documents.index', $policy) }}" class="btn btn-secondary btn-sm"><i
                                                        class="fas fa-file-eye"></i></a>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="10" class="text-center">No se encontraron registros.</td>
                                        </tr>
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
