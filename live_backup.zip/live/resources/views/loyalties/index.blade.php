@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Fidelización</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Fidelización</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <div class="mb-2">
                            {{ Form::open(['url' => route('loyalties.index'), 'method' => 'GET']) }}
                            <label>Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Numero de poliza</label>
                            {{ Form::text('code', request('code'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fidelización</label>
                            {{ Form::select('is_service_ok', [1=>'Si', 0=>'No'], request('is_service_ok'), ['class' => 'form-control', 'style' => 'width: 120px; display: inline', 'placeholder' => '- Seleccionar -']) }}

                            <button class="btn btn-primary">Buscar</button>
                            <a href="/loyalties" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Contratante</th>
                                <th>Poliza</th>
                                <th>Vigencia</th>
                                <th>Compañia</th>
                                <th>Moneda</th>
                                <th>Prima Neta</th>
                                <th>Tipo de venta</th>
                                <th>Asesor</th>
                                <th>Status</th>
                                <th>Fidelización</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($policies as $policy)
                                <tr>
                                    <td>{{ $policy->id }}</td>
                                    <td>
                                        {{ $policy->customer->name }}
                                        <div class="d-inline" data-toggle="modal"
                                             data-target="#quickModal{{ $policy->id }}"
                                             style="cursor: pointer; color: blue">
                                            <i class="fas fa-eye"></i>
                                        </div>
                                    </td>
                                    <td>{{ $policy->code }}</td>
                                    <td>{{ $policy->validity_date }}</td>
                                    <td>{{ $policy->id }}</td>
                                    <td>{{ $policy->currency === 0 ? 'Soles':'Dolares'  }}</td>
                                    <td>{{ $policy->prime }}</td>
                                    <td>{{ \App\Enums\SellType::getDescription($policy->sell_type) }}</td>
                                    <td>{{ $policy->assessor->name }}</td>
                                    <td>{{ $policy->status->name }}</td>
                                    <td>{{ $policy->loyaltyAnswer }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        <a class="btn btn-secondary btn-sm"
                                           href="{{ route('loyalties.show',$policy) }}">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $policies->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quick Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="quickModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="quickModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="quickModalLongTitle">Cliente</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table">
                            <tr>
                                <td>Nombre</td>
                                <th>{{ $policy->customer->name }}</th>
                            </tr>
                            <tr>
                                <td>Correo electronico</td>
                                <th>{{ $policy->customer->email }}</th>
                            </tr>
                            <tr>
                                <td>Telefono</td>
                                <th>{{ $policy->customer->phone }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    <!-- Delete Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="deleteModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar la poliza?</div>
                        <table class="table">
                            <tr>
                                <td>Cliente</td>
                                <td>{{ $policy->customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Poliza ID</td>
                                <td>{{ $policy->id }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $(function () {
                $('[data-toggle="tooltip"]').tooltip();
            })
            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar la poliza?');
                if (!confirm) {
                    e.preventDefault();
                }
            })
        };
    </script>
@endpush
