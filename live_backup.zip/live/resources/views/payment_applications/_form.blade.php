<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Compañia</label>
            <div class="col">
                {{ Form::select('company_id', dropdownData('Companies'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Contratante</label>
            <div class="col">
                {{ Form::select('customer_id', dropdownData('Customers'), null, ['class' => 'form-control'.($errors->has('customer_id') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('customer_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Banco</label>
            <div class="col">
                {{ Form::select('bank_id', dropdownData('Banks'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ticket</label>
            <div class="col">
                {{ Form::text('ticket', null, ['class' => 'form-control'.($errors->has('ticket') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('ticket') }}</div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                {{ Form::select('assessor_id', dropdownData('Employees'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                {{ Form::select('policy_id', dropdownData('Policies', $paymentApplication ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Rubro</label>
            <div class="col">
                {{ Form::select('sector_id', dropdownData('Sectors', $paymentApplication ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Producto</label>
            <div class="col">
                {{ Form::select('product_id', dropdownData('Products', $paymentApplication ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Moneda</label>
            <div class="col">
                {{ Form::select('currency', dropdownData('Currency'), null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto</label>
            <div class="col">
                {{ Form::text('amount', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Doc de cobro.</label>
            <div class="col">
                {{ Form::text('invoice_document', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Boleta cobranza</label>
            <div class="col">
                {{ Form::text('invoice', null, ['class' => 'form-control']) }}
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Status</label>
            <div class="col">
                {{ Form::select('status', dropdownData('PaymentCollectionStatuses'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-group">Observaciones</div>
        <div class="form-group">
            {{ Form::textarea('comments', null, ['class' => 'form-control']) }}
        </div>
    </div>
</div>
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=company_id]').select2();
            $('select[name=sector_id]').select2();
            $('select[name=product_id]').select2();
            $('select[name=customer_id]').select2();
            $('select[name=bank_id]').select2();
            $('select[name=assessor_id]').select2();
            $('select[name=policy_id]').select2();

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                axios.get('/api/sectors?company_id=' + company_id).then((response) => {
                    $('select[name=sector_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                axios.get('/api/products?sector_id=' + sector_id).then((response) => {
                    $('select[name=product_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });

            // policy
            $('select[name=customer_id]').change(function () {
                let customer_id = $(this).val();
                axios.get('/api/policies?customer_id=' + customer_id).then((response) => {
                    $('select[name=policy_id]').empty();
                    response.data.data.forEach(function (policy) {
                        $('select[name=policy_id]').append($("<option />").val(policy.id).text(policy.code));
                    });
                });
            });
        };
    </script>
@endpush
