@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Aplicaciones de pago</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Aplicaciones de pago</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('create', \App\PaymentApplication::class)
                        <a class="btn btn-primary" href="{{ route('payment_applications.create') }}"><i
                                class="fas fa-plus mr-2"></i>Nuevo</a>
                    @endcan
                    @can('view-disabled', \App\PaymentApplication::class)
                        <a class="btn btn-danger" href="{{ route('payment_applications.disabled') }}"><i
                                class="fas fa-plus mr-2"></i>Eliminados</a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="mb-2">
                            {{ Form::open(['url' => route('payment_applications.index'), 'method' => 'GET']) }}
                            <label>Documento (#)</label>
                            {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Contratante</label>
                            {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="{{ request('dates') }}" style="width: 200px">

                            <label class="ml-3">Status</label>
                            {{ Form::select('status', $cboStatus, request('status'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline']) }}

                            <button class="btn btn-primary ml-3">Buscar</button>
                            <a href="{{ route('payment_applications.index') }}" class="btn btn-secondary">Resetear</a>
                            {{ Form::close() }}
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Ticket</th>
                                <th>Asesor</th>
                                <th>Cliente</th>
                                <th>Poliza</th>
                                <th>Moneda</th>
                                <th>Monto a aplicar</th>
                                <th>Doc de cobro</th>
                                <th>Boleta de cobranza</th>
                                <th>Status</th>
                                <th>Observaciones</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($paymentApplications as $paymentApplication)
                                <tr>
                                    <td>{{ $paymentApplication->id }}</td>
                                    <td>{{ $paymentApplication->createdDateTime }}</td>
                                    <td>{{ $paymentApplication->company->name }}</td>
                                    <td>{{ $paymentApplication->ticket }}</td>
                                    <td>{{ $paymentApplication->assessor->name }}</td>
                                    <td>{{ $paymentApplication->customer->name }}</td>
                                    <td>{{ $paymentApplication->policy->code }}</td>
                                    <td>{{ $paymentApplication->currency }}</td>
                                    <td>{{ $paymentApplication->amount }}</td>
                                    <td>{{ $paymentApplication->invoice_document }}</td>
                                    <td>{{ $paymentApplication->invoice }}</td>
                                    <td>{{ $paymentApplication->statusName }}</td>
                                    <td>{{ $paymentApplication->comments }}</td>
                                    <td>{{ $paymentApplication->user->name }}</td>
                                    <td class="text-right" style="white-space: nowrap">
                                        @can('create', $paymentApplication)
                                            <a href="{{ route('payment_applications.edit', $paymentApplication) }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        @endcan
                                        @can('disable',$paymentApplication)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $paymentApplication->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $paymentApplications->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($paymentApplications as $paymentApplication)
        <div class="modal fade" id="deleteModal{{$paymentApplication->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar la aplicacion de pago?</div>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('payment_applications.disable', $paymentApplication), 'method' => 'PUT']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
