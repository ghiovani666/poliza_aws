<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                {{ Form::select('policy_id', dropdownData('Policies'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Prima</label>
            <div class="col">
                {{ Form::text('prime', null, ['class' => 'form-control'.($errors->has('prime') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('prime') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comision Morgan</label>
            <div class="col">
                {{ Form::text('commission_broker', null, ['class' => 'form-control'.($errors->has('commission_broker') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('commission_broker') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comision Asesor (estimado)</label>
            <div class="col">
                {{ Form::text('commission_assessor_estimated', null, ['class' => 'form-control'.($errors->has('commission_assessor_estimated') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('commission_assessor_estimated') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comision Asesor (real)</label>
            <div class="col">
                {{ Form::text('commission_assessor_real', null, ['class' => 'form-control'.($errors->has('commission_assessor_real') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('commission_assessor_real') }}</div>
            </div>
        </div>
    </div>
    <div class="col"></div>
</div>
