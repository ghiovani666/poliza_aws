@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Liquidaciones</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('payings.index') }}">Liquidaciones</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $paying->assessor->name }}</li>
                    </ol>
                </nav>
                <div class="float-right">

                </div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Poliza (#)</th>
                                <th>Contratante</th>
                                <th>Prima Neta</th>
                                <th>Comision Morgan</th>
                                <th>Comision Asesor (estimado)</th>
                                <th>Comision Asesor (real)</th>
                                <th>F. Registro</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($items as $item)
                                <tr>
                                    <td>{{ $item->id }}</td>
                                    <td>{{ $item->policy->code }}</td>
                                    <td>{{ $item->customer->name }}</td>
                                    <td>{{ $item->prime }}</td>
                                    <td>{{ $item->commission_broker }}</td>
                                    <td>{{ $item->commission_assessor_estimated }}</td>
                                    <td>{{ $item->commission_assessor_real }}</td>
                                    <td>{{ $item->created_at->format('d/m/Y') }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        <a href="{{ route('payings.items.edit',[$paying, $item]) }}" class="btn btn-secondary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $items->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
