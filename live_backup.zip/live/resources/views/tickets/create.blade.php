@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">TICKETS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('tickets.index') }}">Tickets</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['url' => route('tickets.store')]) }}
                        <div class="row">
                            <div class="col-12">
                                <div class="h5">Ticket #</div>
                                <div class="row no-gutters">
                                    <div class="col">
                                        <div class="form-row form-group">
                                            <label class="col-4 col-form-label">Cliente</label>
                                            <div class="col">
                                                {{ Form::select('customer_id', dropdownData('Customers'), null, ['class' => 'form-control']) }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-row form-group">
                                            <label class="col-4 col-form-label ml-2"># Poliza</label>
                                            <div class="col">
                                                {{ Form::text('policy_number', null, ['class' => 'form-control']) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row no-gutters">
                                    <div class="col">
                                        <div class="form-row form-group">
                                            <label class="col-4 col-form-label">Responsable</label>
                                            <div class="col">
                                                {{ Form::select('employee_id', $employees, null, ['class' => 'form-control']) }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-row form-group">
                                            <label class="col-4 col-form-label ml-2"># Copia a</label>
                                            <div class="col">
                                                {{ Form::select('copy_to[]', $employees, null, ['class' => 'form-control', 'multiple' => true, 'id' => 'copy_to']) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-2 col-form-label">Asunto</label>
                                    <div class="col">
                                        {{ Form::text('subject', null, ['class' => 'form-control'.($errors->has('subject') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('subject') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <div class="col">
                                        {{ Form::textarea('body', null, ['class' => 'form-control'.($errors->has('body') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('body') }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('#copy_to').select2();
        };
    </script>
@endpush
