@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="h2 d-inline-block">TICKETS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('tickets.index') }}">Tickets</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $ticket->subject }}</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="h5">#
                                    Ticket {{ $ticket->id }} {{ $ticket->created_at->format('d/m/Y H:i') }}</div>
                                <table class="table">
                                    <tr>
                                        <td>Cliente</td>
                                        <td>{{ $ticket->customer->name }}</td>
                                    </tr>
                                    <tr>
                                        <td># poliza</td>
                                        <td>{{ $ticket->policy_number }}</td>
                                    </tr>
                                    <tr>
                                        <td>Responsable</td>
                                        <td>{{ $ticket->employee->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Copia a</td>
                                        <td>
                                            {{ implode(', ',$ticket->getEmployeesToCopy()->pluck('name')->all()) }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Asunto</td>
                                        <td>{{ $ticket->subject }}</td>
                                    </tr>
                                </table>
                                {{ Form::open(['url' => route('comments.store')]) }}
                                <hr>
                                {{ Form::textarea('body', null, ['class' => 'form-control']) }}
                                <hr>
                                <div class="form-group">
                                    <input type="hidden" name="ticket_id" value="{{ $ticket->id }}">
                                    <button class="btn btn-primary">Agregar</button>
                                </div>
                                {{ Form::close() }}
                                @include('flash::message')
                            </div>
                            <div class="col">
                                <div class="h5">Historial</div>
                                <div class="comments" style="overflow-y: scroll; max-height: 500px">
                                    @foreach($ticket->comments()->orderByDesc('id')->get() as $comment)
                                        <div class="comment">
                                            <div class="author font-weight-bold"><i
                                                    class="fas fa-user-circle mr-2"></i>{{ $comment->user->name }}</div>
                                            <div class="body my-2" style=" white-space: pre-line;">{{ $comment->body }}</div>
                                            <div class="date"><i class="far fa-clock mr-2"></i><span
                                                    title="{{ $comment->createdDateTime }}">{{ $comment->createdTimeAgo }}</span>
                                            </div>
                                        </div>
                                        <hr>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
