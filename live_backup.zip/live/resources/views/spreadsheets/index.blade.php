@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Google Sheet</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Google Sheets</li>
                    </ol>
                </nav>
                <div class="float-right"></div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <div class="row">
                            <div class="col-6">
                                <h3>Modo de uso:</h3>
                                <img class="img-fluid" src="{{ asset('/img/google-embed.png') }}">
                            </div>
                            <div class="col-6">
                                {{ Form::open(['url' => route('spreadsheet.store')]) }}
                                <div class="form-group mb-3">
                                    {{ Form::label('embed','Canal digital') }}
                                    <div class="mb-3">
                                        <small class="text-muted">Ingresa el codigo obtenido en Google Sheet</small>
                                    </div>
                                    {{ Form::textarea('embed', old('embed', $setting->value), ['class' => 'form-control']) }}
                                </div>
                                <div class="form-group mb-3">
                                    {{ Form::label('report_renewal','Reporte post-venta') }}
                                    <div class="mb-3">
                                        <small class="text-muted">Ingresa el codigo obtenido en Google Sheet</small>
                                    </div>
                                    {{ Form::textarea('report_renewal', old('report_renewal', $settingRenewal->value), ['class' => 'form-control']) }}
                                </div>
                                <div class="form-group mb-3">
                                    {{ Form::label('report_balance','Reporte cobranzas') }}
                                    <div class="mb-3">
                                        <small class="text-muted">Ingresa el codigo obtenido en Google Sheet</small>
                                    </div>
                                    {{ Form::textarea('report_balance', old('report_balance', $settingBalance->value), ['class' => 'form-control']) }}
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary">Guardar</button>
                                </div>
                                {{ Form::close() }}
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
