<div class="mb-2">
    {{ $leads->count() }} Leads
    <span
        class="text-success mx-2">S/{{ $totalAmountInPEN }}</span>
    <span
        class="text-success mx-2">${{ $totalAmountInUSD }}</span>
</div>

@include('leads._filters')

<div class="row">
    <div class="col-8">
        @forelse($leads as $lead)
            <div class="card mb-4">
                <div class="card-body alert {{ $lead->alertType }}" style="margin-bottom: 0">
                    <div class="row">
                        <div class="col-3 text-right">
                            <div class="mb-2">
                                <div class="badge badge-secondary p-1">
                                    {{ \App\Enums\LeadProcess::getDescription($lead->process_id) }}
                                </div>
                            </div>
                            <div class="mb-2">
                                <div class="badge badge-info p-1">
                                    {{ \App\Enums\LeadStage::getDescription($lead->stage_id) }}
                                </div>
                            </div>
                            <div class="mb-2">
                                <div class="badge badge-success p-1">
                                    {{ $lead->currency }}
                                    {{ $lead->amount }}
                                </div>
                            </div>
                            <div class="mb-2">
                                <span class="p-1">Creado: {{ $lead->created_at }}</span>
                            </div>
                            <div class="mb-2">
                                <span class="p-1">Editado: {{ $lead->updated_at }}</span>
                            </div>
                            <div class="mb-2">
                                <span class="p-1">Asesor: {{ $lead->assessor->name }}</span>
                            </div>
                        </div>
                        <div class="col" style="border-left: 1px solid #ccc">
                            <div class="card-title">
                                <a href="{{ route('leads.show', $lead) }}">{{ $lead->name }}</a>
                            </div>
                            <div class="mb-2">Nombre: {{ $lead->name }}</div>
                            <div class="mb-2">Telefono: {{ $lead->phone }}</div>
                            <div class="mb-2">Email: {{ $lead->email }}</div>
                            <div class="mb-2">
                                Documento:
                                {{ \App\Enums\DocumentType::getDescription($lead->document_type) }}
                                {{ $lead->document_number }}
                            </div>
                            <div class="mb-2">
                                Origen: {{ \App\Enums\LeadSource::getDescription($lead->source_id) }}</div>
                            <div class="mb-2">
                                <div class="mb-2">Descripción:</div>
                                <div style="white-space: pre-wrap">{{ $lead->description }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="text-center">No se encontraron registros.</div>
        @endforelse
    </div>
    <div class="col">
        <div class="card mb-4">
            <div class="card-body">
                <div class="card-title">Pipeline de ventas</div>
                @foreach(\App\Enums\LeadStage::toSelectArray() as $stageId => $stageName)
                    <div class="row mb-2">
                        <div class="col">
                            {{ $stageName }}
                            <span class="badge badge-secondary">
                                                    {{ (clone $baseQuery)->byStage($stageId)->count() }}
                                                </span>
                        </div>
                        <div class="col text-right">
                                                <span class="text-success mr-2">
                                                    S/ {{ (clone $baseQuery)->byStage($stageId)->where('currency','PEN')->sum('amount') }}
                                                </span>
                            <span class="text-success">
                                                    $ {{ (clone $baseQuery)->byStage($stageId)->where('currency','USD')->sum('amount') }}
                                                </span>
                        </div>
                    </div>
                @endforeach
                <div class="row">
                    <div class="col">{{ $leads->count() }} leads</div>
                    <div class="col text-right">
                                            <span class="text-success mr-2">
                                                S/ {{ (clone $baseQuery)->where('currency','PEN')->sum('amount') }}
                                            </span>
                        <span class="text-success">
                                                $ {{ (clone $baseQuery)->where('currency','USD')->sum('amount') }}
                                            </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-title">Leads Ganados</div>
                <div class="row mb-2">
                    <div class="col">PEN</div>
                    <div class="col text-right">S/{{ $totalAmountSuccessInPen }}</div>
                </div>
                <div class="row mb-2">
                    <div class="col">USD</div>
                    <div class="col text-right">${{ $totalAmountSuccessInUSD }}</div>
                </div>
            </div>
        </div>
    </div>
</div>
