@extends('layouts.app')

@section('content')
    <crm-dashboard-index></crm-dashboard-index>
@endsection
