<div class="mb-2">
    {{ $leads->count() }} Leads
    <span
        class="text-success mx-2">S/{{ $totalAmountInPEN }}</span>
    <span
        class="text-success mx-2">${{ $totalAmountInUSD }}</span>
</div>

@include('leads._filters')

<div class="row">
    @foreach($leadsGroup as $group)
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <div>{{ $group['stage_name'] }}</div>
                        <div class="text-success float-right">
                            S/{{ $group['amount_pen'] }}
                        </div>
                        <div class="text-success float-right mx-2">
                            /
                        </div>
                        <div class="text-success float-right">
                            ${{ $group['amount_usd'] }}
                        </div>
                        <div class="text-muted">
                            {{ $group['total'] }} leads
                        </div>
                    </div>
                    @forelse($group['leads'] as $lead)
                        <div class="alert {{ $lead->alertType }}">
                            <div class="row">
                            <div class="col">
                                <div class="font-weight-bold">
                                    <a href="{{ route('leads.show', $lead) }}">{{ $lead->name }}</a>
                                </div>
                                <div class="text-muted">{{ $lead->close_date }}</div>
                                <div class="text-muted">{{ $lead->assessor->name }}</div>
                            </div>
                            <div class="col">
                                <div class="text-right">
                                    {{ \App\Enums\LeadProcess::getDescription($lead->process_id) }}
                                </div>
                                <div class="text-right">
                                    {{ $lead->currency }}
                                    {{ $lead->amount }}
                                </div>
                            </div>
                        </div>
                        </div>
                    @empty
                        <div class="text-center">No se encontraron registros.</div>
                    @endforelse
                </div>
            </div>
        </div>
    @endforeach
</div>
