<div class="mb-2">
    {{ $leads->count() }} Leads
    <span
        class="text-success mx-2">S/{{ $totalAmountInPEN }}</span>
    <span
        class="text-success mx-2">${{ $totalAmountInUSD }}</span>
</div>

@include('leads._filters')

<div class="card">
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Estatus</th>
                <th>Importe</th>
                <th>Fecha de cierre</th>
                <th>Etapa</th>
                <th>Asesor</th>
                <th>Ultima actualizacion</th>
                <th>Proceso</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($leads as $lead)
                <tr class="alert {{ $lead->alertType }}">
                    <td><a href="{{ route('leads.show', $lead) }}">{{ $lead->name }}</a></td>
                    <td>
                        @if ($lead->daysToClose() > 0)
                            <a href="{{ route('leads.show', $lead) }}"
                               class="btn btn-outline-info btn-sm">
                                {{ $lead->daysToClose() }}d
                            </a>
                        @else
                            <a href="{{ route('leads.show', $lead) }}"
                               class="btn btn-outline-danger btn-sm">
                                {{ $lead->daysToClose() * 1 }}d
                            </a>
                        @endif

                    </td>
                    <td>{{ $lead->currency }} {{ $lead->amount }}</td>
                    <td>{{ optional($lead->close_date)->toDateString() }}</td>
                    <td>{{ \App\Enums\LeadStage::getDescription($lead->stage_id) }}</td>
                    <td>{{ $lead->assessor->name }}</td>
                    <td>{{ $lead->updated_at }}</td>
                    <td>{{ \App\Enums\LeadProcess::getDescription($lead->process_id) }}</td>
                    <td class="text-right">
                        <a href="{{ route('leads.show', $lead) }}" class="btn btn-secondary btn-sm">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="{{ route('leads.edit', $lead) }}" class="btn btn-secondary btn-sm">
                            <i class="fas fa-edit"></i>
                        </a>
                        @can('delete',$lead)
                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                    data-target="#deleteModal{{ $lead->id }}">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        @endcan
                    </td>
                </tr>
            @empty
                <tr>
                    <td class="text-center" colspan="8">No se encontraron registros.</td>
                </tr>
            @endforelse
            </tbody>
        </table>

        <!-- Delete Modal -->
        @foreach($leads as $lead)
            <div class="modal fade" id="deleteModal{{$lead->id}}" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                            <button type="button" class="close" data-dismiss="modal"
                                    aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="h4 text-center">¿Seguro que desea eliminar el lead?
                            </div>
                            <table class="table">
                                <tr>
                                    <td>Lead</td>
                                    <td>{{ $lead->name }}</td>
                                </tr>
                                <tr>
                                    <td>ID</td>
                                    <td>{{ $lead->id }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="modal-footer">
                            {{ Form::open(['url' => route('leads.destroy', $lead), 'method' => 'DELETE']) }}
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                Cancelar
                            </button>
                            <button type="submit" class="btn btn-danger">Si, eliminar</button>
                            {{ Form::close() }}
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
