@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Leads</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Leads</li>
                    </ol>
                </nav>
                <div class="float-right">
                    <a class="btn btn-primary" href="{{ route('leads.create') }}">
                        <i class="fas fa-plus mr-2"></i>Nuevo</a>
                    <div class="btn-group" role="group">
                        <a href="?mode=1" class="btn btn-secondary"><i class="fas fa-table"></i></a>
                        <a href="?mode=2" class="btn btn-secondary"><i class="fas fa-calendar-week"></i></a>
                        <a href="?mode=3" class="btn btn-secondary"><i class="fas fa-stream"></i></a>
                    </div>
                    <a class="btn btn-secondary" href="{{ route('leads.export') }}" title="Descargar en excel">
                        <i class="fas fa-file-excel"></i></a>
                </div>

                @includeWhen($mode == 1, 'leads._compact-mode')

                @includeWhen($mode == 2, 'leads._extended-mode')

                @includeWhen($mode == 3, 'leads._pipeline-mode')
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="created_at"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="created_at"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('input[name="close_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="close_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });
        };
    </script>
@endpush
