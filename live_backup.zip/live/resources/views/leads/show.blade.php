@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="h2 d-inline-block">Leads</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('leads.index') }}">Leads</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $lead->name }}</li>
                    </ol>
                </nav>
                <div class="row">
                    <div class="col-7">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <table class="table">
                                            <tr class="alert alert-primary">
                                                <th>Etapa</th>
                                                <th>{{ \App\Enums\LeadStage::getDescription($lead->stage_id) }}</th>
                                            </tr>
                                            <tr class="alert alert-primary">
                                                <th>Proceso</th>
                                                <th>{{ \App\Enums\LeadProcess::getDescription($lead->process_id) }}</th>
                                            </tr>
                                            <tr>
                                                <td>Nombre</td>
                                                <td>{{ $lead->name }}</td>
                                            </tr>
                                            <tr>
                                                <td>Teléfono</td>
                                                <td>{{ $lead->phone }}</td>
                                            </tr>
                                            <tr>
                                                <td>Email</td>
                                                <td>{{ $lead->email }}</td>
                                            </tr>
                                            <tr>
                                                <td>Documento</td>
                                                <td>
                                                    {{ \App\Enums\DocumentType::getDescription($lead->document_type) }}
                                                    {{ $lead->document_number }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Origen</td>
                                                <td>{{ \App\Enums\LeadSource::getDescription($lead->source_id) }}</td>
                                            </tr>
                                            <tr>
                                                <td>Descripción</td>
                                                <td style="white-space: pre-wrap">{{ $lead->description }}</td>
                                            </tr>
                                            <tr>
                                                <td>Importe</td>
                                                <td>
                                                    {{ $lead->currency }}
                                                    {{ $lead->amount }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Fecha de ciere estimada</td>
                                                <td>{{ $lead->toDate('close_date') }}</td>
                                            </tr>
                                            <tr>
                                                <td>Fecha de ciere</td>
                                                <td>{{ $lead->toDate('wind_date') }}</td>
                                            </tr>
                                            <tr>
                                                <td>Supervisor</td>
                                                <td>{{ $lead->supervisor->name }}</td>
                                            </tr>
                                            <tr>
                                                <td>Asesor</td>
                                                <td>{{ $lead->assessor->name }}</td>
                                            </tr>
                                            <tr>
                                                <td>Fecha de registro</td>
                                                <td>{{ $lead->createdDateTime }}</td>
                                            </tr>
                                            <tr>
                                                <td>Fecha de ultima actualizacion</td>
                                                <td>{{ $lead->updatedDateTime }}</td>
                                            </tr>
                                        </table>
                                        <hr>
                                        <a class="btn btn-primary" href="{{ route('leads.edit', $lead) }}" style="min-width: 160px">
                                            <i class="fas fa-edit mr-2"></i>
                                            Modificar
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <lead-appointments :id="{{ $lead->id }}" type="App\Lead"></lead-appointments>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
