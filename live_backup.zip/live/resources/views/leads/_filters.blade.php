<div class="mb-2">
    {{ Form::open(['url' => route('leads.index'), 'method' => 'GET']) }}

    <input type="hidden" name="mode" value="{{ $mode }}">

    <div class="d-inline-block mr-2" title="Asesor" style="width: 160px">
        {{ Form::select('assessor_id', dropdownData('Employees'), request('assessor_id'), ['class' => 'form-control', 'placeholder' => 'Asesor', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Proceso" style="width: 100px">
        {{ Form::select('process_id', \App\Enums\LeadProcess::toSelectArray(), request('process_id'), ['class' => 'form-control', 'placeholder' => 'Proceso', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Etapa" style="width: 140px">
        {{ Form::select('stage_id', \App\Enums\LeadStage::toSelectArray(), request('stage_id'), ['class' => 'form-control', 'placeholder' => 'Etapa', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Ultima accion" style="width: 160px">
        {{ Form::select('last_action', commentActionsToSelectArray(), request('last_action'), ['class' => 'form-control', 'placeholder' => 'Ultima accion', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Nombre" style="width: 120px">
        {{ Form::text('name', request('name'), ['class' => 'form-control', 'placeholder' => 'Nombre', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Fecha de creacion" style="width: 160px">
        {{ Form::text('created_at', request('created_at'), ['class' => 'form-control', 'placeholder' => 'Fecha de creacion', 'style' => 'width: 100%']) }}
    </div>

    <div class="d-inline-block mr-2" title="Fecha de cierre" style="width: 160px">
        {{ Form::text('close_date', request('close_date'), ['class' => 'form-control', 'placeholder' => 'Fecha de cierre', 'style' => 'width: 100%']) }}
    </div>

    <button class="btn btn-primary ml-2"><i class="fas fa-search"></i> Buscar</button>
    <a href="{{ route('leads.index') }}" class="btn btn-secondary" title="Resetear">
        <i class="fas fa-sync"></i>
    </a>

    {{ Form::close() }}
</div>
