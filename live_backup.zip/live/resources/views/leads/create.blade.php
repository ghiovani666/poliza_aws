@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Leads</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('leads.index') }}">Leads</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['url' => route('leads.store')]) }}
                        <div class="row">
                            <div class="col-6">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Nombre</label>
                                    <div class="col">
                                        {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('name') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Teléfono</label>
                                    <div class="col">
                                        {{ Form::text('phone', null, ['class' => 'form-control'.($errors->has('phone') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('phone') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Email</label>
                                    <div class="col">
                                        {{ Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('email') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Documento</label>
                                    <div class="col">
                                        <div class="row no-gutters">
                                            <div class="col mr-2">
                                                {{ Form::select('document_type', dropdownData('DocumentTypes'), null, ['class' => 'form-control'.($errors->has('document_type') ? ' is-invalid': null)]) }}
                                                <div
                                                    class="invalid-feedback">{{ $errors->first('document_type') }}</div>
                                            </div>
                                            <div class="col">
                                                {{ Form::text('document_number', null, ['class' => 'form-control'.($errors->has('document_number') ? ' is-invalid': null)]) }}
                                                <div
                                                    class="invalid-feedback">{{ $errors->first('document_number') }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Origen</label>
                                    <div class="col">
                                        {{ Form::select('source_id',\App\Enums\LeadSource::toSelectArray(), null, ['placeholder' => '','class' => 'form-control'.($errors->has('source_id') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('source_id') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Description</label>
                                    <div class="col">
                                        {{ Form::textarea('description', null, ['class' => 'form-control'.($errors->has('description') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('description') }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Etapa</label>
                                    <div class="col">
                                        {{ Form::select('stage_id', \App\Enums\LeadStage::toSelectArray(), null, ['class' => 'form-control'.($errors->has('stage_id') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('stage_id') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Importe</label>
                                    <div class="col">
                                        <div class="row no-gutters">
                                            <div class="col mr-2">
                                                {{ Form::select('currency', dropdownData('Currency'), null, ['class' => 'form-control'.($errors->has('currency') ? ' is-invalid': null)]) }}
                                                <div class="invalid-feedback">{{ $errors->first('currency') }}</div>
                                            </div>
                                            <div class="col">
                                                {{ Form::text('amount', null, ['class' => 'form-control'.($errors->has('amount') ? ' is-invalid': null)]) }}
                                                <div class="invalid-feedback">{{ $errors->first('amount') }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Fecha de cierre estimada</label>
                                    <div class="col">
                                        {{ Form::date('close_date', null, ['class' => 'form-control'.($errors->has('close_date') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('close_date') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Proceso</label>
                                    <div class="col">
                                        {{ Form::select('process_id', \App\Enums\LeadProcess::toSelectArray(), null, ['class' => 'form-control'.($errors->has('process_id') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('process_id') }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
