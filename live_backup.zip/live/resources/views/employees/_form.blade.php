<div class="row">
    <div class="col">
        <div class="h5">Informacion</div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de empleado</label>
            <div class="col">
                {{ Form::select('type', $employeeTypes, null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Correo</label>
            <div class="col">
                {{ Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('email') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Telefono</label>
            <div class="col">
                {{ Form::text('phone', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">DNI</label>
            <div class="col">
                {{ Form::text('dni', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de nacimiento</label>
            <div class="col">
                {{ Form::text('birth_date', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de ingreso</label>
            <div class="col">
                {{ Form::text('start_date', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <!-- Hide unused fields in the employee form
        <div class="form-row form-group">
            <label class="col-4 col-form-label"># CUSPP</label>
            <div class="col">
                {{ Form::text('cuspp_number', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">¿Tiene sueldo basico?</label>
            <div class="col">
                {{ Form::radio('has_salary1', null, false, ['disabled' => true]) }} Si
                {{ Form::radio('has_salary2', null, false, ['disabled' => true]) }} No
            </div>
        </div>
        <div id="salary">
            <div class="form-row form-group">
                <label class="col-4 col-form-label">Sueldo basico</label>
                <div class="col">
                    {{ Form::text('salary_base', null, ['class' => 'form-control']) }}
                </div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Sistema de pension</label>
            <div class="col">
                {{ Form::text('pension_system', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comision por venta</label>
            <div class="col">
                {{ Form::text('sale_commission', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comision por renovacion</label>
            <div class="col">
                {{ Form::text('renew_commission', null, ['class' => 'form-control']) }}
            </div>
        </div>
        -->
    </div>
    <div class="col">
        <!-- Hide unused fields in the employee form
        <div class="h5">Descuentos</div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">O.N.P. 13%</label>
            <div class="col">
                {{ Form::text('discount_onp', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comis. Afp</label>
            <div class="col">
                {{ Form::text('discount_afp_commission', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Prima Afp</label>
            <div class="col">
                {{ Form::text('discount_afp_prime', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Aport Afp</label>
            <div class="col">
                {{ Form::text('discount_afp_goal', null, ['class' => 'form-control']) }}
            </div>
        </div>

        <div id="supervisor1" style="display: none">
            <div class="h5 mt-5">
                Gerente General
                <small class="text-muted mb-3">(Gerentes bajo supervicion)</small>
            </div>

            <div class="mb-2">Gerentes Comercial</div>
            @foreach(employees([2],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Gerentes de Operaciones</div>
            @foreach(employees([3],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor2" style="display: none">
            <div class="h5 mt-5">
                Areas
                <small class="text-muted mb-3">(Areas bajo supervicion)</small>
            </div>
            <div class="mb-2">Ejecutivo de Cuenta</div>
            @foreach(employees([14],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Ejecutivo de Riesgos Laborales</div>
            @foreach(employees([15],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Consultor de Cuentas Estado</div>
            @foreach(employees([16],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Asesor de Ventas Freelance</div>
            @foreach(employees([17],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Gerente de Canal</div>
            @foreach(employees([8],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor3" style="display: none">
            <div class="h5 mt-5">
                Areas
                <small class="text-muted mb-3">(Areas bajo supervicion)</small>
            </div>

            <div class="mb-2">Fidelización y Mantenimiento</div>
            @foreach(employees([4],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Ejecutivo de Cobranzas</div>
            @foreach(employees([5],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Asistente Administrativo</div>
            @foreach(employees([6],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor5" style="display: none">
            <div class="h5 mt-5">
                Asistentes
                <small class="text-muted mb-3">(Asistentes bajo supervicion)</small>
            </div>
            <div class="mb-2">Asistente de Cobranzas</div>
            @foreach(employees([7],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor8" style="display: none">
            <div class="h5 mt-5">
                Areas
                <small class="text-muted mb-3">(Areas bajo supervicion)</small>
            </div>

            <div class="mb-2">Gerente de Agencia</div>
            @foreach(employees([10],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach

            <div class="mb-2">Asistente de Agencia</div>
            @foreach(employees([9],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor10" style="display: none">
            <div class="h5 mt-5">
                Areas
                <small class="text-muted mb-3">(Areas bajo supervicion)</small>
            </div>

            <div class="mb-2">Supervisor de ventas</div>
            @foreach(employees([12],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>

        <div id="supervisor12" style="display: none">
            <div class="h5 mt-5">
                Areas
                <small class="text-muted mb-3">(Areas bajo supervicion)</small>
            </div>

            <div class="mb-2">Asesor de ventas</div>
            @foreach(employees([13],2) as $chunk)
                <div class="form-row form-group mb-2">
                    @foreach($chunk as $row)
                        <div class="col">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="chkAssessor{{ $row->id }}" name="supervise[]"
                                       value="{{ $row->id }}"
                                       @if (in_array($row->id, $employee->supervise ?? [])) checked @endif>
                                <label class="custom-control-label"
                                       for="chkAssessor{{ $row->id }}">{{ $row->name }}</label>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
        -->
    </div>
</div>

@push('scripts')
    <script>
        window.onload = function () {
            $('select[name=type]').change(onChangeType);
            onChangeType();
        };

        function hideAllSupervise() {
            $('#supervisor1').css('display', 'none');
            $('#supervisor2').css('display', 'none');
            $('#supervisor3').css('display', 'none');
            $('#supervisor5').css('display', 'none');
            $('#supervisor8').css('display', 'none');
            $('#supervisor10').css('display', 'none');
            $('#supervisor12').css('display', 'none');
        }

        function displaySupervise(type) {
            $('#supervisor' + type).css('display', 'block');
        }

        function onChangeType() {
            let type = parseInt($('select[name=type]').val());

            hideAllSupervise()
            displaySupervise(type)
            onHasSalary()
        }


        function onHasSalary() {
            let type = parseInt($('select[name=type]').val());
            if (type === 1 || type === 2) {
                $('input[name=has_salary2]').prop('checked', true);
                $('input[name=has_salary1]').prop('checked', false);
                $('#salary').css('display', 'none');
            } else {
                $('input[name=has_salary1]').prop('checked', true);
                $('input[name=has_salary2]').prop('checked', false);
                $('#salary').css('display', 'block');
            }
        }
    </script>
@endpush
