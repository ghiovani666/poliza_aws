@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-trash-alt mr-2"></i> Papelera
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="#">Polizas</a>
                            </li>
                        </ul>

                        <table class="table">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($policies as $policy)
                                <tr>
                                    <td>{{ $policy->id }}</td>
                                    <td>{{ $policy->customer->name }}</td>
                                    <td class="text-right">
                                        <a class="btn btn-secondary btn-sm" title="Restaurar poliza"
                                           href="{{ route('settings.restore',$policy) }}">
                                            <i class="fas fa-trash-restore"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
