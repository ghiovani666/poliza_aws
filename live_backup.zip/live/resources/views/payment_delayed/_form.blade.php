<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Compañia</label>
            <div class="col">
                {{ Form::select('company_id', dropdownData('Companies'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Contratante</label>
            <div class="col">
                {{ Form::select('customer_id', dropdownData('Customers'), null, ['class' => 'form-control'.($errors->has('customer_id') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('customer_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Banco</label>
            <div class="col">
                {{ Form::select('bank_id', dropdownData('Banks'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ticket</label>
            <div class="col">
                {{ Form::text('ticket', null, ['class' => 'form-control'.($errors->has('ticket') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('ticket') }}</div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                {{ Form::select('assessor_id', dropdownData('Employees'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                {{ Form::select('policy_id', [], null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Rubro</label>
            <div class="col">
                {{ Form::select('sector_id', [], null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Producto</label>
            <div class="col">
                {{ Form::select('product_id', [], null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Moneda</label>
            <div class="col">
                {{ Form::select('currency', dropdownData('Currency'), null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto</label>
            <div class="col">
                {{ Form::text('amount', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Doc de cobro.</label>
            <div class="col">
                {{ Form::text('invoice_document', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Boleta cobranza</label>
            <div class="col">
                {{ Form::text('invoice', null, ['class' => 'form-control']) }}
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Status</label>
            <div class="col">
                {{ Form::select('status', dropdownData('FinanceStatuses'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
            </div>
        </div>
        <div class="form-group">Observaciones</div>
        <div class="form-group">
            {{ Form::textarea('comments', null, ['class' => 'form-control']) }}
        </div>
    </div>
</div>
