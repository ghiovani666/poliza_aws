@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Deudas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Deudas</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col">
                                {{ Form::open(['method' => 'GET']) }}
                                <div class="d-inline-block">Compañia</div>
                                <div class="d-inline-block mr-2" style="width: 160px">
                                    {{ Form::select('company_id', dropdownData('Companies'), request('company_id'), ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
                                </div>
                                <div class="d-inline-block">Contratante</div>
                                <div class="d-inline-block mr-2" style="width: 160px">
                                    {{ Form::select('customer_id', dropdownData('Customers'), request('customer_id'), ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
                                </div>
                                <div class="d-inline-block">Poliza</div>
                                <div class="d-inline-block mr-2" style="width: 160px">
                                    {{ Form::select('policy_id', dropdownData('Policies'), request('policy_id'), ['class' => 'form-control', 'placeholder' => '- Seleccionar -']) }}
                                </div>
                                <div class="d-inline-block">
                                    <button type="submit" class="btn btn-primary">Buscar</button>
                                    <a href="{{ route('payment_delayeds.index') }}" type="button"
                                       class="btn btn-secondary">Resetear</a>
                                </div>
                                {{ Form::close() }}
                            </div>
                            <div class="col-2 text-right">
                                @can('import', \App\PaymentDelayed::class)
                                    <button class="btn btn-primary" title="Importar archivo" data-toggle="modal"
                                            data-target="#importModal">
                                        <i class="fas fa-upload"></i></button>
                                @endcan
                                <a class="btn btn-danger" href="{{ route('payment-delayed-log.index') }}"
                                   title="Registros no importados">
                                    <i class="fas fa-exclamation"></i>
                                </a>
                            </div>
                        </div>

                        @include('flash::message')

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Asesor</th>
                                <th>Compañia</th>
                                <th>Contratante</th>
                                <th>Poliza</th>
                                <th>Monto</th>
                                <th>F. Vencimiento</th>
                                <th>Modalidad cobro</th>
                                <th>Motivo rechazo</th>
                                <th>Cuotas (#)</th>
                                <th>Documento pago</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($paymentDelayeds as $paymentDelayed)
                                <tr>
                                    <td>{{ $paymentDelayed->id }}</td>
                                    <td>{{ $paymentDelayed->assessor->name }}</td>
                                    <td>{{ $paymentDelayed->company->name }}</td>
                                    <td>{{ $paymentDelayed->customer->name }}</td>
                                    <td>{{ $paymentDelayed->policy->code }}</td>
                                    <td>{{ $paymentDelayed->policy->currency }} {{ $paymentDelayed->amount }}</td>
                                    <td>{{ $paymentDelayed->paymentExpirationDate }}</td>
                                    <td>{{ $paymentDelayed->payment_method }}</td>
                                    <td>{{ $paymentDelayed->rejection_reason }}</td>
                                    <td>{{ $paymentDelayed->dues }}</td>
                                    <td>{{ $paymentDelayed->payment_document }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $paymentDelayeds->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('payment_delayeds.store'), 'files' => true, 'id'=>'frmModal']) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Importar deudas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    Descarga la siguiente <a target="_blank"
                                             href="{{ asset('MorganPlantillaDeudas.csv') }}">plantilla</a>, llena los
                    campos y sube el archivo para ser importado.
                    <div class="form-group mt-3">
                        <div class="font-weight-bold">Compañia</div>
                        <div class="mb-3">
                            {{ Form::select('company_id',dropdownData('Companies'), null, ['class' => 'form-control', 'required' => true, 'style' => 'width: 300px']) }}
                        </div>
                        <div class="font-weight-bold">Archivo</div>
                        <div>
                            {{ Form::file('file', ['required'=>true]) }}
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script>
        window.onload = function () {
            $('select').select2();
        };
    </script>
@endpush
