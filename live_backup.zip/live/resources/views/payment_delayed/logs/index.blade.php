@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Deudas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="/payment_delayeds">Deudas</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Logs</li>
                    </ol>
                </nav>

                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>Poliza</th>
                                <th>Monto</th>
                                <th>Fecha Vencimiento</th>
                                <th>Motivo Rechazo</th>
                                <th>Cuotas</th>
                                <th>Modalidad Cobro</th>
                                <th>Documento Pago</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($logs as $paying)
                                <tr>
                                    <td>{{ $paying->policy }}</td>
                                    <td>{{ $paying->amount }}</td>
                                    <td>{{ $paying->expiry_date }}</td>
                                    <td>{{ $paying->reason }}</td>
                                    <td>{{ $paying->dues }}</td>
                                    <td>{{ $paying->modality }}</td>
                                    <td>{{ $paying->document }}</td>
                                    <td>{{ $paying->status }}</td>
                                    <td>{{ $paying->created_at }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $logs->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="importPayingModal" tabindex="-1" role="dialog"
         aria-labelledby="importPayingModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('payings.store'), 'files' => true]) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importPayingModalLabel">Importar liquidaciones</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        Descarga la siguiente <a href="/MorganPlantillaLiquidaciones.csv"
                                                 target="_blank">plantilla</a>, llena los campos y sube el archivo
                        para ser importado.
                    </div>
                    <div class="form-group form-row">
                        <div class="col-4">Archivo</div>
                        <div class="col">
                            <input type="file" id="file" ref="file" name="file"/>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $(function () {
                $('[data-toggle="tooltip"]').tooltip();
            })
            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar la poliza?');
                if (!confirm) {
                    e.preventDefault();
                }
            })
        };
    </script>
@endpush
