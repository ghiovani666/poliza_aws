@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Mi Perfil</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Mi Perfil</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        {{ Form::model($employee,['url' => route('profile.update'), 'method' => 'POST']) }}
                        <div class="row">
                            <div class="col">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Nombre</label>
                                    <div class="col">
                                        {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('name') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Correo</label>
                                    <div class="col">
                                        {{ Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('email') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Telefono</label>
                                    <div class="col">
                                        {{ Form::text('phone', null, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">DNI</label>
                                    <div class="col">
                                        {{ Form::text('dni', null, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Fecha de nacimiento</label>
                                    <div class="col">
                                        {{ Form::date('birth_date', null, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Cambiar contraseña</label>
                                    <div class="col">
                                        {{ Form::password('password', ['class' => 'form-control'.($errors->has('password') ? ' is-invalid': null)]) }}
                                        <div class="text-muted">Llenar solo si desea cambiar su contraseña.</div>
                                        <div class="invalid-feedback">{{ $errors->first('password') }}</div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Confirmar contraseña</label>
                                    <div class="col">
                                        {{ Form::password('password_confirmation', ['class' => 'form-control'.($errors->has('password_confirmation') ? ' is-invalid': null)]) }}
                                        <div class="text-muted">Llenar solo si desea cambiar su contraseña.</div>
                                        <div class="invalid-feedback">{{ $errors->first('password_confirmation') }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
