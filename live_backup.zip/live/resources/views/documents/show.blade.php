@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="h2 d-inline-block">EMPLEADOS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('employees.index') }}">Empleados</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $employee->name }}</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="h5">Informacion</div>
                                <table class="table">
                                    <tr>
                                        <td>Tipo de empleado</td>
                                        <td>{{ $employee->job->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Nombre</td>
                                        <td>{{ $employee->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Correo</td>
                                        <td>{{ $employee->email }}</td>
                                    </tr>
                                    <tr>
                                        <td>Telefono</td>
                                        <td>{{ $employee->phone }}</td>
                                    </tr>
                                    <tr>
                                        <td>DNI</td>
                                        <td>{{ $employee->dni }}</td>
                                    </tr>
                                    <tr>
                                        <td>Fecha de nacimiento</td>
                                        <td>{{ $employee->birth_date }}</td>
                                    </tr>
                                    <tr>
                                        <td>Fecha de ingreso</td>
                                        <td>{{ $employee->start_date }}</td>
                                    </tr>
                                    <tr>
                                        <td># CUSPP</td>
                                        <td>{{ $employee->cuspp_number }}</td>
                                    </tr>
                                    <tr>
                                        <td>Sueldo basico</td>
                                        <td>{{ $employee->salary_base }}</td>
                                    </tr>
                                    <tr>
                                        <td>Sistema de pension</td>
                                        <td>{{ $employee->pension_system }}</td>
                                    </tr>
                                    <tr>
                                        <td>Comision por ventas</td>
                                        <td>{{ $employee->sale_commission }}</td>
                                    </tr>
                                    <tr>
                                        <td>Comision por renovacion</td>
                                        <td>{{ $employee->renew_commission }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col">
                                <div class="h5">Descuentos</div>
                                <table class="table">
                                    <tr>
                                        <td>O.N.P. 13%</td>
                                        <td>S/{{ $employee->discount_onp }}</td>
                                    </tr>
                                    <tr>
                                        <td>Comis. AFP</td>
                                        <td>S/{{ $employee->discount_afp_commission }}</td>
                                    </tr>
                                    <tr>
                                        <td>Prima AFP</td>
                                        <td>S/{{ $employee->discount_afp_prime }}</td>
                                    </tr>
                                    <tr>
                                        <td>Aport AFP</td>
                                        <td>S/{{ $employee->discount_afp_goal }}</td>
                                    </tr>
                                </table>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="h5">Boletas</div>
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>Periodo</th>
                                        <th>Total descuentos</th>
                                        <th>Neto a pagar</th>
                                        <th>Essalud</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Julio 2019</td>
                                        <td>S/.689.04</td>
                                        <td>S/.1710.96</td>
                                        <td>S/.216.00</td>
                                        <td>
                                            <a href="#" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-file-invoice-dollar"></i></a>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
