<div class="row">
    <div class="col">
        <!--
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Compañia</label>
            <div class="col">
                {{ Form::select('company_id', dropdownData('Companies'), null, ['placeholder' => '- Selecionar -','class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        -->
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Documento</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Link</label>
            <div class="col">
                {{ Form::text('url', null, ['class' => 'form-control','placeholder' => 'http://']) }}
                <small class="text-muted">Ingrese el URL completo, por ejemplo: https://www.sunat.gob.pe</small>
            </div>
        </div>
    </div>
    <div class="col">
    </div>
</div>
