@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">DOCUMENTOS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Documentos</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('create',\App\Document::class)
                        <a class="btn btn-primary" href="{{ route('documents.create') }}">
                            <i class="fas fa-plus"></i>Nuevo
                        </a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">

                        @include('flash::message')

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <!--<th>Compañia</th>-->
                                <th>Documento</th>
                                <th>F. Registro</th>
                                <th>Descargar</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($documents as $document)
                                <tr>
                                    <td>{{ $document->id }}</td>
                                <!--<td>{{ $document->company->name }}</td>-->
                                    <td>{{ $document->name }}</td>
                                    <td>{{ $document->createdDateTime }}</td>
                                    <td><a target="_blank" href="{{ $document->url }}">Descargar</a></td>
                                    <td class="text-right">
                                        @can('update',$document)
                                            <a href="{{ route('documents.edit', $document) }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i>
                                            </a>
                                        @endcan
                                        @can('delete',$document)
                                            {{ Form::open(['class' => 'frm-delete', 'url' => route('documents.destroy',$document), 'method' => 'DELETE']) }}
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                            {{ Form::close() }}
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('styles')
    <style type="text/css">
        .frm-delete {
            display: inline;
        }
    </style>
@endpush
@push('scripts')
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            $('.frm-delete').submit(function (evt) {
                let confirm = window.confirm("¿Seguro desea eliminar el documento?")
                if (confirm === false) {
                    evt.preventDefault()
                }
            })
        });
    </script>
@endpush
