@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">DOCUMENTOS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('documents.index') }}">Documentos</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['url' => route('documents.store'), 'files' => true]) }}
                        @include('documents._form')
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
