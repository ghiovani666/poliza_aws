@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Reclamos</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    {{-- <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Reclamos</li>
                    </ol> --}}
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="/">Inicio</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.index') }}">
                                Cartera de clientes
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('customers.show', $policy->customer) }}">
                                {{ $policy->customer->name }}
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.comments.index', $policy->id) }}">
                                {{ $policy->id }}
                            </a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">
                            Reclamos
                        </li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('export',\App\Policy::class)
                        <a class="btn btn-secondary" href="{{ route('policies.claims.export', $policy) }}" title="Descargar">
                            <i class="fas fa-file-excel"></i>
                        </a>
                    @endcan
                    @can('create',\App\Policy::class)
                        <a class="btn btn-primary" href="{{ route('policies.claims.create', $policy) }}">
                            <i class="fas fa-plus mr-2"></i>Nuevo
                        </a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        {{-- <div class="mb-2">
                            {{ Form::open(['url' => route('policies.index'), 'method' => 'GET']) }}

                            <div class="mb-2">
                                <div class="d-inline-block mr-2" title="Contratante" style="width: 160px">
                                    {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'placeholder' => 'Contratante', 'style' => 'width: 100%;']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de documento" style="width: 160px">
                                    {{ Form::text('document', request('document'), ['class' => 'form-control', 'placeholder' => 'Numero de documento', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de poliza" style="width: 160px">
                                    {{ Form::text('code', request('code'), ['class' => 'form-control', 'placeholder' => 'Numero de accidente', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Status de accidente" style="width: 160px">
                                    {{ Form::select('active', \App\Enums\PolicyActiveType::toSelectArray(), request('active'), ['class' => 'form-control', 'style' => '100%', 'placeholder' => '- Status de poliza -']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Estado" style="width: 160px">
                                    {{ Form::select('status_id', dropdownData('PolicyStatuses'), request('status_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Estado -']) }}
                                </div>

                            </div>

                            <div>
                                <div class="d-inline-block mr-2" title="Fecha de solicitud" style="width: 160px">
                                    {{ Form::text('request_date', request('request_date'), ['class' => 'form-control', 'placeholder' => 'Fecha de solicitud', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Fecha de vigencia" style="width: 160px">
                                    {{ Form::text('validity_date', request('validity_date'), ['class' => 'form-control', 'placeholder' => 'Inicio de vigencia', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Asesor" style="width: 160px">
                                    {{ Form::select('assessor_id', dropdownData('Employees'), request('assessor_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Asesor -']) }}
                                </div>

                                <button class="btn btn-primary ml-2">Buscar</button>
                                <a href="/policies" class="btn btn-secondary">Resetear</a>
                            </div>

                            {{ Form::close() }}
                        </div> --}}
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                {{-- <th>Poliza</th> --}}
                                <th>Tipo</th>
                                <th>Fecha del Reclamo</th>
                                <th>Motivo</th>
                                <th>Monto solicitado</th>
                                <th>Resultado</th>
                                <th>Fecha de resolución</th>
                                <th>Estado</th>
                                {{-- <th>Comentarios adicionales</th> --}}
                                {{-- <th>Documentos adjuntos</th> --}}
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($claims as $claim)
                                <tr>
                                    <td>{{ $claim->id }}</td>
                                    <td>{{ App\Enums\ClaimType::getDescription($claim->type) }}</td>
                                    <td>{{ $claim->submission_date }}</td>
                                    <td>{{ $claim->reason }}</td>
                                    <td>{{ $claim->money_amount_claimed }}</td>
                                    <td>{{ App\Enums\ClaimResult::getDescription($claim->result) }}</td>
                                    <td>{{ $claim->resolution_date }}</td>
                                    <td>{{ App\Enums\ClaimState::getDescription($claim->state) }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        @can('update', $claim)
                                            <a class="btn btn-secondary btn-sm"
                                               href="{{ route('policies.claims.edit', [$policy, $claim]) }}">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @endcan
                                        @can('delete', $claim)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $claim->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="14">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $claims->appends(request()->input())->links() }}
                            </div>
                            <div class="col text-right">
                                @can('create',\App\Policy::class)
                                    <a class="btn btn-primary" href="{{ route('policies.claims.create', $policy) }}">
                                        <i class="fas fa-plus mr-2"></i>Nuevo
                                    </a>
                                @endcan
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($claims as $claim)
        <div class="modal fade" id="deleteModal{{$claim->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar el reclamo?</div>
                        <table class="table">
                            {{-- <tr>
                                <td>Cliente</td>
                                <td>{{ $claim->customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Poliza ID</td>
                                <td>{{ $claim->id }}</td>
                            </tr> --}}
                            <tr>
                                <td>Siniestro ID</td>
                                <td>{{ $claim->id }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.claims.destroy', [$policy, $claim]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('[data-toggle="tooltip"]').tooltip();

            $('input[name="request_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="request_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('input[name="validity_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="validity_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('select[name="assessor_id"]').select2();

            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar el reclamo?');
                if (!confirm) {
                    e.preventDefault();
                }
            })
        };
    </script>
@endpush
