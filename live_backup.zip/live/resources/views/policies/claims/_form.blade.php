<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                <input class="form-control" disabled value="{{ $policy->code }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Teléfono del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->phone }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Email del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->email }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->assessor->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Aseguradora</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->company->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ramo</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->sector->name }}" />
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo</label>
            <div class="col">
                {{ Form::select('type', \App\Enums\ClaimType::toSelectArray(), null, ['class' => 'form-control'.($errors->has('type') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha del reclamo</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'submission_date', null, ['class' => 'form-control'.($errors->has('submission_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('submission_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Motivo</label>
            <div class="col">
                {{ Form::text('reason', null, ['class' => 'form-control'.($errors->has('reason') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('reason') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto solicitado</label>
            <div class="col">
                {{ Form::text('money_amount_claimed', null, ['id' => 'money_amount_claimed', 'class' => 'form-control'.($errors->has('money_amount_claimed') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('money_amount_claimed') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Resultado</label>
            <div class="col">
                {{ Form::select('result', \App\Enums\ClaimResult::toSelectArray(), null, ['class' => 'form-control'.($errors->has('result') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('result') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de Resolución</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'resolution_date', null, ['class' => 'form-control'.($errors->has('resolution_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('resolution_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Estado</label>
            <div class="col">
                {{ Form::select('state', \App\Enums\ClaimState::toSelectArray(), null, ['class' => 'form-control'.($errors->has('state') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('state') }}</div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comentarios Adicionales</label>
            <div class="col">
                {{ Form::textarea('adicional_comments', null, ['class' => 'form-control'.($errors->has('adicional_comments') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('adicional_comments') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Archivos</label>
            <div class="col">
                <files-uploader :initialfiles="{{ @$claim ? $claim->files : '[]' }}" target="claims" mode="{{ @$claim ? "update" : "create" }}" entityid="{{ @$claim ? $claim->id : null }}"></files-uploader>
            </div>
        </div>

    </div>
</div>
<input type="hidden" name="return" value="{{ request('return') }}">
<script>
    window.addEventListener("load", () => {
        $("input#money_amount_claimed").on("input", function(evt) {
            if (
                $(this).val().split(".")[0].length > 6 ||
                $(this).val().split(".")[1]?.length > 2 ||
                isNaN($(this).val())
            ) {
                $(this).val($(this).val().slice(0, -1));
            }
        });
    });
</script>
