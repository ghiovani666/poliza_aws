@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Reclamos</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="/">Inicio</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.index') }}">
                                Cartera de clientes
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('customers.show', $policy->customer) }}">
                                {{ $policy->customer->name }}
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.comments.index', $policy->id) }}">
                                {{ $policy->id }}
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.claims.index', $policy) }}">
                                Reclamos
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.claims.edit', [$policy, $claim]) }}">
                                {{ $claim->id }}
                            </a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Editar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::model($claim, ['id' => 'frm-edit', 'url' => route('policies.claims.update', [$policy, $claim]), 'method' => 'PUT']) }}
                        @include('policies.claims._form')
                        <hr>
                        <div class="row">
                            <div class="col text-right">
                                <button class="btn btn-primary">
                                    Guardar
                                </button>
                            </div>
                        </div>
                        <input name="policy_id" type="hidden" value="{{ $policy->id }}">
                        <input id="refresh" name="refresh" type="hidden" value="">
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>

        <div>

        </div>
    </div>
@endsection
{{-- @push('scripts')
    <script type="text/javascript">
        let products = @json($productsResource);

        window.onload = function () {
            $('select[name=customer_id]').select2();
            $('select[name=broker_id]').select2();
            $('select[name=assessor_id]').select2();
            $('select[name=key_id]').select2();

            // customer
            $('select[name=customer_id]').change(function () {
                if ($(this).val() === '') {
                    $('#refresh').val(9);
                } else {
                    $('#refresh').val(1);
                }

                $('#frm-create').submit();
            });

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                axios.get('sectors?company_id=' + company_id).then((response) => {
                    $('select[name=sector_id]').empty();
                    $('select[name=sector_id]').append($("<option />").val('').text('- Seleccionar -'));
                    response.data.data.forEach(function (sector) {
                        $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                axios.get('products?sector_id=' + sector_id).then((response) => {
                    products = response.data.data;
                    $('select[name=product_id]').empty();
                    $('select[name=product_id]').append($("<option />").val('').text('- Seleccionar -'));
                    response.data.data.forEach(function (sector) {
                        $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                        $('input[name=commission_percentage]').val(sector.commission);
                        calculateCommission();
                    });
                });
            });
            $('select[name=product_id]').change(function () {
                let product_id = $('select[name=product_id]').val();
                let product = products.find(obj => obj.id == product_id);

                $('input[name=commission_percentage]').val(product.commission);
                calculateCommission();
            });

            // prime
            $('input[name=prime]').change(function () {
                calculateCommission();
            });
        };

        function calculateCommission() {
            console.log('start calculating commission');
            let value = parseFloat($('input[name=prime]').val());
            let percentage = parseFloat($('input[name=commission_percentage]').val());
            if (percentage > 0 && value > 0) {
                let estimated = value * percentage / 100;
                $('input[name=commission_estimated]').val(estimated);
                $('input[name=commission_real]').val(estimated);
            } else {
                $('input[name=commission_estimated]').val(0);
                $('input[name=commission_real]').val(0);
            }eval ()
            console.log(value);
            console.log(percentage);
        }
    </script>
@endpush --}}
