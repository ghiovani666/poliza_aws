@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Polizas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Polizas</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['id' => 'frm-create','url' => route('policies.store'), 'method' => 'POST']) }}
                        @include('policies._form')
                        <hr>
                        <div class="row">
                            <div class="col text-right">
                                <button class="btn btn-primary">Guardar & Continuar</button>
                            </div>
                        </div>
                        <input id="refresh" name="refresh" type="hidden" value="">
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=customer_id]').select2();
            $('select[name=broker_id]').select2();
            $('select[name=assessor_id]').select2();
            $('select[name=key_id]').select2();
            $('select[name=customer_id]').change(function () {
                if ($(this).val() === '') {
                    $('#refresh').val(9);
                } else {
                    $('#refresh').val(1);
                }

                $('#frm-create').submit();
            });

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                axios.get('sectors?company_id=' + company_id).then((response) => {
                    $('select[name=sector_id]').empty();
                    $('select[name=sector_id]').append($("<option />").val('').text('- Seleccionar -'));
                    response.data.data.forEach(function (sector) {
                        $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                axios.get('products?sector_id=' + sector_id).then((response) => {
                    $('select[name=product_id]').empty();
                    $('select[name=product_id]').append($("<option />").val('').text('- Seleccionar -'));
                    response.data.data.forEach(function (sector) {
                        $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                        $('input[name=commission_percentage]').val(sector.commission);
                        calculateCommission();
                    });
                });
            });

            //
            $('input[name=prime]').change(function () {
                calculateCommission();
            });
        };

        function calculateCommission() {
            let value = parseFloat($('input[name=prime]').val());
            let percentage = parseFloat($('input[name=commission_percentage]').val());
            if (percentage > 0 && value > 0) {
                let estimated = value * percentage / 100;
                $('input[name=commission_estimated]').val(estimated);
                $('input[name=commission_real]').val(estimated);
            }
        }
    </script>
@endpush
