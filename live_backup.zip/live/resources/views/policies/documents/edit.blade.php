@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">EMPLEADOS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('keys.index') }}">Policies</a></li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.show',$policy) }}">{{ $policy->customer->name }}</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.documents.index',$policy) }}">Documentos</a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Actualizar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        {{ Form::model($document,['url' => route('policies.documents.update', [$policy, $document]), 'method' => 'PUT']) }}
                        @include('policies.documents._form')
                        <hr>
                        <div class="row">
                            <div class="col">
                                <a href="{{ route('policies.documents.index', $policy) }}"
                                   class="btn btn-secondary">Volver</a>
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
