@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Comentarios</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        <comments id="{{ $policy->id }}" type="{{ \App\Policy::class }}"></comments>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
