<ul class="nav nav-tabs mb-2">
    <li class="nav-item">
        <a id="documents"></a>
        <a class="nav-link {{ activeUrl(['policies/*/comments','policies/*/comments/*']) }}"
           href="{{ route('policies.comments.index',$policy) }}#comments">Comentarios</a>
    </li>
    <li class="nav-item">
        <a id="documents"></a>
        <a class="nav-link {{ activeUrl(['policies/*/documents','policies/*/documents/*']) }}"
           href="{{ route('policies.documents.index',$policy) }}#documents">Documentos</a>
    </li>
    <li class="nav-item">
        <a id="beneficiaries"></a>
        <a class="nav-link {{ activeUrl(['policies/*/beneficiaries','policies/*/beneficiaries/*']) }}"
           href="{{ route('policies.beneficiaries.index',$policy) }}#beneficiaries">Beneficiarios</a>
    </li>
    <li class="nav-item">
        <a id="insureds"></a>
        <a class="nav-link {{ activeUrl(['policies/*/insureds','policies/*/insureds/*']) }}"
           href="{{ route('policies.insureds.index',$policy) }}#insureds">Asegurados</a>
    </li>
    <li class="nav-item">
        <a id="vehicles"></a>
        <a class="nav-link {{ activeUrl(['policies/*/vehicles','policies/*/vehicles/*']) }}"
           href="{{ route('policies.vehicles.index',$policy) }}#vehicles">Vehiculos</a>
    </li>
    <li class="nav-item">
        <a id="vehicles"></a>
        <a class="nav-link {{ activeUrl(['policies/*/payments','policies/*/payments/*']) }}"
           href="{{ route('policies.payments.index',$policy) }}#payments">Deudas</a>
    </li>
    <li class="nav-item">
        <a id="alerts"></a>
        <a class="nav-link {{ activeUrl(['policies/*/alerts','policies/*/alerts/*']) }}"
           href="{{ route('policies.alerts.index',$policy) }}#alerts">Alertas</a>
    </li>
</ul>
