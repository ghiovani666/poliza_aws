@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('policies.documents.index',$policy) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Documentos</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">

                    </div>
                </div>

                @include('policies._detail')

                <hr>
                <h3>Documentos</h3>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>URL</th>
                        <th>F. Registro</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($policy->documents as $document)
                        <tr>
                            <td>{{ $document->id }}</td>
                            <td>{{ $document->name }}</td>
                            <td><a target="_blank" href="{{ $document->url }}">{{ $document->url }}</a></td>
                            <td>{{ $document->created_at->tz('America/Lima') }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                <hr>
                <h3>Beneficiarios</h3>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Tipo Documento</th>
                        <th>Numero Documento</th>
                        <th>Fecha de nacmiento</th>
                        <th>Beneficio (%)</th>
                        <th>F. Registro</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($policy->beneficiaries as $beneficiary)
                        <tr>
                            <td>{{ $beneficiary->id }}</td>
                            <td>{{ $beneficiary->name }}</td>
                            <td>{{ \App\Enums\DocumentType::getDescription($beneficiary->document_type) }}</td>
                            <td>{{ $beneficiary->document_number }}</td>
                            <td>{{ $beneficiary->birth_date }}</td>
                            <td>{{ $beneficiary->percentage }}</td>
                            <td>{{ $beneficiary->created_at->tz('America/Lima') }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                <hr>
                <h3>Asegurados</h3>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Tipo Documento</th>
                        <th>Numero Documento</th>
                        <th>Fecha de nacmiento</th>
                        <th>EPS</th>
                        <th>Tipo EPS</th>
                        <th>F. Registro</th>
                        <th>Estado</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($policy->insureds as $insured)
                        <tr>
                            <td>{{ $insured->id }}</td>
                            <td>{{ $insured->name }}</td>
                            <td>{{ \App\Enums\DocumentType::getDescription($insured->document_type) }}</td>
                            <td>{{ $insured->document_number }}</td>
                            <td>{{ $insured->birth_date }}</td>
                            <td>{{ $insured->with_eps ? 'Si' : 'No' }}</td>
                            <td>{{ \App\Enums\EPSType::getDescription($insured->eps_type) }}</td>
                            <td>{{ $insured->created_at }}</td>
                            <td>{{ $insured->enabled ? 'Activo' : 'Eliminado' }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                <hr>
                <h3>Vehiculos</h3>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Uso</th>
                        <th>Placa</th>
                        <th>Motor</th>
                        <th>Chasis</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Año de fabricacion</th>
                        <th>Valor comercial</th>
                        <th># certificado</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($policy->vehicles as $vehicle)
                        <tr>
                            <td>{{ $vehicle->id }}</td>
                            <td>{{ $vehicle->category->name }}</td>
                            <td>{{ $vehicle->use }}</td>
                            <td>{{ $vehicle->plate_number }}</td>
                            <td>{{ $vehicle->engine }}</td>
                            <td>{{ $vehicle->chassis }}</td>
                            <td>{{ $vehicle->brand }}</td>
                            <td>{{ $vehicle->model }}</td>
                            <td>{{ $vehicle->manufacturing_year }}</td>
                            <td>{{ $vehicle->commercial_value }} ({{ $vehicle->currency }})</td>
                            <td>{{ $vehicle->certificate_number }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                <hr>
                <h3>Deudas</h3>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Monto</th>
                        <th>F. Vencimiento</th>
                        <th>Modalidad cobro</th>
                        <th>Motivo rechazo</th>
                        <th>Cuotas (#)</th>
                        <th>Documento pago</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($policy->payments as $payment)
                        <tr>
                            <td>{{ $payment->id }}</td>
                            <td>{{ $payment->policy->currency }} {{ $payment->amount }}</td>
                            <td>{{ $payment->paymentExpirationDate }}</td>
                            <td>{{ $payment->payment_method }}</td>
                            <td>{{ $payment->rejection_reason }}</td>
                            <td>{{ $payment->dues }}</td>
                            <td>{{ $payment->payment_document }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script>
        window.onload = function () {
            window.print();
        };
    </script>
@endpush
