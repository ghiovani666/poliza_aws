@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Asegurados</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        {{ Form::model($policy, ['url' => route('policies.alerts.update',$policy), 'method' => 'PUT']) }}
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td style="width: 32px">
                                    {{ Form::hidden('alert_royalties_enabled', 0) }}
                                    {{ Form::checkbox('alert_royalties_enabled', 1, $policy->alert_royalties_enabled) }}
                                </td>
                                <td style="width: 130px">Alerta de Fidelizacion</td>
                                <td style="width: 60px">
                                    <input name="alert_royalties_days" value="{{ $policy->alert_royalties_days }}"
                                           type="number" class="form-control text-center" style="width: 60px">
                                </td>
                                <td>días después del inicio de la póliza.</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td style="width: 32px">
                                    {{ Form::hidden('alert_surveys_enabled', 0) }}
                                    {{ Form::checkbox('alert_surveys_enabled', 1, $policy->alert_surveys_enabled) }}
                                </td>
                                <td style="width: 130px">Alerta de Encuesta</td>
                                <td style="width: 60px">
                                    <input name="alert_surveys_days" value="{{ $policy->alert_surveys_days }}"
                                           type="number" class="form-control text-center" style="width: 60px">
                                </td>
                                <td>días después del inicio de la póliza.</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td style="width: 32px">
                                    {{ Form::hidden('alert_renewal_enabled', 0) }}
                                    {{ Form::checkbox('alert_renewal_enabled', 1, $policy->alert_renewal_enabled) }}
                                </td>
                                <td style="width: 130px">Alerta de Renovacion</td>
                                <td style="width: 60px">
                                    <input name="alert_renewal_days" value="{{ $policy->alert_renewal_days }}"
                                           type="number" class="form-control text-center" style="width: 60px">
                                </td>
                                <td>días después del inicio de la póliza.</td>
                                <td></td>
                            </tr>
                        </table>
                        <hr>
                        <button class="btn btn-primary">Guardar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
