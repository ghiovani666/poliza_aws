@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Documentos</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Monto</th>
                                <th>F. Vencimiento</th>
                                <th>Modalidad cobro</th>
                                <th>Motivo rechazo</th>
                                <th>Cuotas (#)</th>
                                <th>Documento pago</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($payments as $payment)
                                <tr>
                                    <td>{{ $payment->id }}</td>
                                    <td>{{ $payment->policy->currency }} {{ $payment->amount }}</td>
                                    <td>{{ $payment->paymentExpirationDate }}</td>
                                    <td>{{ $payment->payment_method }}</td>
                                    <td>{{ $payment->rejection_reason }}</td>
                                    <td>{{ $payment->dues }}</td>
                                    <td>{{ $payment->payment_document }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $payments->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('policies.documents.import', $policy), 'files' => true]) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Importar Registros</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">Descarga la siguiente <a href="{{ asset('MorganTemplateDocuments.csv') }}">plantilla</a>,
                        llena los campos y sube el archivo para ser importado.
                    </div>
                    <div class="text-center mt-3">
                        <input type="file" name="file">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($payments as $payment)
        <div class="modal fade" id="deleteModal{{$payment->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el documento?</div>
                        <table class="table">
                            <tr>
                                <td style="width: 150px">ID del documento</td>
                                <th>{{ $payment->id }}</th>
                            </tr>
                            <tr>
                                <td>Nombre del documento</td>
                                <th>{{ $payment->name }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.documents.destroy', [$policy, $payment]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
