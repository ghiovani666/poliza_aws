@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Vehiculos</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        <div class="text-right mb-2">
                            @can('import', \App\PolicyVehicle::class)
                                <button class="btn btn-primary" data-toggle="modal" data-target="#importModal">
                                    <i class="fas fa-upload mr-2"></i> Importar
                                </button>
                            @endcan
                            @can('create', \App\PolicyVehicle::class)
                                <a class="btn btn-primary"
                                   href="{{ route('policies.vehicles.create',$policy) }}#vehicles">
                                    <i class="fas fa-plus mr-2"></i>Nuevo</a>
                            @endcan
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tipo</th>
                                <th>Uso</th>
                                <th>Placa</th>
                                <th>Motor</th>
                                <th>Chasis</th>
                                <th>Marca</th>
                                <th>Modelo</th>
                                <th>Año de fabricacion</th>
                                <th>Valor comercial</th>
                                <th># certificado</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($vehicles as $vehicle)
                                <tr>
                                    <td>{{ $vehicle->id }}</td>
                                    <td>{{ $vehicle->category->name }}</td>
                                    <td>{{ $vehicle->use }}</td>
                                    <td>{{ $vehicle->plate_number }}</td>
                                    <td>{{ $vehicle->engine }}</td>
                                    <td>{{ $vehicle->chassis }}</td>
                                    <td>{{ $vehicle->brand }}</td>
                                    <td>{{ $vehicle->model }}</td>
                                    <td>{{ $vehicle->manufacturing_year }}</td>
                                    <td>{{ $vehicle->commercial_value }} ({{ $vehicle->currency }})</td>
                                    <td>{{ $vehicle->certificate_number }}</td>
                                    <td class="text-right">
                                        @if ($policy->status->editable)
                                            <a href="{{ route('policies.vehicles.edit', [$policy, $vehicle]) }}#vehicles"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $vehicle->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $vehicles->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('policies.vehicles.import', $policy), 'files' => true]) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Importar Registros</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">Descarga la siguiente <a
                            href="{{ asset('MorganPlantillaVehiculos.csv') }}">plantilla</a>, llena los campos y sube
                        el archivo para ser importado.
                    </div>
                    <div class="text-center mt-3">
                        <input type="file" name="file">
                    </div>
                    <hr>
                    <div class="text-center">Valores para tipo de vehiculo (usar ID's para importar)</div>
                    <div class="row">
                        <div class="col">
                            <table class="table table-borderless table-sm">
                                <tr>
                                    <th>Tipo</th>
                                    <th>ID</th>
                                </tr>
                                @foreach ($vehicleTypes->take(5) as $id => $name)
                                    <tr>
                                        <td>{{ $name }}</td>
                                        <th>{{ $id }}</th>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                        <div class="col">
                            <table class="table table-borderless table-sm">
                                <tr>
                                    <th>Tipo</th>
                                    <th>ID</th>
                                </tr>
                                @foreach ($vehicleTypes->slice(5)->take(5) as $id => $name)
                                    <tr>
                                        <td>{{ $name }}</td>
                                        <th>{{ $id }}</th>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($vehicles as $vehicle)
        <div class="modal fade" id="deleteModal{{$vehicle->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el vehiculo?</div>
                        <table class="table">
                            <tr>
                                <td style="width: 150px">ID</td>
                                <th>{{ $vehicle->id }}</th>
                            </tr>
                            <tr>
                                <td>Placa</td>
                                <th>{{ $vehicle->plate_number }}</th>
                            </tr>
                            <tr>
                                <td>Certificado (#)</td>
                                <th>{{ $vehicle->certificate_number }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.vehicles.destroy', [$policy, $vehicle]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
