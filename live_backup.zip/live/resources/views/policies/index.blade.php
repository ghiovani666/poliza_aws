@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Polizas</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Polizas</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('export',\App\Policy::class)
                        <button class="btn btn-secondary action-export" data-url="{{ route('policies.export') }}" title="Exportar Pólizas">
                            <i class="fas fa-file-excel mr-1"></i>
                            Exportar Pólizas
                        </button>
                    @endcan
                    @can('export',\App\Policy::class)
                        <button class="btn btn-secondary action-export" data-url="{{ route('policies.accidents.export_all') }}" title="Exportar Siniestros">
                            <i class="fas fa-file-excel mr-1"></i> Exportar Siniestros
                        </button>
                    @endcan
                    @can('export',\App\Policy::class)
                        <button class="btn btn-secondary action-export" data-url="{{ route('policies.claims.export_all') }}" title="Exportar Reclamos">
                            <i class="fas fa-file-excel mr-1"></i> Exportar Reclamos
                        </button>
                    @endcan
                    {{-- @can('export',\App\Policy::class)
                        <a class="btn btn-secondary" href="{{ route('policies.export') }}" title="Descargar">
                            <i class="fas fa-file-excel"></i>
                        </a>
                    @endcan --}}
                    @can('create',\App\Policy::class)
                        <a class="btn btn-primary" href="{{ route('policies.create') }}">
                            <i class="fas fa-plus mr-2"></i> Nuevo
                        </a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <div class="mb-2">
                            {{ Form::open(['url' => route('policies.index'), 'method' => 'GET']) }}

                            <div class="mb-2">
                                <div class="d-inline-block mr-2" title="Contratante" style="width: 160px">
                                    {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'placeholder' => 'Contratante', 'style' => 'width: 100%;']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de documento" style="width: 160px">
                                    {{ Form::text('document', request('document'), ['class' => 'form-control', 'placeholder' => 'Numero de documento', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de poliza" style="width: 160px">
                                    {{ Form::text('code', request('code'), ['class' => 'form-control', 'placeholder' => 'Numero de poliza', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Status de poliza" style="width: 160px">
                                    {{ Form::select('active', \App\Enums\PolicyActiveType::toSelectArray(), request('active'), ['class' => 'form-control', 'style' => '100%', 'placeholder' => '- Status de poliza -']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Estado" style="width: 160px">
                                    {{ Form::select('status_id', dropdownData('PolicyStatuses'), request('status_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Estado -']) }}
                                </div>

                            </div>

                            <div>
                                <div class="d-inline-block mr-2" title="Fecha de solicitud" style="width: 160px">
                                    {{ Form::text('request_date', request('request_date'), ['class' => 'form-control', 'placeholder' => 'Fecha de solicitud', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Fecha de vigencia" style="width: 160px">
                                    {{ Form::text('validity_date', request('validity_date'), ['class' => 'form-control', 'placeholder' => 'Inicio de vigencia', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Asesor" style="width: 160px">
                                    {{ Form::select('assessor_id', dropdownData('Employees'), request('assessor_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Asesor -']) }}
                                </div>

                                <button class="btn btn-primary ml-2">Buscar</button>
                                <a href="/policies" class="btn btn-secondary">Resetear</a>
                            </div>

                            {{ Form::close() }}
                        </div>
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Contratante</th>
                                <th>Poliza</th>
                                <th>Solicitud</th>
                                <th>Inicio de vigencia</th>
                                <th>Compañia</th>
                                <th>Moneda</th>
                                <th>Prima Neta</th>
                                <th>Tipo de venta</th>
                                <th>Asesor</th>
                                <th>Status de Póliza</th>
                                <th>Estado</th>
                                <th>Comision Real</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($policies as $policy)
                                <tr>
                                    <td>{{ $policy->id }}</td>
                                    <td>
                                        {{ $policy->customer->name }}
                                        <div class="d-inline" data-toggle="modal"
                                             data-target="#quickModal{{ $policy->id }}"
                                             style="cursor: pointer; color: blue">
                                            <i class="fas fa-eye"></i>
                                        </div>
                                    </td>
                                    <td>{{ $policy->code }}</td>
                                    <td>{{ $policy->requested_date }}</td>
                                    <td>{{ $policy->validity_date }}</td>
                                    <td>{{ $policy->company->name }}</td>
                                    <td>{{ $policy->currency  }}</td>
                                    <td>{{ $policy->prime }}</td>
                                    <td>{{ \App\Enums\SellType::getDescription($policy->sell_type) }}</td>
                                    <td>{{ $policy->assessor->name }}</td>
                                    <td>{{ App\Enums\PolicyActiveType::getDescription($policy->active) }}</td>
                                    <td>{{ $policy->status->name }}</td>
                                    <td>{{ $policy->commission_real }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        @can('view', $policy)
                                            <a
                                                class="btn btn-secondary btn-sm"
                                                href="{{ route('policies.comments.index',$policy) }}"
                                                v-b-tooltip.hover title="Detalle de Pólizas"
                                            >
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('accidents', $policy)
                                            <a
                                                class="btn btn-secondary btn-sm"
                                                href="{{ route('policies.accidents.index', $policy) }}"
                                                v-b-tooltip.hover title="Siniestros"
                                            >
                                               <i class="fa-solid fa-car-burst"></i>
                                                {{-- <i class="fa-regular fa-brake-warning"></i> --}}
                                            </a>
                                        @endcan
                                        @can('claims', $policy)
                                            <a
                                                class="btn btn-secondary btn-sm"
                                                href="{{ route('policies.claims.index', $policy) }}"
                                                v-b-tooltip.hover title="Reclamos"
                                            >
                                                <i class="fa-solid fa-book"></i>
                                                
                                            </a>
                                        @endcan
                                        @can('update', $policy)
                                            <a
                                                class="btn btn-secondary btn-sm"
                                                href="{{ route('policies.edit',$policy) }}"
                                                v-b-tooltip.hover title="Editar"
                                            >
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @endcan
                                        @can('delete', $policy)
                                            <button
                                                class="btn btn-danger btn-sm"
                                                data-toggle="modal"
                                                data-target="#deleteModal{{ $policy->id }}"
                                                v-b-tooltip.hover title="Eliminar"
                                            >
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $policies->appends(request()->input())->links() }}
                            </div>
                            <div class="col text-right">
                                @can('create',\App\Policy::class)
                                    <a class="btn btn-primary" href="{{ route('policies.create') }}">
                                        <i class="fas fa-plus mr-2"></i>Nuevo
                                    </a>
                                @endcan
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quick Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="quickModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="quickModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="quickModalLongTitle">Cliente</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table">
                            <tr>
                                <td>Nombre</td>
                                <th>{{ $policy->customer->name }}</th>
                            </tr>
                            <tr>
                                <td>Correo electronico</td>
                                <th>{{ $policy->customer->email }}</th>
                            </tr>
                            <tr>
                                <td>Telefono</td>
                                <th>{{ $policy->customer->phone }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    <!-- Delete Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="deleteModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar la poliza?</div>
                        <table class="table">
                            <tr>
                                <td>Cliente</td>
                                <td>{{ $policy->customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Poliza ID</td>
                                <td>{{ $policy->id }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('[data-toggle="tooltip"]').tooltip();

            $('input[name="request_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="request_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('input[name="validity_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="validity_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('select[name="assessor_id"]').select2();

            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar la poliza?');
                if (!confirm) {
                    e.preventDefault();
                }
            });

            $('button.action-export').each((i, el) => {
                console.log({el});
                $(el).on('click', async (evt) => {
                    $(el).toggleClass('disabled');
                    $(el).children('svg').attr('hidden', true);
                    const loadingEl = new DOMParser().parseFromString('<span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>', 'text/html').body.childNodes[0];
                    el.prepend(loadingEl);
                    const rsp = await axios.get(el.dataset.url, { responseType: 'blob' });
                    console.log(rsp);
                    const href = URL.createObjectURL(rsp.data);
                    const link = document.createElement('a');
                    link.href = href;
                    link.setAttribute('download', rsp.headers['content-disposition'].slice(21).replaceAll('"', ''));
                    document.body.appendChild(link);
                    link.click();
                    $(el).toggleClass('disabled');
                    $(el).children('svg').removeAttr('hidden');
                    loadingEl.remove();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(href);
                });
            });
        };
    </script>
@endpush
{{-- <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> --}}