<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                <input class="form-control" disabled value="{{ $policy->code }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Teléfono del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->phone }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Email del contratante</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->email }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->assessor->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Aseguradora</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->company->name }}" />
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ramo</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->sector->name }}" />
            </div>
        </div>
        {{-- <div class="form-row form-group">
            <label class="col-4 col-form-label">Ramo</label>
            <div class="col">
                <input class="form-control-plaintext" disabled type="readonly" value="{{ $policy->customer->name }}" />
            </div>
        </div> --}}
    </div>
    <div class="col">
        {{-- <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de solicitud</label>
            <div class="col">
                {{ Form::date('requested_date', null, ['class' => 'form-control'.($errors->has('requested_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('requested_date') }}</div>
            </div>
        </div> --}}
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo</label>
            <div class="col">
                {{ Form::select('type', \App\Enums\AccidentType::toSelectArray(), null, ['class' => 'form-control'.($errors->has('type') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha del siniestro</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'happened_date', null, ['class' => 'form-control'.($errors->has('happened_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('happened_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de notificación al corredor</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'broker_notification_date', null, ['class' => 'form-control'.($errors->has('broker_notification_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('broker_notification_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de notificación al asegurador</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'insurer_notification_date', null, ['class' => 'form-control'.($errors->has('insurer_notification_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('insurer_notification_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de recepción de documentación (Sin ajustador)</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'documentation_receipt_no_adjuster_date', null, ['class' => 'form-control'.($errors->has('documentation_receipt_no_adjuster_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('documentation_receipt_no_adjuster_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de recepción de documentación (Con ajustador)</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'documentation_receipt_adjuster_date', null, ['class' => 'form-control'.($errors->has('documentation_receipt_adjuster_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('documentation_receipt_adjuster_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Descripción</label>
            <div class="col">
                {{ Form::textarea('description', null, ['class' => 'form-control'.($errors->has('description') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('description') }}</div>
            </div>
        </div>
        {{-- <div class="form-row form-group">
            <label class="col-4 col-form-label">Cliente</label>
            <div class="col">
                {{ Form::select('customer_id', dropdownData('Customers'), null, ['placeholder' => '- Nuevo Cliente -','class' => 'form-control'.($errors->has('customer_id') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('customer_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Teléfono</label>
            <div class="col">
                {{ Form::text('phone', null, ['class' => 'form-control'.($errors->has('phone') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('phone') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Correo</label>
            <div class="col">
                {{ Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('email') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Documento Identidad</label>
            <div class="col">
                <div class="row no-gutters">
                    <div class="col mr-2">
                        {{ Form::select('document_type', dropdownData('DocumentTypes'), null, ['class' => 'form-control'.($errors->has('document_type') ? ' is-invalid': null)]) }}
                        <div
                            class="invalid-feedback">{{ $errors->first('document_type') }}</div>
                    </div>
                    <div class="col">
                        {{ Form::text('document_number', null, ['class' => 'form-control'.($errors->has('document_number') ? ' is-invalid': null)]) }}
                        <div
                            class="invalid-feedback">{{ $errors->first('document_number') }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Cumpleaños</label>
            <div class="col">
                {{ Form::date('birth_date', null, ['class' => 'form-control'.($errors->has('birth_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('birth_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Dirección</label>
            <div class="col">
                {{ Form::text('address', null, ['class' => 'form-control'.($errors->has('address') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('address') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Distrito</label>
            <div class="col">
                {{ Form::text('city', null, ['class' => 'form-control'.($errors->has('city') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('city') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Provincia</label>
            <div class="col">
                {{ Form::text('province', null, ['class' => 'form-control'.($errors->has('province') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('province') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Departamento</label>
            <div class="col">
                {{ Form::text('state', null, ['class' => 'form-control'.($errors->has('state') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('state') }}</div>
            </div>
        </div>
        <hr>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comisión Morgan (Estimado)</label>
            <div class="col">
                {{ Form::text('commission_estimated', null, ['readonly'=>true,'class' => 'form-control'.($errors->has('commission_estimated') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('commission_estimated') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comisión Morgan (Real)</label>
            <div class="col">
                {{ Form::text('commission_real', null, ['class' => 'form-control'.($errors->has('commission_real') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('commission_real') }}</div>
            </div>
        </div> --}}
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Lugar</label>
            <div class="col">
                {{ Form::text('place', null, ['class' => 'form-control'.($errors->has('place') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('place') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto estimado de daños</label>
            <div class="col">
                {{ Form::text('estimated_damage_amount', null, ['id' => 'estimated_damage_amount', 'class' => 'form-control'.($errors->has('estimated_damage_amount') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('estimated_damage_amount') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha en que la aseguradora declaró consentido el siniestro</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'consent_declared_date', null, ['class' => 'form-control'.($errors->has('consent_declared_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('consent_declared_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha en que la aseguradora efectuó el pago del siniestro</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'insurer_paid_date', null, ['class' => 'form-control'.($errors->has('insurer_paid_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('insurer_paid_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Estado</label>
            <div class="col">
                {{ Form::select('state', \App\Enums\AccidentState::toSelectArray(), null, ['class' => 'form-control'.($errors->has('state') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('state') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de Resolución</label>
            <div class="col">
                {{ Form::input('dateTime-local', 'resolution_date', null, ['class' => 'form-control'.($errors->has('resolution_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('resolution_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Comentarios Adicionales</label>
            <div class="col">
                {{ Form::textarea('adicional_comments', null, ['class' => 'form-control'.($errors->has('adicional_comments') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('adicional_comments') }}</div>
            </div>
        </div>


        <div class="form-row form-group">
            <label class="col-4 col-form-label">Archivos</label>
            <div class="col">
                {{-- <div class="card">
                    <div class="card-body"> --}}
                        {{-- {{ Form::file() }} --}}
                        <files-uploader :initialfiles="{{ @$accident ? $accident->files : '[]' }}" target="accidents" mode="{{ @$accident ? "update" : "create" }}" entityid="{{ @$accident ? $accident->id : null }}"></files-uploader>
                        {{-- <files-uploader :initialfiles="{{ $accident->files ? $accident->files : [] }}" target="accidents"></files-uploader> --}}
                    {{-- </div>
                </div> --}}
                
                {{-- {{ Form::textarea('adicional_comments', null, ['class' => 'form-control'.($errors->has('adicional_comments') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('adicional_comments') }}</div> --}}
            </div>
        </div>



        {{-- <div class="form-row form-group">
            <label class="col-4 col-form-label">Status de Póliza</label>
            <div class="col">
                {{ Form::select('active', \App\Enums\PolicyActiveType::toSelectArray(), null, ['class' => 'form-control'.($errors->has('active') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('active') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de venta</label>
            <div class="col">
                {{ Form::select('sell_type', dropdownData('SellTypes'), null, ['class' => 'form-control'.($errors->has('sell_type') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('sell_type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Estado</label>
            <div class="col">
                {{ Form::select('operation_status', dropdownData('PolicyStatuses'), null, ['class' => 'form-control'.($errors->has('operation_status') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('operation_status') }}</div>
            </div>
        </div>
        <hr>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Corredor</label>
            <div class="col">
                {{ Form::select('broker_id', dropdownData('Brokers'), $policy->broker_id ?? 1, ['class' => 'form-control'.($errors->has('broker_id') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('broker_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                {{ Form::select('assessor_id', $employees, $policy->assessor_id ?? 1, ['class' => 'form-control'.($errors->has('assessor_id') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('assessor_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Compañia</label>
            <div class="col">
                {{ Form::select('company_id',$companies, null, ['class' => 'form-control'.($errors->has('company_id') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('company_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ramo</label>
            <div class="col">
                {{ Form::select('sector_id', $sectors ?? [], null, ['class' => 'form-control'.($errors->has('sector_id') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('sector_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Producto</label>
            <div class="col">
                {{ Form::hidden('commission_percentage') }}
                {{ Form::select('product_id', $products ?? [], null, ['class' => 'form-control'.($errors->has('product_id') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('product_id') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Prima neta</label>
            <div class="col">
                <div class="row no-gutters">
                    <div class="col mr-2">
                        {{ Form::select('currency', dropdownData('Currency'), null, ['class' => 'form-control'.($errors->has('currency') ? ' is-invalid': null)]) }}
                        <div class="invalid-feedback">{{ $errors->first('currency') }}</div>
                    </div>
                    <div class="col">
                        {{ Form::text('prime', null, ['class' => 'form-control'.($errors->has('prime') ? ' is-invalid': null)]) }}
                        <div class="invalid-feedback">{{ $errors->first('prime') }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Financiamiento</label>
            <div class="col">
                {{ Form::select('payment_type',dropdownData('PaymentType'), null, ['class' => 'form-control'.($errors->has('payment_type') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('payment_type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Cuotas</label>
            <div class="col">
                {{ Form::select('dues', dropdownData('Dues'), null, ['class' => 'form-control'.($errors->has('dues') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('dues') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Período de póliza</label>
            <div class="col">
                {{ Form::select('period', dropdownData('PeriodTypes'), null, ['class' => 'form-control'.($errors->has('period') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('period') }}</div>
            </div>
        </div> --}}
    </div>
    {{-- <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Póliza</label>
            <div class="col">
                {{ Form::text('code', null, ['class' => 'form-control'.($errors->has('code') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('code') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label"># tramite</label>
            <div class="col">
                {{ Form::text('procedure_number', null, ['class' => 'form-control'.($errors->has('procedure_number') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('procedure_number') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha emisión</label>
            <div class="col">
                {{ Form::date('release_date', null, ['class' => 'form-control'.($errors->has('release_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('release_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Inicio de vigencia</label>
            <div class="col">
                {{ Form::date('validity_date', null, ['class' => 'form-control'.($errors->has('validity_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('validity_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fin de vigencia</label>
            <div class="col">
                {{ Form::date('renewal_date', null, ['class' => 'form-control'.($errors->has('renewal_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('renewal_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de anulación</label>
            <div class="col">
                {{ Form::date('delivery_date', null, ['class' => 'form-control'.($errors->has('delivery_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('delivery_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Con inspección</label>
            <div class="col">
                {{ Form::select('inspection', dropdownData('YesNot'), null, ['class' => 'form-control'.($errors->has('inspection') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('inspection') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Continuidad</label>
            <div class="col">
                {{ Form::select('abidance', dropdownData('YesNot'), null, ['class' => 'form-control'.($errors->has('abidance') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('abidance') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Observaciones</label>
            <div class="col">
                {{ Form::textarea('comments', null, ['class' => 'form-control'.($errors->has('comments') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('comments') }}</div>
            </div>
        </div>
    </div> --}}
</div>
<input type="hidden" name="return" value="{{ request('return') }}">
<script>
    window.addEventListener("load", () => {
        $("input#estimated_damage_amount").on("input", function(evt) {
            if (
                $(this).val().split(".")[0].length > 6 ||
                $(this).val().split(".")[1]?.length > 2 ||
                isNaN($(this).val())
            ) {
                $(this).val($(this).val().slice(0, -1));
            }
            // if (this.value.length > this.maxLength) {
            //     this.value = this.value.slice(0, this.maxLength);
            // }
        });
    });
    // window.onload = function () {
    //     $('select[name=customer_id]').select2();
    //     $('select[name=broker_id]').select2();
    //     $('select[name=assessor_id]').select2();
    //     $('select[name=key_id]').select2();
    //     $('select[name=customer_id]').change(function () {
    //         if ($(this).val() === '') {
    //             $('#refresh').val(9);
    //         } else {
    //             $('#refresh').val(1);
    //         }

    //         $('#frm-create').submit();
    //     });

    //     // key
    //     $('select[name=company_id]').change(function () {
    //         let company_id = $(this).val();
    //         axios.get('sectors?company_id=' + company_id).then((response) => {
    //             $('select[name=sector_id]').empty();
    //             $('select[name=sector_id]').append($("<option />").val('').text('- Seleccionar -'));
    //             response.data.data.forEach(function (sector) {
    //                 $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
    //             });
    //         });
    //     });
    //     $('select[name=sector_id]').change(function () {
    //         let sector_id = $(this).val();
    //         axios.get('products?sector_id=' + sector_id).then((response) => {
    //             $('select[name=product_id]').empty();
    //             $('select[name=product_id]').append($("<option />").val('').text('- Seleccionar -'));
    //             response.data.data.forEach(function (sector) {
    //                 $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
    //                 $('input[name=commission_percentage]').val(sector.commission);
    //                 calculateCommission();
    //             });
    //         });
    //     });

    //     //
    //     $('input[name=prime]').change(function () {
    //         calculateCommission();
    //     });
    // };

    function calculateCommission() {
        let value = parseFloat($('input[name=prime]').val());
        let percentage = parseFloat($('input[name=commission_percentage]').val());
        if (percentage > 0 && value > 0) {
            let estimated = value * percentage / 100;
            $('input[name=commission_estimated]').val(estimated);
            $('input[name=commission_real]').val(estimated);
        }
    }
</script>
