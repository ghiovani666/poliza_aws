@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Siniestros</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    {{-- <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Accidentes</li>
                    </ol> --}}
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                clientes</a></li>
                        <li class="breadcrumb-item"><a
                                href="{{ route('customers.show', $policy->customer) }}">{{ $policy->customer->name }}</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.comments.index', $policy->id) }}">
                                {{ $policy->id }}
                            </a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Siniestros</li>
                    </ol>
                </nav>
                <div class="float-right">
                    @can('export',\App\Policy::class)
                        <a class="btn btn-secondary" href="{{ route('policies.accidents.export', $policy) }}" title="Descargar">
                            <i class="fas fa-file-excel"></i>
                        </a>
                    @endcan
                    @can('create',\App\Policy::class)
                        <a class="btn btn-primary" href="{{ route('policies.accidents.create', $policy) }}">
                            <i class="fas fa-plus mr-2"></i>Nuevo
                        </a>
                    @endcan
                </div>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        {{-- <div class="mb-2">
                            {{ Form::open(['url' => route('policies.index'), 'method' => 'GET']) }}

                            <div class="mb-2">
                                <div class="d-inline-block mr-2" title="Contratante" style="width: 160px">
                                    {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'placeholder' => 'Contratante', 'style' => 'width: 100%;']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de documento" style="width: 160px">
                                    {{ Form::text('document', request('document'), ['class' => 'form-control', 'placeholder' => 'Numero de documento', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Numero de poliza" style="width: 160px">
                                    {{ Form::text('code', request('code'), ['class' => 'form-control', 'placeholder' => 'Numero de accidente', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Status de accidente" style="width: 160px">
                                    {{ Form::select('active', \App\Enums\PolicyActiveType::toSelectArray(), request('active'), ['class' => 'form-control', 'style' => '100%', 'placeholder' => '- Status de poliza -']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Estado" style="width: 160px">
                                    {{ Form::select('status_id', dropdownData('PolicyStatuses'), request('status_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Estado -']) }}
                                </div>

                            </div>

                            <div>
                                <div class="d-inline-block mr-2" title="Fecha de solicitud" style="width: 160px">
                                    {{ Form::text('request_date', request('request_date'), ['class' => 'form-control', 'placeholder' => 'Fecha de solicitud', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Fecha de vigencia" style="width: 160px">
                                    {{ Form::text('validity_date', request('validity_date'), ['class' => 'form-control', 'placeholder' => 'Inicio de vigencia', 'style' => 'width: 100%']) }}
                                </div>

                                <div class="d-inline-block mr-2" title="Asesor" style="width: 160px">
                                    {{ Form::select('assessor_id', dropdownData('Employees'), request('assessor_id'), ['class' => 'form-control', 'style' => 'width: 100%', 'placeholder' => '- Asesor -']) }}
                                </div>

                                <button class="btn btn-primary ml-2">Buscar</button>
                                <a href="/policies" class="btn btn-secondary">Resetear</a>
                            </div>

                            {{ Form::close() }}
                        </div> --}}
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                {{-- <th>Poliza</th> --}}
                                <th>Tipo</th>
                                <th>Fecha ocurrido</th>
                                <th>Fecha de notificación corredor</th>
                                <th>Fecha de notificación aseguradora</th>
                                <th>Fecha de recepción documentación (Sin ajustador)</th>
                                <th>Fecha de recepción documentación (Con ajustador)</th>
                                {{-- <th>Descripción</th> --}}
                                <th>Lugar</th>
                                <th>Monto estimado de daños</th>
                                <th>Fecha declarado consentido</th>
                                <th>Fecha del pago</th>
                                <th>Estado</th>
                                <th>Fecha de resolución</th>
                                {{-- <th>Comentarios adicionales</th> --}}
                                {{-- <th>Documentos adjuntos</th> --}}
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($accidents as $accident)
                                <tr>
                                    <td>{{ $accident->id }}</td>
                                    <td>{{ App\Enums\AccidentType::getDescription($accident->type) }}</td>
                                    <td>{{ $accident->happened_date }}</td>
                                    <td>{{ $accident->broker_notification_date }}</td>
                                    <td>{{ $accident->insurer_notification_date }}</td>
                                    <td>{{ $accident->documentation_receipt_no_adjuster_date }}</td>
                                    <td>{{ $accident->documentation_receipt_adjuster_date  }}</td>
                                    {{-- <td>{{ $accident->description }}</td> --}}
                                    <td>{{ $accident->place }}</td>
                                    <td>{{ $accident->estimated_damage_amount }}</td>
                                    <td>{{ $accident->consent_declared_date }}</td>
                                    <td>{{ $accident->insurer_paid_date }}</td>
                                    <td>{{ App\Enums\AccidentState::getDescription($accident->state) }}</td>
                                    <td>{{ $accident->resolution_date }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        {{-- @can('view', $accident)
                                            <a class="btn btn-secondary btn-sm"
                                               href="{{ route('policies.comments.index',$accident) }}">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        @endcan --}}
                                        @can('update', $accident)
                                            <a class="btn btn-secondary btn-sm"
                                               href="{{ route('policies.accidents.edit', [$policy, $accident]) }}">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @endcan
                                        @can('delete', $accident)
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $accident->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endcan
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="14">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $accidents->appends(request()->input())->links() }}
                            </div>
                            <div class="col text-right">
                                @can('create',\App\Policy::class)
                                    <a class="btn btn-primary" href="{{ route('policies.accidents.create', $policy) }}">
                                        <i class="fas fa-plus mr-2"></i>Nuevo
                                    </a>
                                @endcan
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($accidents as $accident)
        <div class="modal fade" id="deleteModal{{$accident->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar el siniestro?</div>
                        <table class="table">
                            {{-- <tr>
                                <td>Cliente</td>
                                <td>{{ $accident->customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Poliza ID</td>
                                <td>{{ $accident->id }}</td>
                            </tr> --}}
                            <tr>
                                <td>Siniestro ID</td>
                                <td>{{ $accident->id }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.accidents.destroy', [$policy, $accident]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('[data-toggle="tooltip"]').tooltip();

            $('input[name="request_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="request_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('input[name="validity_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="validity_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('select[name="assessor_id"]').select2();

            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar el siniestro?');
                if (!confirm) {
                    e.preventDefault();
                }
            })
        };
    </script>
@endpush
