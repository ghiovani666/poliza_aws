<div class="row">
    <div class="col">
        <table class="table table-borderless table-hover" style="border-right: 1px solid #cccccc">
            <tr>
                <td class="w-50">Fecha de solicitud</td>
                <th>{{ $policy->requested_date }}</th>
            </tr>
            <tr>
                <td>Contratante</td>
                <th>{{ $policy->customer->name }}</th>
            </tr>
            <tr>
                <td>Teléfono</td>
                <th>{{ $policy->customer->phone }}</th>
            </tr>
            <tr>
                <td>Correo</td>
                <th>{{ $policy->customer->email }}</th>
            </tr>
            <tr>
                <td>Tipo de documento de identidad</td>
                <th>{{ \App\Enums\DocumentType::getDescription($policy->customer->document_type) }}</th>
            </tr>
            <tr>
                <td>Numero de documento de identidad</td>
                <th>{{ $policy->customer->document_number }}</th>
            </tr>
            <tr>
                <td>Cumpleaños</td>
                <th>{{  $policy->customer->birthDateString }}</th>
            </tr>
            <tr>
                <td>Dirección</td>
                <th>{{ $policy->customer->address }}</th>
            </tr>
            <tr>
                <td>Distrito</td>
                <th>{{ $policy->customer->city }}</th>
            </tr>
            <tr>
                <td>Provincia</td>
                <th>{{ $policy->customer->province }}</th>
            </tr>
            <tr>
                <td>Departamento</td>
                <th>{{ $policy->customer->state }}</th>
            </tr>
            @can('see-commissions',$policy)
                <tr>
                    <td>Comisión Morgan (Estimado)</td>
                    <th>{{ $policy->commission_estimated }}</th>
                </tr>
                <tr>
                    <td>Comisión de Intermediación</td>
                    <th>{{ $policy->commission_real }}</th>
                </tr>
            @endcan
        </table>
    </div>
    <div class="col">
        <table class="table table-borderless table-hover" style="border-right: 1px solid #cccccc">
            <tr>
                <td class="w-50">Status de Póliza</td>
                <th>{{ $policy->activeName }}</th>
            </tr>
            <tr>
                <td>Tipo de venta</td>
                <th>{{ App\Enums\SellType::getDescription($policy->sell_type) }}</th>
            </tr>
            <tr>
                <td>Estado</td>
                <th>{{ $policy->status->name }}</th>
            </tr>
            <tr>
                <td>Corredor</td>
                <th>{{ $policy->broker->name }}</th>
            </tr>
            <tr>
                <td>Asesor</td>
                <th>{{ $policy->assessor->name }}</th>
            </tr>
            <tr>
                <td>Compañia</td>
                <th>{{ $policy->company->name }}</th>
            </tr>
            <tr>
                <td>Ramo</td>
                <th>{{ $policy->sector->name }}</th>
            </tr>
            <tr>
                <td>Producto</td>
                <th>{{ $policy->product->name }}</th>
            </tr>
            <tr>
                <td>Prima neta</td>
                <th>{{ $policy->currency }} {{ $policy->prime }}</th>
            </tr>
            <tr>
                <td>Financiamiento</td>
                <th>{{ \App\Enums\PaymentType::getDescription($policy->payment_type) }}</th>
            </tr>
            <tr>
                <td>Cuotas</td>
                <th>{{ $policy->dues }}</th>
            </tr>
            <tr>
                <td>Período de póliza</td>
                <th>{{ \App\Enums\PeriodType::getDescription($policy->period) }}</th>
            </tr>
        </table>
    </div>
    <div class="col">
        <table class="table table-borderless table-hover" style="border-right: 0px solid #cccccc">
            <tr>
                <td class="w-50">Póliza</td>
                <th>{{ $policy->code }}</th>
            </tr>
            <tr>
                <td># tramite</td>
                <th>{{ $policy->procedure_number }}</th>
            </tr>
            <tr>
                <td>Fecha emisión</td>
                <th>{{ $policy->release_date }}</th>
            </tr>
            <tr>
                <td>Mes de vigencia</td>
                <th>{{ $policy->validity_month }}</th>
            </tr>
            <tr>
                <td>Inicio de vigencia</td>
                <th>{{ $policy->validity_date }}</th>
            </tr>
            <tr>
                <td>Fin de vigencia/renovación</td>
                <th>{{ $policy->renewal_date }}</th>
            </tr>
            <tr>
                <td>Fecha de anulación</td>
                <th>{{ $policy->delivery_date }}</th>
            </tr>
            <tr>
                <td>Con inspección</td>
                <th>{{ $policy->inspectionAnswer }}</th>
            </tr>
            <tr>
                <td>Continuidad</td>
                <th>{{ $policy->abidanceAnswer }}</th>
            </tr>
            <tr>
                <td>Fecha de entrega</td>
                <th>{{ $policy->deadline }}</th>
            </tr>
            <tr>
                <td>Monto asegurado</td>
                <th>{{ $policy->insured_amount }}</th>
            </tr>
            <tr>
                <td>Fecha de documentación aseguradora</td>
                <th>{{ $policy->insurer_docs_date }}</th>
            </tr>
            <tr>
                <td>Fecha de documentación ajustador</td>
                <th>{{ $policy->adjuster_docs_date }}</th>
            </tr>
            <tr>
                <td>Estado de pago</td>
                <th>{{ \App\Enums\PolicyPaymentStatus::getDescription($policy->payment_status) }}</th>
            </tr>
            <tr>
                <td>Observaciones</td>
                <th>{{ $policy->comments }}</th>
            </tr>
        </table>
    </div>
</div>
