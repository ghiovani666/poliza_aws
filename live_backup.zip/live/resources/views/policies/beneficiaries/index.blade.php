@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Beneficiarios</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        <div class="text-right mb-2">
                            @can('import', \App\PolicyBeneficiary::class)
                                <button class="btn btn-primary" data-toggle="modal" data-target="#importModal">
                                    <i class="fas fa-upload mr-2"></i> Importar
                                </button>
                            @endcan
                            @can('create', \App\PolicyBeneficiary::class)
                                <a class="btn btn-primary"
                                   href="{{ route('policies.beneficiaries.create',$policy).'#beneficiaries' }}">
                                    <i class="fas fa-plus mr-2"></i>Nuevo
                                </a>
                            @endcan
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Tipo Documento</th>
                                <th>Numero Documento</th>
                                <th>Fecha de nacmiento</th>
                                <th>Beneficio (%)</th>
                                <th>F. Registro</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($beneficiaries as $beneficiary)
                                <tr>
                                    <td>{{ $beneficiary->id }}</td>
                                    <td>{{ $beneficiary->name }}</td>
                                    <td>{{ \App\Enums\DocumentType::getDescription($beneficiary->document_type) }}</td>
                                    <td>{{ $beneficiary->document_number }}</td>
                                    <td>{{ $beneficiary->birth_date }}</td>
                                    <td>{{ $beneficiary->percentage }}</td>
                                    <td>{{ $beneficiary->created_at->tz('America/Lima') }}</td>
                                    <td class="text-right">
                                        @if ($policy->status->editable)
                                            <a href="{{ route('policies.beneficiaries.edit', [$policy, $beneficiary]).'#beneficiaries' }}"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $beneficiary->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $beneficiaries->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('policies.beneficiaries.import', $policy), 'files' => true]) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Importar Registros</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">Descarga la siguiente <a
                            href="{{ asset('MorganPlantillaBeneficiarios.csv') }}">plantilla</a>, llena los campos y
                        sube
                        el archivo para ser importado.
                    </div>
                    <div class="text-center mt-3">
                        <input type="file" name="file">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($beneficiaries as $beneficiary)
        <div class="modal fade" id="deleteModal{{$beneficiary->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el beneficiario?</div>
                        <table class="table">
                            <tr>
                                <td style="width: 150px">ID</td>
                                <th>{{ $beneficiary->id }}</th>
                            </tr>
                            <tr>
                                <td>Nombre</td>
                                <th>{{ $beneficiary->name }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.beneficiaries.destroy', [$policy, $beneficiary]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
