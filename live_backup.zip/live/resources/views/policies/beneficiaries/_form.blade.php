<div class="row">
    <div class="col-6">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de documento</label>
            <div class="col">
                {{ Form::select('document_type', dropdownData('DocumentTypes'), null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Documento de identidad</label>
            <div class="col">
                {{ Form::text('document_number', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de nacimiento</label>
            <div class="col">
                {{ Form::date('birth_date', null, ['class' => 'form-control'.($errors->has('birth_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('birth_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Porcentaje de beneficio</label>
            <div class="col">
                {{ Form::number('percentage', null, ['class' => 'form-control'.($errors->has('percentage') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('percentage') }}</div>
            </div>
        </div>
    </div>
    <div class="col-6"></div>
</div>
