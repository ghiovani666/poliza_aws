<div class="row">
    <div class="col-6">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Nombre</label>
            <div class="col">
                {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de documento</label>
            <div class="col">
                {{ Form::select('document_type', \App\Enums\DocumentType::toSelectArray(), null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Documento de identidad</label>
            <div class="col">
                {{ Form::text('document_number', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Fecha de nacimiento</label>
            <div class="col">
                {{ Form::date('birth_date', null, ['class' => 'form-control'.($errors->has('birth_date') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('birth_date') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">EPS</label>
            <div class="col">
                {{ Form::select('with_eps', dropdownData('YesNot'), (isset($insurance) ? null : 0), ['class' => 'form-control'.($errors->has('with_eps') ? ' is-invalid': null)]) }}
                <div class="invalid-feedback">{{ $errors->first('with_eps') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo EPS</label>
            <div class="col">
                {{ Form::select('eps_type', \App\Enums\EPSType::toSelectArray(), null, ['class' => 'form-control'.($errors->has('eps_type') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('eps_type') }}</div>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Endoso</label>
            <div class="col">
                {{ Form::select('endorsement', dropdownData('YesNot'), null, ['class' => 'form-control'.($errors->has('endorsement') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('endorsement') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo</label>
            <div class="col">
                {{ Form::select('endorsement_type', [
                    1 => 'Inclusion',
                    0 => 'Exclusion',
                ], null, ['class' => 'form-control'.($errors->has('endorsement_type') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                <div class="invalid-feedback">{{ $errors->first('endorsement_type') }}</div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto</label>
            <div class="col">
                <div class="row no-gutters">
                    <div class="col-2">
                        {{ Form::select('endorsement_operator', [
                            '+' => '+',
                            '-' => '-',
                        ], null, ['class' => 'form-control'.($errors->has('endorsement_operator') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                        <div class="invalid-feedback">{{ $errors->first('endorsement_operator') }}</div>
                    </div>
                    <div class="col">
                        {{ Form::text('endorsement_amount', null, ['class' => 'form-control'.($errors->has('endorsement_amount') ? ' is-invalid': null)]) }}
                        <div class="invalid-feedback">{{ $errors->first('endorsement_amount') }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=with_eps]').change(function () {
                checkEps();
            });

            $('select[name=endorsement]').change(function () {
                checkEndorsement();
            });

            checkEps();
            checkEndorsement();
        };

        function checkEps() {
            let eps = $('select[name=with_eps]').val();
            if (parseInt(eps)) {
                $('select[name=eps_type]').removeAttr('disabled');
            } else {
                $('select[name=eps_type]').attr('disabled', 'disabled');
            }
        }

        function checkEndorsement() {
            let endorsement = $('select[name=endorsement]').val();
            if (parseInt(endorsement)) {
                $('select[name=endorsement_type]').removeAttr('disabled');
                $('select[name=endorsement_operator]').removeAttr('disabled');
                $('input[name=endorsement_amount]').removeAttr('disabled');
            } else {
                $('select[name=endorsement_type]').attr('disabled', 'disabled');
                $('select[name=endorsement_operator]').attr('disabled', 'disabled');
                $('input[name=endorsement_amount]').attr('disabled', 'disabled');
            }
        }
    </script>
@endpush
