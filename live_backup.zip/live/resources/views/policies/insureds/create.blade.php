@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Carteda de clientes</a></li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.show',$policy) }}">{{ $policy->id }}</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('policies.insureds.index',$policy) }}">Asegurados</a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        {{ Form::open(['url' => route('policies.insureds.store', [$policy]), 'method' => 'POST']) }}
                        @include('policies.insureds._form')
                        <hr>
                        <div class="row">
                            <div class="col">
                                <a href="{{ route('policies.insureds.index', $policy) }}#insureds"
                                   class="btn btn-secondary">Volver</a>
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
