@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col">
                        <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                        <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('policies.index') }}">Cartera de
                                        clientes</a></li>
                                <li class="breadcrumb-item"><a
                                        href="{{ route('customers.show',$policy->customer) }}">{{ $policy->customer->name }}</a>
                                </li>
                                <li aria-current="page" class="breadcrumb-item active">Asegurados</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col text-right">
                        @include('policies._nav-secondary')
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        @include('policies._detail')

                        @include('policies._tabs')

                        @include('flash::message')

                        <div class="text-right mb-2">
                            @can('import', \App\PolicyInsured::class)
                                <button class="btn btn-primary" data-toggle="modal" data-target="#importModal">
                                    <i class="fas fa-upload mr-2"></i> Importar
                                </button>
                            @endcan
                            @can('create', \App\PolicyInsured::class)
                                <a class="btn btn-primary"
                                   href="{{ route('policies.insureds.create',$policy) }}#insureds">
                                    <i class="fas fa-plus mr-2"></i>Nuevo</a>
                            @endcan
                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Tipo Documento</th>
                                <th>Numero Documento</th>
                                <th>Fecha de nacmiento</th>
                                <th>EPS</th>
                                <th>Tipo EPS</th>
                                <th>F. Registro</th>
                                <th>Estado</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($insureds as $insured)
                                <tr>
                                    <td>{{ $insured->id }}</td>
                                    <td>{{ $insured->name }}</td>
                                    <td>{{ \App\Enums\DocumentType::getDescription($insured->document_type) }}</td>
                                    <td>{{ $insured->document_number }}</td>
                                    <td>{{ $insured->birth_date }}</td>
                                    <td>{{ $insured->with_eps ? 'Si' : 'No' }}</td>
                                    <td>{{ \App\Enums\EPSType::getDescription($insured->eps_type) }}</td>
                                    <td>{{ $insured->created_at }}</td>
                                    <td>{{ $insured->enabled ? 'Activo' : 'Eliminado' }}</td>
                                    <td class="text-right">
                                        @if ($policy->status->editable)
                                            <a href="{{ route('policies.insureds.edit', [$policy, $insured]) }}#insureds"
                                               class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal{{ $insured->id }}">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $insureds->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                {{ Form::open(['url' => route('policies.insureds.import', $policy), 'files' => true]) }}
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Importar Registros</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">Descarga la siguiente <a
                            href="{{ asset('MorganPlantillaAsegurados.csv') }}">plantilla</a>, llena los campos y sube
                        el archivo para ser importado.
                    </div>
                    <div class="text-center mt-3">
                        <input type="file" name="file">
                    </div>
                    <hr>
                    <div class="text-center">Valores EPS (usar ID's para importar)</div>
                    <table class="table table-borderless table-sm w-50">
                        <tr>
                            <th>EPS</th>
                            <th>ID</th>
                        </tr>
                        <tr>
                            <td>Base</td>
                            <th>{{ \App\Enums\EPSType::BASE }}</th>
                        </tr>
                        <tr>
                            <td>Adicional 1</td>
                            <th>{{ \App\Enums\EPSType::ADITIONAL1 }}</th>
                        </tr>
                        <tr>
                            <td>Adicional 2</td>
                            <th>{{ \App\Enums\EPSType::ADITIONAL2 }}</th>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Importar</button>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($insureds as $insured)
        <div class="modal fade" id="deleteModal{{$insured->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    {{ Form::open(['url' => route('policies.insureds.destroy', [$policy, $insured]), 'method' => 'DELETE']) }}
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el asegurado?</div>
                        <table class="table">
                            <tr>
                                <td style="width: 150px">ID</td>
                                <th>{{ $insured->id }}</th>
                            </tr>
                            <tr>
                                <td>Nombre</td>
                                <th>{{ $insured->name }}</th>
                            </tr>
                            <tr>
                                <td>Numero Documento</td>
                                <th>{{ $insured->document_number }}</th>
                            </tr>
                        </table>
                        <div class="mt-3">
                            <div class="form-row form-group">
                                <label class="col-4 col-form-label">Endoso</label>
                                <div class="col">
                                    {{ Form::select('endorsement', dropdownData('YesNot'), null, ['class' => 'form-control'.($errors->has('endorsement') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                                    <div class="invalid-feedback">{{ $errors->first('endorsement') }}</div>
                                </div>
                            </div>
                            <div class="form-row form-group">
                                <label class="col-4 col-form-label">Tipo</label>
                                <div class="col">
                                    {{ Form::select('endorsement_type', [
                                        1 => 'Inclusion',
                                        0 => 'Exclusion',
                                    ], null, ['class' => 'form-control'.($errors->has('endorsement_type') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                                    <div class="invalid-feedback">{{ $errors->first('endorsement_type') }}</div>
                                </div>
                            </div>
                            <div class="form-row form-group">
                                <label class="col-4 col-form-label">Monto</label>
                                <div class="col">
                                    <div class="row no-gutters">
                                        <div class="col-2">
                                            {{ Form::select('endorsement_operator', [
                                                '+' => '+',
                                                '-' => '-',
                                            ], null, ['class' => 'form-control'.($errors->has('endorsement_operator') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -']) }}
                                            <div
                                                class="invalid-feedback">{{ $errors->first('endorsement_operator') }}</div>
                                        </div>
                                        <div class="col">
                                            {{ Form::text('endorsement_amount', null, ['class' => 'form-control'.($errors->has('endorsement_amount') ? ' is-invalid': null)]) }}
                                            <div
                                                class="invalid-feedback">{{ $errors->first('endorsement_amount') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    @endforeach
@endsection
