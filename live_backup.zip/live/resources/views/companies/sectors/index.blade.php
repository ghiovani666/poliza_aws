@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">KEYS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('companies.index',[$company]) }}">Compañias</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Ramos</li>
                    </ol>
                </nav>
                <div class="float-right">
                    <a class="btn btn-primary" href="{{ route('companies.sectors.create', $company) }}">
                        <i class="fas fa-plus mr-2"></i>Nuevo</a>
                </div>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Compañia</th>
                                <th>Ramo</th>
                                <th>Productos (#)</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($sectors as $sector)
                                <tr>
                                    <td>{{ $sector->id }}</td>
                                    <td>{{ $sector->company->name }}</td>
                                    <td>{{ $sector->name }}</td>
                                    <td>{{ $sector->products_count }}</td>
                                    <td class="text-right">
                                        <a href="{{ route('companies.sectors.products.index', [$company, $sector]) }}"
                                           class="btn btn-secondary btn-sm"><i class="fas fa-eye"></i></a>
                                        <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                data-target="#deleteModal{{ $sector->id }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $sectors->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($sectors as $sector)
        <div class="modal fade" id="deleteModal{{$sector->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar la rama?</div>
                        <table class="table">
                            <tr>
                                <td>Empresa</td>
                                <td>{{ $company->name }}</td>
                            </tr>
                            <tr>
                                <td>Sector</td>
                                <td>{{ $sector->name }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('companies.sectors.destroy', [$company, $sector]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
