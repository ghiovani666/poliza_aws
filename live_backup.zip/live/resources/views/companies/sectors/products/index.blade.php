@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">KEYS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('companies.index',[$company]) }}">Compañias</a></li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('companies.sectors.index',[$company]) }}">Ramos</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Productos</li>
                    </ol>
                </nav>
                <div class="float-right">
                    <a class="btn btn-primary"
                       href="{{ route('companies.sectors.products.create', [$company, $sector]) }}"><i
                            class="fas fa-plus mr-2"></i>Nuevo</a>
                </div>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Compañia</th>
                                <th>Ramo</th>
                                <th>Producto</th>
                                <th>Comision</th>
                                <th># Polizas</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($products as $product)
                                <tr>
                                    <td>{{ $product->id }}</td>
                                    <td>{{ $company->name }}</td>
                                    <td>{{ $sector->name }}</td>
                                    <td>{{ $product->name }}</td>
                                    <td>{{ $product->commission }}</td>
                                    <td>{{ $product->policies()->count() }}</td>
                                    <td class="text-right">
                                        <a href="{{ route('companies.sectors.products.edit', [$company, $sector, $product]) }}"
                                           class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                data-target="#deleteModal{{ $product->id }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $products->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    @foreach($products as $product)
        <div class="modal fade" id="deleteModal{{$product->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar el producto?</div>
                        <table class="table">
                            <tr>
                                <td>Empresa</td>
                                <td>{{ $company->name }}</td>
                            </tr>
                            <tr>
                                <td>Sector</td>
                                <td>{{ $sector->name }}</td>
                            </tr>
                            <tr>
                                <td>Producto</td>
                                <td>{{ $product->name }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('companies.sectors.products.destroy', [$company, $sector, $product]), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
