    @extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">KEYS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('companies.index') }}">Compañias</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['url' => route('companies.store')]) }}
                        <div class="row">
                            <div class="col-6">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Nombre</label>
                                    <div class="col">
                                        {{ Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)]) }}
                                        <div class="invalid-feedback">{{ $errors->first('name') }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
