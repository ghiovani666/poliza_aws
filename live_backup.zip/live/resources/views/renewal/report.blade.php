@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Reporte</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item active">Post-venta</li>
                        <li aria-current="page" class="breadcrumb-item active">Reporte</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {!! str_replace('<iframe','<iframe width="100%" height="600px" style="border:none;" ',$setting->value) !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
