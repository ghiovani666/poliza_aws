@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Renovacion</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Post-venta</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        @include('flash::message')
                        {{ Form::open(['url' => route('renewal.index'), 'method' => 'GET']) }}
                        <div class="row mb-2">

                            <div class="col">
                                {{ Form::text('customer', request('customer'), ['class' => 'form-control', 'placeholder' => 'Contratante']) }}
                            </div>

                            <div class="col">
                                {{ Form::text('document_number', request('document_number'), ['class' => 'form-control', 'placeholder' => 'DNI']) }}
                            </div>

                            <div class="col">
                                {{ Form::text('code', request('code'), ['class' => 'form-control', 'placeholder' => 'Numero de poliza']) }}
                            </div>

                            <div class="col">
                                {{ Form::text('validity_date', request('validity_date'), ['class' => 'form-control', 'placeholder' => 'Inicio de vigencia']) }}
                            </div>

                            <div class="col">
                                {{ Form::select('assessor_id', dropdownData('Employees'), request('assessor_id'), ['class' => 'form-control', 'placeholder' => '- Asesor -']) }}
                            </div>

                            <div class="col">
                                {{ Form::select('wish_renewal', [1=>'Si', 0=>'No'], request('wish_renewal'), ['class' => 'form-control', 'placeholder' => '- Renovacion -']) }}
                            </div>

                            <div class="col">
                                <button class="btn btn-primary">Buscar</button>
                                <a href="/renewal" class="btn btn-secondary">Resetear</a>
                            </div>
                        </div>
                        {{ Form::close() }}
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Contratante</th>
                                <th>Poliza</th>
                                <th>Inicio de vigencia</th>
                                <th>Compañia</th>
                                <th>Moneda</th>
                                <th>Prima Neta</th>
                                <th>Tipo de venta</th>
                                <th>Asesor</th>
                                <th>Status</th>
                                <th>Renovacion</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($policies as $policy)
                                <tr>
                                    <td>{{ $policy->id }}</td>
                                    <td>
                                        {{ $policy->customer->name }}
                                        <div class="d-inline" data-toggle="modal"
                                             data-target="#quickModal{{ $policy->id }}"
                                             style="cursor: pointer; color: blue">
                                            <i class="fas fa-eye"></i>
                                        </div>
                                    </td>
                                    <td>{{ $policy->code }}</td>
                                    <td>{{ $policy->validity_date }}</td>
                                    <td>{{ $policy->id }}</td>
                                    <td>{{ $policy->currency }}</td>
                                    <td>{{ $policy->prime }}</td>
                                    <td>{{ \App\Enums\SellType::getDescription($policy->sell_type) }}</td>
                                    <td>{{ $policy->assessor->name }}</td>
                                    <td>{{ $policy->status->name }}</td>
                                    <td>{{ $policy->renewalAnswer }}</td>
                                    <td class="text-right" style="white-space: nowrap;">
                                        <a class="btn btn-secondary btn-sm"
                                           href="{{ route('renewal.show',$policy) }}">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-center" colspan="12">No se encontraron registros.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col">
                                {{ $policies->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quick Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="quickModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="quickModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="quickModalLongTitle">Cliente</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table">
                            <tr>
                                <td>Nombre</td>
                                <th>{{ $policy->customer->name }}</th>
                            </tr>
                            <tr>
                                <td>Correo electronico</td>
                                <th>{{ $policy->customer->email }}</th>
                            </tr>
                            <tr>
                                <td>Telefono</td>
                                <th>{{ $policy->customer->phone }}</th>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    <!-- Delete Modal -->
    @foreach($policies as $policy)
        <div class="modal fade" id="deleteModal{{$policy->id}}" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center">¿Seguro que desea eliminar la poliza?</div>
                        <table class="table">
                            <tr>
                                <td>Cliente</td>
                                <td>{{ $policy->customer->name }}</td>
                            </tr>
                            <tr>
                                <td>Poliza ID</td>
                                <td>{{ $policy->id }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="modal-footer">
                        {{ Form::open(['url' => route('policies.destroy', $policy), 'method' => 'DELETE']) }}
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
@push('scripts')
    <script type="text/javascript">
        window.onload = function () {
            $('[data-toggle="tooltip"]').tooltip();

            $('input[name="validity_date"]').daterangepicker(window.dateRangePickerSettings, function (start, end, label) {
                $('input[name="validity_date"]').val(start.format('DD/MM/YYYY') + ' a ' + end.format('DD/MM/YYYY'));
            });

            $('select[name="assessor_id"]').select2();

            $('.form-delete').submit(function (e) {
                let confirm = window.confirm('¿Seguro que desea eliminar la poliza?');
                if (!confirm) {
                    e.preventDefault();
                }
            })
        };
    </script>
@endpush
