@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="h2 d-inline-block text-uppercase">Renovacion</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('renewal.index') }}">Post-venta</a></li>
                        <li aria-current="page" class="breadcrumb-item active">{{ $policy->customer->name }}</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        {{ Form::model($policy, ['url' => route('renewal.update', $policy), 'method' => 'PUT']) }}
                        <div class="row">
                            <div class="col">
                                <table class="table table-sm table-hover">
                                    <tr>
                                        <td width="50%">Compañia</td>
                                        <td>{{ $policy->company->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Contratante</td>
                                        <td>{{ $policy->customer->name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Telefono</td>
                                        <td>{{ $policy->customer->phone }}</td>
                                    </tr>
                                    <tr>
                                        <td>Correo</td>
                                        <td>{{ $policy->customer->email }}</td>
                                    </tr>
                                    <tr>
                                        <td>Poliza</td>
                                        <td>{{ $policy->code }}</td>
                                    </tr>
                                    <tr>
                                        <td>Prima neta</td>
                                        <td>{{ $policy->prime }}</td>
                                    </tr>
                                    <tr>
                                        <td>Fin de vigencia</td>
                                        <td>{{ $policy->validityEndDate }}</td>
                                    </tr>
                                    <tr>
                                        <td>Modalidad de cobro</td>
                                        <td>{{ $policy->paymentMethod }}</td>
                                    </tr>
                                    <tr>
                                        <td>Asesor</td>
                                        <td>{{ $policy->assessor->name }}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col" style="border-left: 1px solid #cccccc">
                                <div class="form-group form-row">
                                    <div class="col">
                                        Desea renovar
                                    </div>
                                    <div class="col">
                                        <label class="mr-2">
                                            {!! Form::radio('wish_renewal', '1', null,  []) !!} Si
                                        </label>
                                        <label>
                                            {!! Form::radio('wish_renewal', '0', null,  []) !!} No
                                        </label>
                                        <label>
                                            {!! Form::radio('wish_renewal', '2', null,  []) !!} No Contactado
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group form-row">
                                    <div class="col">PDF de poliza</div>
                                    <div class="col">
                                        @if($policy->hasPolicyFile)
                                            <a href="{{ $policy->policyFileUrl }}">Descargar</a>
                                        @else
                                            No se encontro archivo.
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group form-row">
                                    <div class="col">Documentos del cliente</div>
                                    <div class="col">
                                        @foreach(documents() as $document)
                                            <div><a target="_blank"
                                                    href="{{ $document->fileUrl }}">{{ $document->name }}</a></div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="form-group form-row">
                                    <div class="col">Observaciones</div>
                                </div>
                                <div class="form-group form-row">
                                    {{ Form::textarea('comments', null, ['class' => 'form-control']) }}
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col text-left">
                                @can('view',$policy)
                                    <a class="btn btn-secondary"
                                       href="{{ route('policies.documents.index', [$policy, 'return' => 'renewal']) }}">
                                        Ver Poliza</a>
                                @endcan
                                @can('update',$policy)
                                    <a class="btn btn-secondary"
                                       href="{{ route('policies.edit', [$policy, 'return' => 'renewal']) }}">
                                        Modificar Poliza</a>
                                @endcan
                            </div>
                            <div class="col text-right">
                                @can('renewal-update', $policy)
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                @endcan
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
