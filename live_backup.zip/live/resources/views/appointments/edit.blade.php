@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('appointments.index') }}">Citas</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Modificar</li>
                    </ol>
                </nav>
                {{ Form::model($appointment, ['url' => route('appointments.update', $appointment), 'method' => 'PUT']) }}
                <div class="card">
                    <div class="card-header">Modificar Cita</div>
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <div class="form-group row">
                            <div class="col">
                                {{ Form::label('date','Fecha')  }}
                                {{ Form::date('date', null, ['class' => 'form-control']) }}
                            </div>
                            <div class="col">
                                {{ Form::label('hours','Hora')  }}
                                {{ Form::time('hours', null, ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                {{ Form::label('subject','Asunto')  }}
                                {{ Form::text('subject', null, ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                {{ Form::label('comment','Comentario')  }}
                                {{ Form::textarea('comment', null, ['class' => 'form-control']) }}
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="{{ route('appointments.index') }}" class="btn btn-secondary">Volver</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
@endsection
