@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <calendar></calendar>
            </div>
        </div>
    </div>
@endsection
