@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('appointments.index') }}">Citas</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Detalle</li>
                    </ol>
                </nav>
                {{ Form::open(['url' => route('appointments.store'), 'method' => 'POST']) }}
                <div class="card">
                    <div class="card-header">Detalle Cita</div>
                    <div class="card-body">
                        <div class="form-group row">
                            <div class="col">
                                <small class="text-muted">Fecha</small>
                                <div>{{ $appointment->date }}</div>
                            </div>
                            <div class="col">
                                <small class="text-muted">Hora</small>
                                <div>{{ $appointment->hours }}</div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <small class="text-muted">Asunto</small>
                                <div>{{ $appointment->subject }}</div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <small class="text-muted">Comentario</small>
                                <div>{{ $appointment->comment }}</div>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <a href="{{ route('appointments.index') }}" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </div>
@endsection
