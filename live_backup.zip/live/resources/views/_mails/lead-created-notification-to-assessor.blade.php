@component('mail::message')
# Hola {{ $name }},

Reporte de nuevo lead creado:

Asesor: {{ $lead->assessor->name }}

Fecha: {{ date('d/m/Y H:i') }}

@component('mail::button', ['url' => asset(route('leads.show', $lead))])
Ver en la intranet
@endcomponent

@component('mail::table')
| Campo        | Valor                                                           |
|:-------------|:----------------------------------------------------------------|
| ID           | {{ $lead->id }}                                                 |
| Nombre       | {{ $lead->name }}                                               |
| Telefono     | {{ $lead->phone }}                                              |
| Email        | {{ $lead->email }}                                              |
| Dcoumento    | {{ $lead->document_number }}                                    |
| Origen       | {{ \App\Enums\LeadSource::getDescription($lead->source_id) }}   |
| Descripcion  | {{ $lead->description }}                                        |
| Etapa        | {{ \App\Enums\LeadStage::getDescription($lead->stage_id) }}     |
| Importe      | {{$lead->currency }} {{ $lead->amount }}                        |
| Fecha Cierre | {{ $lead->close_date }}                                         |
| Proceso      | {{ \App\Enums\LeadProcess::getDescription($lead->process_id) }} |
@endcomponent

@endcomponent
