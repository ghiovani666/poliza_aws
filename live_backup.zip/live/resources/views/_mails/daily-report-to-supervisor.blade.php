@component('mail::message')
# Hola {{ $name }},

Tu reporte de leads diario: {{ $today }}

@component('mail::panel')
Leads en el mes actual: {{ $currentMonth }}
@endcomponent

@component('mail::table')
| Pendientes | Perdidos | Ganados | Ganados PEN | Ganados USD |
| :--------: |:--------:| :------:| ----------: | ----------: |
| {{ $currentMonthData['pending'] }} | {{ $currentMonthData['lost'] }} | {{ $currentMonthData['win'] }} | {{ $currentMonthData['win_pen'] }} | {{ $currentMonthData['win_usd'] }} |
@endcomponent

@component('mail::panel')
Leads en el mes anterior: {{ $previousMonth }}
@endcomponent

@component('mail::table')
| Pendientes | Perdidos | Ganados | Ganados PEN | Ganados USD |
| :--------: |:--------:| :------:| ----------: | ----------: |
| {{ $previousMonthData['pending'] }} | {{ $previousMonthData['lost'] }} | {{ $previousMonthData['win'] }} | {{ $previousMonthData['win_pen'] }} | {{ $previousMonthData['win_usd'] }} |
@endcomponent

@component('mail::panel')
Pipeline
@endcomponent

Todos los leads.

@component('mail::table')
| Etapa | Leads # | Importe PEN | Importe USD |
| :---- |:-------:| -----------:| ----------: |
| {{ \App\Enums\LeadStage::getDescription(1) }} | {{ $pipelineData[1]['count'] }} | {{ $pipelineData[1]['pen'] }} | {{ $pipelineData[1]['usd'] }} |
| {{ \App\Enums\LeadStage::getDescription(2) }} | {{ $pipelineData[2]['count'] }} | {{ $pipelineData[2]['pen'] }} | {{ $pipelineData[2]['usd'] }} |
| {{ \App\Enums\LeadStage::getDescription(3) }} | {{ $pipelineData[3]['count'] }} | {{ $pipelineData[3]['pen'] }} | {{ $pipelineData[3]['usd'] }} |
| {{ \App\Enums\LeadStage::getDescription(4) }} | {{ $pipelineData[4]['count'] }} | {{ $pipelineData[4]['pen'] }} | {{ $pipelineData[4]['usd'] }} |
@endcomponent

@endcomponent
