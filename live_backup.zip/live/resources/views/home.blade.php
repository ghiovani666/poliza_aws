@extends('layouts.app')

@section('content')
    @if($roleId == 1 || $roleId == 2 || $roleId == 3 || $roleId == 4 || $roleId == 5 || $roleId == 6 || $roleId == 9)
        @include('dashboards.admin')
    @else
        <div class="text-center">¡Proximamente!</div>
    @endif
@endsection
