<?php

use App\Enums\SellType;

return [
    SellType::class => [
        SellType::NEW_SALE => 'Venta Nueva',
        SellType::AGENCY => 'Agenciamiento',
        SellType::RENEWAL => 'Renovacion',
        SellType::ENDORSEMENT => 'Endoso',
    ]
];
