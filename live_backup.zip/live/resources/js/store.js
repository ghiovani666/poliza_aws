import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex);

axios.defaults.baseURL = '/api';

export default new Vuex.Store({
    state: {
        acl: {}
    },
    mutations: {},
    actions: {},
    getters: {
        isAdmin() {
            return User.isAdmin;
        },
        isSupervisor() {
            return User.employee.type === 6;
        }
    },
})
