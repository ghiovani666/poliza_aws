<template>
    <div class="container-fluid">
        <loading :active.sync="isLoading" :is-full-page="true"></loading>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                <breadcrumb :tree="[
                {id:0, url:'/', label:'Inicio'},
                {id:1, url:'/policies', label:'Carte de clientes'}
                ]" current="Nuevo"></breadcrumb>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <!-- request date -->
                                <b-form-group
                                    label="Fecha de solicitud"
                                    label-for="request_date"
                                    :invalid-feedback="form.request_date.error"
                                    :state="form.request_date.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.request_date.value"
                                        type="date"
                                        :state="form.request_date.state"
                                        trim
                                        id="request_date"></b-form-input>
                                </b-form-group>

                                <!-- name -->
                                <b-form-group
                                    label="Nombre"
                                    label-for="name"
                                    :invalid-feedback="form.name.error"
                                    :state="form.name.state"
                                    label-cols-sm="4">
                                    <b-input-group>
                                        <b-form-input
                                            v-model="form.name.value"
                                            :state="form.name.state"
                                            type="text"></b-form-input>
                                        <b-input-group-append>
                                            <find></find>
                                        </b-input-group-append>
                                    </b-input-group>
                                </b-form-group>

                                <!-- phone -->
                                <b-form-group
                                    label="Teléfono"
                                    label-for="phone"
                                    :invalid-feedback="form.phone.error"
                                    :state="form.phone.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.phone.value"
                                        type="tel"
                                        :state="form.phone.state"
                                        trim
                                        id="phone"></b-form-input>
                                </b-form-group>

                                <!-- email -->
                                <b-form-group
                                    label="Correo"
                                    label-for="email"
                                    :invalid-feedback="form.email.error"
                                    :state="form.email.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.email.value"
                                        type="email"
                                        :state="form.email.state"
                                        trim
                                        id="email"></b-form-input>
                                </b-form-group>

                                <!-- document_number -->
                                <b-form-group
                                    label="Documento Identidad"
                                    label-for="document_number"
                                    :invalid-feedback="form.document_number.error"
                                    :state="form.document_number.state"
                                    label-cols-sm="4">
                                    <div class="row no-gutters">
                                        <div class="col mr-2">
                                            <b-form-select
                                                v-model="form.document_type.value"
                                                :state="form.document_type.state"
                                                :options="options.document_type"
                                                id="document_type"></b-form-select>
                                        </div>
                                        <div class="col">
                                            <b-form-input
                                                v-model="form.document_number.value"
                                                type="text"
                                                :state="form.document_number.state"
                                                trim
                                                id="document_number"></b-form-input>
                                        </div>
                                    </div>
                                </b-form-group>

                                <!-- birth_date -->
                                <b-form-group
                                    label="Cumpleaños"
                                    label-for="birth_date"
                                    :invalid-feedback="form.birth_date.error"
                                    :state="form.birth_date.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.birth_date.value"
                                        type="date"
                                        :state="form.birth_date.state"
                                        trim
                                        id="birth_date"></b-form-input>
                                </b-form-group>

                                <!-- address -->
                                <b-form-group
                                    label="Dirección"
                                    label-for="address"
                                    :invalid-feedback="form.address.error"
                                    :state="form.address.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.address.value"
                                        type="text"
                                        :state="form.address.state"
                                        trim
                                        id="address"></b-form-input>
                                </b-form-group>

                                <!-- state -->
                                <b-form-group
                                    label="Departamento"
                                    label-for="state"
                                    :invalid-feedback="form.state.error"
                                    :state="form.state.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.state.value"
                                        type="text"
                                        :state="form.state.state"
                                        trim
                                        id="state"></b-form-input>
                                </b-form-group>

                                <!-- province -->
                                <b-form-group
                                    label="Provincia"
                                    label-for="province"
                                    :invalid-feedback="form.province.error"
                                    :state="form.province.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.province.value"
                                        type="text"
                                        :state="form.province.state"
                                        trim
                                        id="province"></b-form-input>
                                </b-form-group>

                                <!-- city -->
                                <b-form-group
                                    label="Distrito"
                                    label-for="city"
                                    :invalid-feedback="form.city.error"
                                    :state="form.city.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.city.value"
                                        type="text"
                                        :state="form.city.state"
                                        trim
                                        id="city"></b-form-input>
                                </b-form-group>

                                <hr>

                                <!-- commission estimated -->
                                <b-form-group
                                    label="Comisión Morgan (Estimado)"
                                    label-for="commission_estimated"
                                    :invalid-feedback="form.commission_estimated.error"
                                    :state="form.commission_estimated.state"
                                    label-cols-sm="4">
                                    <b-input-group prepend="$">
                                        <b-form-input
                                            v-model="form.commission_estimated.value"
                                            type="text"
                                            :state="form.commission_estimated.state"
                                            readonly
                                            id="commission_estimated"></b-form-input>
                                    </b-input-group>
                                </b-form-group>

                                <!-- commission real -->
                                <b-form-group
                                    label="Comisión Morgan (Real)"
                                    label-for="commission_real"
                                    :invalid-feedback="form.commission_real.error"
                                    :state="form.commission_real.state"
                                    label-cols-sm="4">
                                    <b-input-group prepend="$">
                                        <b-form-input
                                            v-model="form.commission_real.value"
                                            type="text"
                                            :state="form.commission_real.state"
                                            trim
                                            id="commission_real"></b-form-input>
                                    </b-input-group>
                                </b-form-group>
                            </div>
                            <div class="col">
                                <!-- policy_status -->
                                <b-form-group
                                    label="Status de Póliza"
                                    label-for="policy_status"
                                    :invalid-feedback="form.policy_status.error"
                                    :state="form.policy_status.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.policy_status.value"
                                        :state="form.policy_status.state"
                                        :options="options.policy_status"
                                        id="policy_status"></b-form-select>
                                </b-form-group>

                                <!-- sell_type -->
                                <b-form-group
                                    label="Tipo de venta"
                                    label-for="sell_type"
                                    :invalid-feedback="form.sell_type.error"
                                    :state="form.sell_type.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.sell_type.value"
                                        :state="form.sell_type.state"
                                        :options="options.sell_type"
                                        id="sell_type"></b-form-select>
                                </b-form-group>

                                <!-- endorsement_type -->
                                <b-form-group
                                    label="Tipo de endoso"
                                    label-for="endorsement_type"
                                    :invalid-feedback="form.endorsement_type.error"
                                    :state="form.endorsement_type.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.endorsement_type.value"
                                        :state="form.endorsement_type.state"
                                        id="endorsement_type"></b-form-input>
                                </b-form-group>

                                <!-- operation_status -->
                                <b-form-group
                                    label="Estado"
                                    label-for="operation_status"
                                    :invalid-feedback="form.operation_status.error"
                                    :state="form.operation_status.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.operation_status.value"
                                        :state="form.operation_status.state"
                                        :options="options.operation_status"
                                        id="operation_status"></b-form-select>
                                </b-form-group>

                                <hr>

                                <!-- broker_id -->
                                <b-form-group
                                    label="Corredor"
                                    label-for="broker_id"
                                    :invalid-feedback="form.broker_id.error"
                                    :state="form.broker_id.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.broker_id.value"
                                        :state="form.broker_id.state"
                                        :options="options.broker_id"
                                        value-field="id"
                                        text-field="name"
                                        id="broker_id"></b-form-select>
                                </b-form-group>

                                <!-- assessor_id -->
                                <b-form-group
                                    label="Asesor"
                                    label-for="assessor_id"
                                    :invalid-feedback="form.assessor_id.error"
                                    :state="form.assessor_id.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.assessor_id.value"
                                        :state="form.assessor_id.state"
                                        :options="options.assessor_id"
                                        value-field="id"
                                        text-field="name"
                                        id="assessor_id"></b-form-select>
                                </b-form-group>

                                <!-- key_id -->
                                <b-form-group
                                    label="Key"
                                    label-for="key_id"
                                    :invalid-feedback="form.key_id.error"
                                    :state="form.key_id.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.key_id.value"
                                        :state="form.key_id.state"
                                        :options="options.key_id"
                                        value-field="id"
                                        text-field="name"
                                        id="key_id"></b-form-select>
                                </b-form-group>

                                <!-- prime -->
                                <b-form-group
                                    label="Prima neta"
                                    label-for="prime"
                                    :invalid-feedback="form.prime.error"
                                    :state="form.prime.state"
                                    label-cols-sm="4">
                                    <div class="row">
                                        <div class="col">
                                            <b-form-select
                                                v-model="form.currency_id.value"
                                                :state="form.currency_id.state"
                                                :options="options.currency_id"
                                                id="currency_id"></b-form-select>
                                        </div>
                                        <div class="col">
                                            <b-form-input
                                                v-model="form.prime.value"
                                                :state="form.prime.state"
                                                id="prime"></b-form-input>
                                        </div>
                                    </div>
                                </b-form-group>

                                <!-- funding_id -->
                                <b-form-group
                                    label="Financiamiento"
                                    label-for="funding_id"
                                    :invalid-feedback="form.funding_id.error"
                                    :state="form.funding_id.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.funding_id.value"
                                        :state="form.funding_id.state"
                                        :options="options.funding_id"
                                        id="funding_id"></b-form-select>
                                </b-form-group>

                                <!-- dues -->
                                <b-form-group
                                    label="Cuotas"
                                    label-for="dues"
                                    :invalid-feedback="form.dues.error"
                                    :state="form.dues.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.dues.value"
                                        :state="form.dues.state"
                                        :options="options.dues"
                                        id="dues"></b-form-select>
                                </b-form-group>

                                <!-- policy_period -->
                                <b-form-group
                                    label="Período de póliza"
                                    label-for="policy_period"
                                    :invalid-feedback="form.policy_period.error"
                                    :state="form.policy_period.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.policy_period.value"
                                        :state="form.policy_period.state"
                                        :options="options.policy_period"
                                        id="policy_period"></b-form-select>
                                </b-form-group>
                            </div>
                            <div class="col">
                                <!-- city -->
                                <b-form-group
                                    label="Póliza"
                                    label-for="city"
                                    :invalid-feedback="form.city.error"
                                    :state="form.city.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.city.value"
                                        type="text"
                                        :state="form.city.state"
                                        trim
                                        id="city"></b-form-input>
                                </b-form-group>

                                <!-- city -->
                                <b-form-group
                                    label="# tramite"
                                    label-for="city"
                                    :invalid-feedback="form.city.error"
                                    :state="form.city.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.city.value"
                                        type="text"
                                        :state="form.city.state"
                                        trim
                                        id="city"></b-form-input>
                                </b-form-group>

                                <!-- release_date -->
                                <b-form-group
                                    label="Fecha emisión"
                                    label-for="release_date"
                                    :invalid-feedback="form.release_date.error"
                                    :state="form.release_date.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.release_date.value"
                                        type="date"
                                        :state="form.release_date.state"
                                        id="release_date"></b-form-input>
                                </b-form-group>

                                <!-- validity_month -->
                                <b-form-group
                                    label="Mes de vigencia"
                                    label-for="validity_month"
                                    :invalid-feedback="form.validity_month.error"
                                    :state="form.validity_month.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.validity_month.value"
                                        type="date"
                                        :state="form.validity_month.state"
                                        id="validity_month"></b-form-input>
                                </b-form-group>

                                <!-- validity -->
                                <b-form-group
                                    label="Vigencia"
                                    label-for="validity"
                                    :invalid-feedback="form.validity.error"
                                    :state="form.validity.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.validity.value"
                                        type="date"
                                        :state="form.validity.state"
                                        id="validity"></b-form-input>
                                </b-form-group>

                                <!-- policy_delivery_date -->
                                <b-form-group
                                    label="Fecha de anulación"
                                    label-for="policy_delivery_date"
                                    :invalid-feedback="form.policy_delivery_date.error"
                                    :state="form.policy_delivery_date.state"
                                    label-cols-sm="4">
                                    <b-form-input
                                        v-model="form.policy_delivery_date.value"
                                        type="date"
                                        :state="form.policy_delivery_date.state"
                                        id="policy_delivery_date"></b-form-input>
                                </b-form-group>

                                <!-- inspection -->
                                <b-form-group
                                    label="Con inspección"
                                    label-for="inspection"
                                    :invalid-feedback="form.inspection.error"
                                    :state="form.inspection.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.inspection.value"
                                        :state="form.inspection.state"
                                        :options="options.inspection"
                                        id="inspection"></b-form-select>
                                </b-form-group>

                                <!-- abidance -->
                                <b-form-group
                                    label="Continuidad"
                                    label-for="abidance"
                                    :invalid-feedback="form.abidance.error"
                                    :state="form.abidance.state"
                                    label-cols-sm="4">
                                    <b-form-select
                                        v-model="form.abidance.value"
                                        :state="form.abidance.state"
                                        :options="options.abidance"
                                        id="abidance"></b-form-select>
                                </b-form-group>

                                <!-- comment -->
                                <b-form-group
                                    label="Observaciones"
                                    label-for="comment"
                                    :invalid-feedback="form.comment.error"
                                    :state="form.comment.state"
                                    label-cols-sm="4">
                                    <b-form-textarea
                                        v-model="form.comment.value"
                                        :state="form.comment.state"
                                        rows="8"
                                        id="comment"></b-form-textarea>
                                </b-form-group>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="fixed-bottom p-3" style="background-color: #e9ecef">
            <div class="row">
                <div class="col text-left">
                    <button class="btn btn-primary">Beneficiarios</button>
                    <button class="btn btn-primary">Asegurados</button>
                    <button class="btn btn-primary">Vehículos</button>
                </div>
                <div class="col text-center">
                    <button class="btn btn-primary">SCTR</button>
                    <button class="btn btn-primary">Renovación</button>
                    <button class="btn btn-primary">Endoso</button>
                </div>
                <div class="col text-right">
                    <button @click.prevent="onSubmit" type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Loading from 'vue-loading-overlay';
    import 'vue-loading-overlay/dist/vue-loading.css';

    export default {
        components: {Loading},
        data() {
            return {
                isLoading: true,
                form: {
                    request_date: {state: '', value: '', error: ''},
                    name: {state: '', value: '', error: ''},
                    phone: {state: '', value: '', error: ''},
                    email: {state: '', value: '', error: ''},
                    document_type: {state: '', value: 1, error: ''},
                    document_number: {state: '', value: '', error: ''},
                    birth_date: {state: '', value: '', error: ''},
                    address: {state: '', value: '', error: ''},
                    state: {state: '', value: '', error: ''},
                    province: {state: '', value: '', error: ''},
                    city: {state: '', value: '', error: ''},
                    commission_estimated: {state: '', value: 0, error: ''},
                    commission_real: {state: '', value: 0, error: ''},
                    policy_status: {state: '', value: 1, error: ''},
                    sell_type: {state: '', value: 1, error: ''},
                    endorsement_type: {state: '', value: '', error: ''},
                    operation_status: {state: '', value: 1, error: ''},
                    broker_id: {state: '', value: 1, error: ''},
                    assessor_id: {state: '', value: 1, error: ''},
                    key_id: {state: '', value: '', error: ''},
                    currency_id: {state: '', value: 1, error: ''},
                    prime: {state: '', value: '', error: ''},
                    funding_id: {state: '', value: '', error: ''},
                    dues: {state: '', value: '', error: ''},
                    policy_period: {state: '', value: '', error: ''},
                    policy_code: {state: '', value: '', error: ''},
                    procedure_number: {state: '', value: '', error: ''},
                    release_date: {state: '', value: '', error: ''},
                    validity_month: {state: '', value: '', error: ''},
                    validity: {state: '', value: '', error: ''},
                    policy_delivery_date: {state: '', value: '', error: ''},
                    inspection: {state: '', value: 1, error: ''},
                    abidance: {state: '', value: 1, error: ''},
                    comment: {state: '', value: '', error: ''},
                },
                options: {
                    document_type: [
                        {value: 1, text: 'DNI'},
                        {value: 2, text: 'RUC'},
                        {value: 3, text: 'Pasaporte'},
                    ],
                    policy_status: [
                        {value: 1, text: 'Vigente'},
                        {value: 0, text: 'No Vigente'},
                    ],
                    sell_type: [
                        {value: 1, text: 'Venta Nueva'},
                        {value: 2, text: 'Agenciamiento'},
                        {value: 3, text: 'Renovación'},
                        {value: 4, text: 'Endoso'},
                    ],
                    operation_status: [
                        {value: 1, text: 'En emisión'},
                        {value: 1, text: 'Emitido'},
                        {value: 1, text: 'En Agenciamiento'},
                        {value: 1, text: 'Agenciado'},
                        {value: 1, text: 'En renovación'},
                        {value: 1, text: 'Renovado'},
                        {value: 1, text: 'Perdido'},
                        {value: 1, text: 'Anulado'},
                    ],
                    broker_id: [],
                    assessor_id: [],
                    key_id: [],
                    currency_id: [
                        {value: 1, text: 'Soles'},
                        {value: 2, text: 'Dolares'},
                    ],
                    funding_id: [
                        {value: 1, text: 'CC (cargo en cuenta)'},
                        {value: 1, text: 'CP (cupón)'},
                        {value: 1, text: 'Contado'},
                    ],
                    dues: [
                        {value: 1, text: '01'},
                        {value: 2, text: '02'},
                        {value: 3, text: '03'},
                        {value: 4, text: '04'},
                        {value: 5, text: '05'},
                        {value: 6, text: '06'},
                        {value: 7, text: '07'},
                        {value: 8, text: '08'},
                        {value: 9, text: '09'},
                        {value: 10, text: '10'},
                        {value: 11, text: '11'},
                        {value: 12, text: '12'},
                    ],
                    policy_period: [
                        {value: 1, text: 'Mensual'},
                        {value: 2, text: 'Bimestral'},
                        {value: 3, text: 'Trimestral'},
                        {value: 6, text: 'Semestral'},
                        {value: 12, text: 'Anual'},
                    ],
                    inspection: [
                        {value: 1, text: 'Si'},
                        {value: 0, text: 'No'},
                    ],
                    abidance: [
                        {value: 1, text: 'Si'},
                        {value: 0, text: 'No'},
                    ],
                }
            };
        },
        mounted() {
            this.fetchEmployees();
            this.fetchKeys();
            this.loading(false);
        },
        created() {
            let ctx = this;
            this.$root.$on('customer-selected', function (item) {
                ctx.form.name.value = item.name;
                ctx.form.phone.value = item.phone;
                ctx.form.email.value = item.email;
                //ctx.form.dni_ruc.value = item.dni_ruc;
                ctx.form.birth_date.value = item.birth_date;
                ctx.form.address.value = item.address;
                ctx.form.state.value = item.state;
                ctx.form.province.value = item.province;
                ctx.form.city.value = item.city;
            });
        },
        methods: {
            loading(status = true) {
                this.isLoading = status;
            },
            getFormData() {
                let data = {};
                for (let field in this.form) {
                    data[field] = this.form[field].value;
                }
                return data;
            },
            parseFormErrors(errors) {
                for (let field in errors) {
                    this.form[field].state = false;
                    this.form[field].error = errors[field][0];
                }
            },
            cleanFormErrors() {
                for (let field in this.form) {
                    this.form[field].state = '';
                }
            },
            onSubmit() {
                this.loading();
                this.cleanFormErrors();
                let url = '/api/policies';
                axios.post(url, this.getFormData()).then().catch((error) => {
                    // catch validation error
                    if (error.response.status === 422) {
                        this.parseFormErrors(error.response.data.errors);
                        return;
                    }

                    // catch general error
                    alert('We found an error processing your request!');
                }).then(() => {
                    this.loading(false);
                });
            },
            fetchEmployees() {
                let url = '/api/employees';
                axios.get(url).then((response) => {
                    this.options.broker_id = response.data.data;
                    this.options.assessor_id = response.data.data;
                }).catch().then();
            },
            fetchKeys() {
                let url = '/api/keys';
                axios.get(url).then((response) => {
                    this.options.key_id = response.data.data;
                }).catch().then();
            }
        }
    }
</script>
