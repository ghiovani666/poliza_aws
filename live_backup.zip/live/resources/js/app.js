/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');
require('select2');
require('daterangepicker');

window.Vue = require('vue');
window.BootstrapVue = require('bootstrap-vue');
window.moment = require('moment');

Vue.use(BootstrapVue);

/**
 * Pages
 */
//Vue.component('policies-create', require('./pages/PolicyCreate.vue').default);

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

//Vue.component('example-component', require('./components/ExampleComponent.vue').default);
//Vue.component('breadcrumb', require('./components/Breadcrumb.vue').default);
//Vue.component('find', require('./components/Find.vue').default);

Vue.component('btnImportPaying', require('./components/BtnImportPaying.vue').default);
Vue.component('calendar', require('./components/Calendar.vue').default);
Vue.component('chartPieBest', require('./components/ChartPieBest.vue').default);
Vue.component('chartBarYear', require('./components/ChartBarYear.vue').default);
Vue.component('chartBarYearStack', require('./components/ChartBarYearStack.vue').default);
Vue.component('chartBarStock', require('./components/ChartBarStock.vue').default);
Vue.component('chartFilters', require('./components/ChartFilters.vue').default);
Vue.component('chartFilter', require('./components/ChartFilter.vue').default);
Vue.component('chartTableTop', require('./components/ChartTableTop.vue').default);
Vue.component('chartTableYear', require('./components/ChartTableYear.vue').default);
Vue.component('chartTableRenew', require('./components/ChartTableRenew.vue').default);
Vue.component('chartTableCounter', require('./components/ChartTableCounter.vue').default);
Vue.component('chartTableGroups', require('./components/ChartTableGroups.vue').default);
Vue.component('chartCounter', require('./components/ChartCounter.vue').default);
Vue.component('comments', require('./components/Comments.vue').default);

Vue.component('crm-dashboard-index', require('./components/crm/DashboardIndex').default);
Vue.component('crm-dashboard-detail', require('./components/crm/DashboardDetail.vue').default);
Vue.component('crm-dashboard-filters', require('./components/crm/DashboardFilters.vue').default);
Vue.component('lead-appointments', require('./components/crm/LeadAppointments').default);

Vue.component('form-dropdown', require('./components/form/Dropdown').default);
Vue.component('form-dropdown-with-checkbox', require('./components/form/DropdownWithCheckbox.vue').default);

Vue.component('link-to-modal', require('./components/form/LinkToModal.vue').default);

Vue.component('filesUploader', require('./components/FilesUploader.vue').default);

Vue.component('multiselect', Multiselect)

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

import store from './store'

// Notyf
import {Notyf} from 'notyf';
import 'notyf/notyf.min.css';

// MultiSelect
// https://vue-multiselect.js.org/#sub-getting-started
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.min.css';

/**
 * Filters
 */
Vue.filter('date', function (value) {
    window.moment.locale('es');
    return window.moment(value).format('L')
})
Vue.filter('time', function (value) {
    window.moment.locale('es');
    return window.moment(value).format('LT')
})

// Event Bus
export const RoleEventBus = new Vue();

const app = new Vue({
    el: '#app',
    store,
    provide: () => {
        return {
            notyf: new Notyf({
                dismissible: true,
                duration: 5000 // Set your global Notyf configuration here
            })
        }
    },
});
