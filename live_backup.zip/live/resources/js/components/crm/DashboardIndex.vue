<template>
    <div>
        <div class="container-fluid mb-4">
            <chart-filter-range-date name="created_at" label="Fecha Creacion" endpoint="chart/years"
                          default-value=""></chart-filter-range-date>
            <chart-filter name="assessor_id" label="Asesor" endpoint="chart/assessors"></chart-filter>
        </div>

        <chart-counters endpoint="/chart/leads/ratios"></chart-counters>

        <chart-counters endpoint="/chart/leads/counters"></chart-counters>

        <div class="container-fluid mb-4">
            <div class="card">
                <div class="card-body">
                    <chart-bar-leads-actions name="leads" title="Leads vs Acciones"></chart-bar-leads-actions>
                </div>
            </div>
        </div>

        <div class="container-fluid mb-4">
            <div class="card">
                <div class="card-body">
                    <chart-table-leads-actions></chart-table-leads-actions>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import ChartCounters from './CharCounters'
    import ChartBarLeadsActions from './ChartBarLeadsActions'
    import ChartTableLeadsActions from './ChartTableLeadsActions'
    import ChartFilter from '../ChartFilter'
    import ChartFilterRangeDate from '../ChartFilterRangeDate'

    export default {
        components: {ChartCounters, ChartBarLeadsActions, ChartTableLeadsActions, ChartFilter, ChartFilterRangeDate}
    }
</script>
