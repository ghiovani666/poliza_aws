<template>
    <div>
        <div class="card-title">
            Detalle Actions vs Leads
        </div>

        <div v-if="isLoading" class="text-center">loading...</div>

        <table v-if="!isLoading" id="details" class="table table-striped table-hover table-sm">
            <thead>
            <tr>
                <td></td>
                <td class="text-center" colspan="5">Acciones</td>
                <td class="text-center" colspan="4">Leads</td>
            </tr>
            <tr>
                <th>Asesor</th>
                <th><i title="Llamada contestada" class="fas fa-phone-volume"></i></th>
                <th><i title="Llamada no contestada" class="fas fa-phone-slash"></i></th>
                <th><i title="Email" class="fas fa-envelope"></i></th>
                <th><i title="Reunion 1" class="fas fa-handshake"></i></th>
                <th><i title="Reunion 2" class="fas fa-handshake"></i></th>
                <th><i title="Reunion 3" class="fas fa-handshake"></i></th>
                <th>Total</th>
                <th>Creados</th>
                <th>Pendientes</th>
                <th>Ganados</th>
                <th>Importe PEN</th>
                <th>Importe USD</th>
                <th>Efectividad (%)</th>
                <th>Ratio PEN</th>
                <th>Ratio USD</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="employee in employees">
                <td>{{ employee.name }}</td>
                <td><span @click="openActionsDetails(employee.id,1)">{{ employee.call_success }}</span></td>
                <td><span @click="openActionsDetails(employee.id,2)">{{ employee.call_fail }}</span></td>
                <td><span @click="openActionsDetails(employee.id,3)">{{ employee.email }}</span></td>
                <td><span @click="openActionsDetails(employee.id,4)">{{ employee.meeting1 }}</span></td>
                <td><span @click="openActionsDetails(employee.id,5)">{{ employee.meeting2 }}</span></td>
                <td><span @click="openActionsDetails(employee.id,6)">{{ employee.meeting3 }}</span></td>
                <td><span @click="openActionsDetails(employee.id)">{{ employee.total }}</span></td>
                <td><span @click="openLeads(employee.id)">{{ employee.created }}</span></td>
                <td><span @click="openLeads(employee.id, 1)">{{ employee.pending }}</span></td>
                <td><span @click="openLeads(employee.id, 3)">{{ employee.success }}</span></td>
                <td class="text-success">S/{{ employee.total_pen }}</td>
                <td class="text-success">${{ employee.total_usd }}</td>
                <td>{{ employee.productivity }}</td>
                <td>{{ employee.ratio_pen }}</td>
                <td>{{ employee.ratio_usd }}</td>
            </tr>
            </tbody>
        </table>

        <!-- Modal Actions -->
        <div class="modal fade" id="actionsModal" tabindex="-1" role="dialog" aria-labelledby="actionsModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="actionsModalLabel">Detalle Acciones</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div v-if="isLoadingActions" class="text-center">loading...</div>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>Asesor</th>
                                <th>Acciones</th>
                                <th>Lead</th>
                                <th>Fecha</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-for="comment in actions">
                                <td>{{ comment.user.name }}</td>
                                <td>
                                    <span v-for="action in comment.actionsNamed" class="badge badge-secondary mr-2 p-1">{{ action.name }}</span>
                                </td>
                                <td>
                                    <a :href="'/leads/'+comment.commentable.id" target="_blank">
                                        {{ comment.commentable.name }}
                                    </a>
                                </td>
                                <td>{{ comment.createdTimeAgo }}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Leads -->
        <div class="modal fade" id="leadsModal" tabindex="-1" role="dialog" aria-labelledby="leadsModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="leadsModalLabel">Detalle Leads</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div v-if="isLoadingLeads" class="text-center">loading...</div>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>Asesor</th>
                                <th>Lead</th>
                                <th>Proceso</th>
                                <th>Moneda</th>
                                <th>Importe</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-for="lead in leads">
                                <td>{{ lead.assessor.name }}</td>
                                <td>
                                    <a :href="'/leads/'+lead.id" target="_blank">
                                        {{ lead.name }}
                                    </a>
                                </td>
                                <td>{{ lead.processName }}</td>
                                <td>{{ lead.currency }}</td>
                                <td>{{ lead.amount }}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        props: ['name', 'title', 'type'],
        data() {
            return {
                isLoading: true,
                isLoadingActions: false,
                isLoadingLeads: false,
                employees: [],
                actions: [],
                leads: [],
                filters: {},
            };
        },
        created() {
            let ctx = this;
            this.$root.$on('apply-filter', function (payload) {
                ctx.filters[payload.filter] = payload.value;
                ctx.getData();
            });

            this.$root.$on('remove-filter', function (payload) {
                delete ctx.filters[payload.filter];
                ctx.getData();
            });
        },
        mounted() {
            this.getData();
        },
        methods: {
            getData() {
                this.isLoading = true;
                let url = 'chart/leads/table-leads-actions';
                axios.get(url, {params: this.filters})
                    .then((response) => this.employees = response.data)
                    .catch()
                    .then(() => this.isLoading = false);
            },
            openActionsDetails(assessor_id, action = 0) {
                this.getActions(assessor_id, action);
                $('#actionsModal').modal('show');
            },
            getActions(assessor_id, action) {
                this.isLoadingActions = true;
                let url = 'chart/leads/actions';
                let data = {params: JSON.parse(JSON.stringify(this.filters))};
                data.params.assessor_id = assessor_id;
                data.params.action = action;

                axios.get(url, data).then((response) => this.actions = response.data).catch().then(() => this.isLoadingActions = false);
            },
            openLeads(assessor_id, process = 0) {
                this.getLeads(assessor_id, process);
                $('#leadsModal').modal('show');
            },
            getLeads(assessor_id, process) {
                this.isLoadingLeads = true;
                let url = 'chart/leads';
                let data = {params: JSON.parse(JSON.stringify(this.filters))};
                data.params.assessor_id = assessor_id;
                data.params.process_id = process;

                axios.get(url, data).then((response) => this.leads = response.data).catch().then(() => this.isLoadingLeads = false);
            }
        }
    }
</script>

<style scoped lang="scss">
    #details {
        thead {
            th, td {
                text-align: center;
            }
        }

        tbody {
            td {
                text-align: center;
            }

            td:first-child {
                text-align: left;
            }

            td:last-child, td:nth-last-child(2) {
                text-align: right;
            }

            td {
                span {
                    cursor: pointer;
                    color: blue;
                }
            }
        }
    }

    .modal-body {
        max-height: calc(100vh - 225px);
        overflow-y: auto;
    }
</style>
