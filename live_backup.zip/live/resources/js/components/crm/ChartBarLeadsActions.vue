<template>
    <div>
        <div class="card-title">
            {{ title }}
        </div>
        <canvas :id="name" height="50"></canvas>
    </div>
</template>

<script>
    import ChartDataLabels from 'chartjs-plugin-datalabels';

    export default {
        props: ['name', 'title', 'type'],
        data() {
            return {
                labels: [],
                leads: [],
                actions: [],
                filters: {},
            };
        },
        mounted() {
            this.chart();
            this.getData();
        },
        created() {
            let ctx = this;
            this.$root.$on('apply-filter', function (payload) {
                ctx.filters[payload.filter] = payload.value;
                ctx.getData();
            });

            this.$root.$on('remove-filter', function (payload) {
                delete ctx.filters[payload.filter];
                ctx.getData();
            });
        },
        methods: {
            getData() {
                let url = 'chart/leads/leads-actions';
                axios.get(url, {params: this.filters}).then((response) => {
                    window['chartBar' + this.name].data.labels = this.labels = response.data.labels;
                    window['chartBar' + this.name].data.datasets[0].data = this.leads = response.data.leads;
                    window['chartBar' + this.name].data.datasets[1].data = this.actions = response.data.actions;
                    window['chartBar' + this.name].update();
                });
            },
            chart() {
                let vue = this;
                let ctx = document.getElementById(this.name);
                window['chartBar' + this.name] = new Chart(ctx, {
                    plugins: [ChartDataLabels],
                    type: 'bar',
                    data: {
                        labels: [],
                        datasets: [
                            {
                                label: 'Leads Creados',
                                data: [],
                                backgroundColor: 'rgba(255,99,132,0.2)',
                                borderColor: 'rgba(255, 99, 132, 1)',
                                borderWidth: 1
                            },
                            {
                                label: 'Acciones Realizadas',
                                data: [],
                                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }
                        ]
                    },
                    options: {
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        },
                    }
                });
            }
        }
    }
</script>
