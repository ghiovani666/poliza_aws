<template>
  <div class="form-row mb-2">
    <div class="form-group col-3">
      <multiselect
          v-model="form.type"
          :options="typeOptions"
          track-by="id"
          label="name"
          placeholder="Vista"
      ></multiselect>
    </div>
    <div class="form-group col-3">
      <multiselect
          v-model="form.status"
          :options="statusOptions"
          track-by="id"
          label="name"
          placeholder="Estado de Cita"
      ></multiselect>
    </div>
    <div class="form-group col-3"></div>
    <div class="form-group col-3"></div>

    <div class="form-group col-3">
      <multiselect
          v-model="form.year"
          :options="yearOptions"
          placeholder="Año"
      ></multiselect>
    </div>
    <div class="form-group col-3">
      <multiselect
          v-model="form.month"
          :options="monthOptions"
          track-by="id"
          label="name"
          placeholder="Mes"
      ></multiselect>
    </div>
    <div class="form-group col-3">
      <multiselect
          v-model="form.week"
          :options="weekOptions"
          placeholder="Semana"
      ></multiselect>
    </div>
    <div class="form-group col-3"></div>

    <div class="form-group col-3">
      <multiselect
          v-model="form.admin"
          :options="adminOptions"
          track-by="id"
          label="name"
          placeholder="Gerentes"
          multiple
      >
        <template slot="selection" slot-scope="{ values, search, isOpen }">
          <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">
            {{ values.length }} seleccionados
          </span>
        </template>
      </multiselect>
    </div>
    <div class="form-group col-3">
      <multiselect
          v-model="form.supervisor"
          :options="supervisorOptions"
          track-by="id"
          label="name"
          placeholder="Supervisores"
          multiple
      >
        <template slot="selection" slot-scope="{ values, search, isOpen }">
          <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">
            {{ values.length }} seleccionados
          </span>
        </template>
      </multiselect>
    </div>
    <div class="form-group col-3">
      <multiselect
          v-model="form.assessor"
          :options="assessorOptions"
          track-by="id"
          label="name"
          placeholder="Asesores"
          multiple
      >
        <template slot="selection" slot-scope="{ values, search, isOpen }">
          <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">
            {{ values.length }} seleccionados
          </span>
        </template>
      </multiselect>
    </div>

    <div class="form-group col-3">
      <button @click="onSubmit" class="btn btn-primary btn-lg">APLICAR FILTROS</button>
    </div>
  </div>
</template>

<script>
export default {
  props: [
    'typeOptions', 'typeSelected',
    'statusOptions', 'statusSelected',
    'yearOptions', 'yearSelected',
    'monthOptions', 'monthSelected',
    'weekOptions', 'weekSelected',
    'adminOptions', 'adminSelected',
    'supervisorOptions', 'supervisorSelected',
    'assessorOptions', 'assessorSelected',
  ],
  data() {
    return {
      form: {
        type: '',
        status: '',
        year: '',
        month: '',
        week: '',
        admin: [],
        supervisor: [],
        assessor: [],
      }
    }
  },
  mounted() {
    this.form.type = this.typeSelected
    this.form.status = this.statusSelected
    this.form.year = this.yearSelected
    this.form.month = this.monthSelected
    this.form.week = this.weekSelected
    this.form.admin = this.adminSelected
    this.form.supervisor = this.supervisorSelected
    this.form.assessor = this.assessorSelected
  },
  methods: {
    onSubmit() {
      let data = {
        type: this.form.type.id,
        status: this.form.status.id,
        year: this.form.year,
        month: this.form.month.id,
        week: this.form.week,
        admin: this.form.admin.map(obj => obj.id),
        supervisor: this.form.supervisor.map(obj => obj.id),
        assessor: this.form.assessor.map(obj => obj.id),
        filters: 'execute',
      }
      window.location.href = '/appointments/dashboard?' + $.param(data);
    }
  }
}
</script>
