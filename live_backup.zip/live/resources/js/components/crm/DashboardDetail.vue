<template>
    <div>
        <div class="card-title">{{ employee.job.name }} : {{ employee.name }}</div>

        <div class="my-2">{{ range }}</div>

        <table class="table table-striped">
            <thead>
            <tr>
                <th>Cliente</th>
                <th>Numero de cita</th>
                <th>Estado</th>
                <th>Telefono</th>
                <th>Fecha</th>
                <th>Hora</th>
            </tr>
            </thead>
            <tbody>
            <template v-if="items.length > 0">
                <tr v-for="item in items">
                    <td><a :href="'/leads/'+item.lead.id" target="_blank">{{ item.lead.name }}</a></td>
                    <td>{{ item.numberName }}</td>
                    <td>{{ item.statusName }}</td>
                    <td>{{ item.lead.phone }}</td>
                    <td>{{ item.date | date }}</td>
                    <td>{{ item.date | time }}</td>
                </tr>
            </template>
            <template v-if="items.length === 0">
                <tr>
                    <td class="text-center" colspan="6">No se encontraron registros</td>
                </tr>
            </template>
            </tbody>
        </table>
    </div>
</template>

<script>
export default {
    props: {
        endpoint: String,
    },
    data() {
        return {
            employee: {
                name: '',
                job: {name: ''}
            },
            range: '',
            items: []
        }
    },
    mounted() {
        this.getItems()
    },
    methods: {
        getItems() {
            let url = this.endpoint
            axios.get(url).then((response) => {
                this.employee = response.data.employee
                this.range = response.data.range
                this.items = response.data.items
            }).catch().then()
        }
    }
}
</script>
