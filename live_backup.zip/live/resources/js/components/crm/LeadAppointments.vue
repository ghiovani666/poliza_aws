<template>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col">
          <div class="h5">Registrar Cita</div>
        </div>
      </div>

      <div class="form-group">
        <label>Numero de cita</label>
        <div class="row">
          <div class="col">
            <div class="custom-control custom-radio">
              <input v-model="form.number" type="radio" class="custom-control-input" id="a1" value="1"
                     :checked="!isDisabled1" :disabled="isDisabled1">
              <label class="custom-control-label" for="a1">Primera Cita</label>
            </div>
          </div>
          <div class="col">
            <div class="custom-control custom-radio">
              <input v-model="form.number" type="radio" class="custom-control-input" id="a2" value="2"
                     :disabled="isDisabled2">
              <label class="custom-control-label" for="a2">Segunda Cita</label>
            </div>
          </div>
          <div class="col">
            <div class="custom-control custom-radio">
              <input v-model="form.number" type="radio" class="custom-control-input" id="a3" value="3"
                     :disabled="isDisabled3">
              <label class="custom-control-label" for="a3">Tercera Cita</label>
            </div>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label>Estado de cita</label>
        <select v-model="form.status" class="form-control">
          <option value="1">Agendada</option>
          <option value="2">Efectiva</option>
          <option value="3">No Efectiva</option>
          <option value="4">Reprogramada</option>
        </select>
      </div>

      <div class="form-row">
        <div class="form-group col">
          <label>Fecha</label>
          <input v-model="form.date" type="date" class="form-control">
        </div>
        <div class="form-group col">
          <label>Hora</label>
          <input v-model="form.time" type="time" class="form-control">
        </div>
      </div>

      <div class="form-group">
        <label>Comentario</label>
        <textarea v-model="form.comment" class="form-control mb-2"
                  placeholder="Añade un comentario aqui..."
                  rows="5"></textarea>
      </div>

      <div class="form-group text-right">
        <button @click="addAppointment" class="btn btn-primary btn-block" :disabled="isLoadingForm">
          <i v-if="!isLoadingForm" class="fas fa-save mr-2" aria-hidden="true"></i>
          {{ formText }}
        </button>
      </div>

      <div class="row mt-4">
        <div class="col">
          <div class="h5">Historial de Citas</div>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <div class="container" style="max-height: 500px; overflow-y: auto">
            <div v-if="!isLoadingAppointments" v-for="appointment in appointments">
              <hr>
              <div class="row">
                <div class="col-2 text-center" style="width: 100px">
                  <div class="mb-2"><i class="fas fa-user-circle fa-2x"></i></div>
                  <div class="mb-2">{{ appointment.user.name }}</div>
                </div>
                <div class="col">
                  <div class="mb-2">
                    <div v-if="isDeletable" class="float-right" style="cursor: pointer"
                         @click="deleteRecord(appointment)">
                      <i v-if="!isLoadingDelete" class="fas fa-trash" title="Eliminar registro"></i>
                      <i v-if="isLoadingDelete" class="fas fa-spinner fa-spin"></i>
                    </div>
                    {{ appointment.numberName }} - {{ appointment.statusName }}<br>
                    Fecha y hora: {{ parseDate(appointment.date) }}
                  </div>
                  <div class="mb-2" style="white-space: pre-wrap">{{ appointment.comment }}</div>
                  <div class="text-muted">{{ appointment.createdTimeAgo }}</div>
                </div>
              </div>
            </div>
          </div>
          <div v-if="isLoadingAppointments" class="text-center">cargando...</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import CommentForm from "../CommentForm";
import moment from "moment"

export default {
  inject: ['notyf'],
  components: {CommentForm},
  props: ['id', 'type'],
  data() {
    return {
      isLoadingAppointments: true,
      appointments: [],
      isLoadingForm: true,
      form: {
        number: '',
      },
      formText: 'Cargando...',
      configuration: {},
      isLoadingDelete: false,
    };
  },
  computed: {
    isDisabled1() {
      return this.configuration.number !== 1;
    },
    isDisabled2() {
      return this.configuration.number !== 2;
    },
    isDisabled3() {
      return this.configuration.number !== 3;
    },
    isDeletable() {
      let rolesAvailable = [1, 3, 12]
      let roleId = window.User.employee.type
      return rolesAvailable.includes(roleId)
    }
  },
  created() {

  },
  mounted() {
    this.getConfiguration();
    this.getAppointments();
  },
  methods: {
    getConfiguration() {
      this.loadingForm(true)
      let url = 'crm/leads/' + this.id + '/appointments/status';
      axios.get(url)
          .then((response) => {
            this.configuration = response.data
            this.form.number = this.configuration.number
          })
          .catch()
          .then(() => this.loadingForm(false));
    },
    getAppointments() {
      this.isLoadingAppointments = true;
      let url = 'crm/leads/' + this.id + '/appointments';
      axios.get(url)
          .then((response) => this.appointments = response.data.data)
          .catch()
          .then(() => this.isLoadingAppointments = false);
    },
    addAppointment() {
      this.loadingForm(true)
      let url = 'crm/leads/' + this.id + '/appointments';
      let data = this.form;
      axios.post(url, data)
          .then((response) => {
            this.getConfiguration()
            this.getAppointments()
            this.cleanForm()
          })
          .catch()
          .then(() => this.loadingForm(false));
    },
    parseDate(date) {
      return moment(date).format('DD/MM/YYYY hh:mm A')
    },
    loadingForm(isLoading = true) {
      this.isLoadingForm = isLoading
      this.formText = !isLoading ? 'Guardar' : 'Cargando...'
    },
    cleanForm() {
      this.form.status = ''
      this.form.comment = ''
      this.form.date = ''
      this.form.time = ''
    },
    deleteRecord(appointment) {
      this.isLoadingDelete = true
      let url = 'crm/leads/' + this.id + '/appointments/' + appointment.id;
      axios.delete(url).then(() => {
        this.notyf.success('Se elimino el registro correctamente.');
        this.getAppointments()
      }).catch(() => {
        this.notyf.error('Ups! Ocurrio un problema, intentelo de nuevo mas tarde.');
      }).then(() => {
        this.isLoadingDelete = false
      })
    }
  }
}
</script>
