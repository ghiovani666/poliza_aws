<template>
    <div class="container-fluid mb-4">
        <div v-if="isLoading" class="text-center">loading...</div>

        <div v-if="!isLoading" class="row">
            <div v-for="counter in counters" class="col">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="h1">{{ counter.total }}</div>
                        <div>{{ counter.name }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['endpoint'],
        data() {
            return {
                isLoading: true,
                counters: [],
                filters: {},
            };
        },
        created() {
            let ctx = this;
            this.$root.$on('apply-filter', function (payload) {
                ctx.filters[payload.filter] = payload.value;
                ctx.getCounters();
            });

            this.$root.$on('remove-filter', function (payload) {
                delete ctx.filters[payload.filter];
                ctx.getCounters();
            });
        },
        mounted() {
            this.getCounters();
        },
        methods: {
            getCounters() {
                let url = this.endpoint;
                let config = {params: this.filters};
                axios.get(url, config)
                    .then((response) => this.counters = response.data)
                    .catch()
                    .then(() => this.isLoading = false);
            }
        }
    }
</script>
