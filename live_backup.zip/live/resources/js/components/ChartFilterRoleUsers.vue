<template>
  <div style="display: inline">
    <chart-filter
        @change-filter="onChangeType"
        name="employee_type"
        label="Tipo de usuario"
        endpoint="chart/employees/types">
    </chart-filter>

    <div style="width: 300px; display: inline-block">
      <dropdown-with-checkbox
          @change="onChange"
          label="Usuarios"
          :items="users"
          :items-checked="[]"
          item-value="id"
          item-text="name">
      </dropdown-with-checkbox>
    </div>
  </div>
</template>

<script>
import ChartFilter from "./ChartFilter";
import DropdownWithCheckbox from "./form/DropdownWithCheckbox";

export default {
  components: {ChartFilter, DropdownWithCheckbox},
  data() {
    return {
      users: [],
      filters: {},
    }
  },
  mounted() {
    this.getUsers()
  },
  methods: {
    getUsers() {
      axios.get('chart/employees', {params: this.filters}).then((response) => {
        this.users = response.data.data
      })
    },
    onChange(payload) {
      this.$emit('change-filter', {filter: 'assessor_id', value: payload});
    },
    onChangeType(payload) {
      this.filters['type'] = payload.value
      this.getUsers()

      this.$emit('change-filter', {filter: 'role_id', value: payload.value});
    }
  }
}
</script>
