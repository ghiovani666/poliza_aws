<template>
  <div>
    <div class="card-title">
      {{ title }}
    </div>

    <div class="row mb-4">
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="year" label="Año" endpoint="chart/years"
            default-value="2021"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="company_id" label="Compañia"
            endpoint="chart/companies"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="sector" label="Ramo" endpoint="chart/sectors"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="product_id" label="Producto" endpoint="chart/products"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="sell_type" label="Tipo de venta"
            endpoint="chart/sell-types"></chart-filter>
      </div>
      <div class="col-2"></div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            name="employee_type"
            label="Tipo de usuario"
            endpoint="chart/employees/types">
        </chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
            multiple
            name="employee_id"
            label="Usuarios"
            endpoint="chart/employees">
        </chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>

    <canvas :id="name" height="50"></canvas>
  </div>
</template>

<script>
import ChartFilter from "./ChartFilter";
import ChartFilterRoleUsers from "./ChartFilterRoleUsers";
import ChartDataLabels from 'chartjs-plugin-datalabels';

export default {
  components: {ChartFilter, ChartFilterRoleUsers},
  props: ['name', 'title', 'type'],
  data() {
    return {
      Y2020: [],
      Y2019: [],
      NPEN: [],
      NUSD: [],
      filters: {},
    };
  },
  mounted() {
    // set type 5 --> post selling
    if (this.type === "5") {
      this.filters['field_date'] = 'cancellation_date';
      this.filters['operation_status'] = [8];
    }

    if (this.type === "1") {
      this.filters['year'] = 2021;
      this.filters['assessor_id'] = window.User.employee.id;
    }

    if (this.type === "8") {
      this.filters['year'] = 2021;
    }

    this.chart();
    this.getData();
  },
  created() {
    let ctx = this;
    this.$root.$on('apply-filter', function (payload) {
      ctx.filters[payload.filter] = payload.value;
      ctx.getData();
    });
  },
  methods: {
    getData() {
      let url = 'chart/policies/year';
      axios.get(url, {params: this.filters}).then((response) => {
        this.NPEN = response.data.data.count_a;
        this.NUSD = response.data.data.count_b;
        window['charYear' + this.name].data.datasets[0].data = this.Y2020 = response.data.data.a;
        window['charYear' + this.name].data.datasets[1].data = this.Y2019 = response.data.data.b;
        window['charYear' + this.name].update();
      });
    },
    chart() {
      let vue = this;
      let ctx = document.getElementById(this.name);
      window['charYear' + this.name] = new Chart(ctx, {
        plugins: [ChartDataLabels],
        type: 'bar',
        data: {
          labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'],
          datasets: [
            {
              label: 'PEN',
              data: [],
              backgroundColor: 'rgba(255, 206, 86, 0.2)',
              borderColor: 'rgba(255, 206, 86, 1)',
              borderWidth: 1
            },
            {
              label: 'USD',
              data: [],
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1
            }
          ]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          },
          plugins: {
            datalabels: {
              align: 'end',
              formatter: function (value, context) {
                let num_policies = 0;
                if (context.dataset.label === 'PEN') {
                  num_policies = vue.NPEN[context.dataIndex];
                }
                if (context.dataset.label === 'USD') {
                  num_policies = vue.NUSD[context.dataIndex];
                }
                return num_policies;
              },
              //rotation: -45,
            }
          }
        }
      });
    },
    onChangeFilter(payload) {
      this.filters[payload.filter] = payload.value;
    },
    onRemoveFilter(payload) {
      console.log(payload)
      delete this.filters[payload.filter]
    },
    onSearch() {
      this.getData()
    }
  }
}
</script>
