<template>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <!--<div class="h5">Comentarios</div>-->
                    <comment-form :id="id" :type="type"></comment-form>
                    <div class="container-fluid" style="">
                        <div v-if="!isLoading" v-for="comment in comments">
                            <hr>
                            <div class="row">
                                <div class="col-2 text-center" style="width: 100px">
                                    <div class="mb-2"><i class="fas fa-user-circle fa-2x"></i></div>
                                    <div class="mb-2">{{ comment.user.name }}</div>
                                </div>
                                <div class="col">
                                    <div class="mb-2" style="white-space: pre-wrap">{{ comment.body }}</div>
                                    <div class="mb-2" v-if="comment.meeting_date != null">Fecha y hora de la reunion: {{ parseDate(comment.meeting_date) }}</div>
                                    <div class="actions mb-2">
                                        <span v-for="action in  comment.actionsNamed" class="badge badge-secondary mr-2">
                                            {{ action.name }}
                                        </span>
                                    </div>
                                    <div v-if="comment.hasAttachment" class="attachments">
                                        <a target="_blank" :href="comment.attachmentUrl">Download</a>
                                    </div>
                                    <div class="text-muted">{{ comment.createdTimeAgo }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div v-if="isLoading" class="text-center">cargando...</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import CommentForm from "./CommentForm";
    import moment from "moment"

    export default {
        components: {CommentForm},
        props: ['id', 'type'],
        data() {
            return {
                isLoading: true,
                comments: [],
            };
        },
        created() {
            this.$root.$on('comment-new', () => {
                this.getComments();
            });
        },
        mounted() {
            this.getComments();
        },
        methods: {
            getComments() {
                this.isLoading = true;
                let url = 'comments';
                let config = {params: {source_id: this.id, source_type: this.type}};
                axios.get(url, config)
                    .then((response) => this.comments = response.data.data)
                    .catch()
                    .then(() => this.isLoading = false);
            },
            parseDate(date){
                return moment(date).format('DD/MM/YYYY hh:mm A')
            }
        }
    }
</script>
