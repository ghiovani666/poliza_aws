<template>
  <div>
    <div class="card-title">
      {{ label }}
    </div>

    <div class="row">
      <div class="col-2">
        <chart-filter @chage-filter="filter"
                      @remove-filter="onRemoveFilter"
                      name="year" label="Año" endpoint="chart/years"
                      default-value="2021"></chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>

    <table v-for="table in data" class="table table-striped table-striped-columns">
      <thead>
      <tr>
        <th style="width: 240px">{{ table.name }}</th>
        <th>Enero</th>
        <th>Febrero</th>
        <th>Marzo</th>
        <th>Abril</th>
        <th>Mayo</th>
        <th>Junio</th>
        <th>Julio</th>
        <th>Agosto</th>
        <th>Septiembre</th>
        <th>Octubre</th>
        <th>Noviembre</th>
        <th>Diciembre</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="row in table.rows">
        <td>{{ row.name }}</td>
        <td v-for="month in row.months">{{ month }}</td>
      </tr>
      </tbody>
    </table>

  </div>
</template>

<script>
import ChartFilter from './ChartFilter'

export default {
  components: {ChartFilter},
  props: {
    label: {type: String, required: false, default: 'Grafico 5'},
    ignoreGlobalFilters: {type: Boolean, required: false, default: false},
  },
  data() {
    return {
      data: {},
      filters: {
        year: 2021,
      },
    };
  },
  mounted() {
    this.getData();
  },
  created() {
    if (!this.ignoreGlobalFilters) {
      let ctx = this;
      this.$root.$on('apply-filter', function (payload) {
        ctx.filters[payload.filter] = payload.value;
        ctx.getData();
      });
    }
  },
  methods: {
    getData() {
      let url = 'chart/policies/groups-table';
      axios.get(url, {params: this.filters}).then((response) => {
        this.data = response.data.data;
      });
    },
    filter(payload) {
      console.log(payload)
      this.filters[payload.filter] = payload.value;
    },
    onSearch() {
      this.getData()
    },
    onRemoveFilter(payload) {
      delete this.filters[payload.filter]
    },
  }
}
</script>
