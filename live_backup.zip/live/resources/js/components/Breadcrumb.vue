<template>
    <nav class="d-inline-block align-middle" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li v-for="item in tree" :key="item.id" class="breadcrumb-item">
                <a :href="item.url">{{ item.label }}</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{ current }}</li>
        </ol>
    </nav>
</template>

<script>
    export default {
        props: ['tree', 'current']
    }
</script>
