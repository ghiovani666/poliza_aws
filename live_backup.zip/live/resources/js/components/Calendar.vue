<template>
    <div>
        <loading :active.sync="isLoading" :is-full-page="true" :z-index="9999"></loading>
        <FullCalendar
            defaultView="dayGridMonth"
            :header="{ left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'}"
            :plugins="calendarPlugins"
            :event-sources="eventSources"
            :locale="locale"
            @dateClick="handleDateClick"
            @eventClick="handleEventClick"
        />
        <!-- Modal Add Event -->
        <div class="modal fade" id="addEventModal" tabindex="-1" role="dialog" aria-labelledby="addEventModalTitle"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form id="frmAddEvent" @submit.prevent="onSubmit">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Agregar Cita</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group form-row">
                                <div class="col-3">Documento</div>
                                <div class="col">
                                    <div class="row no-gutters">
                                        <div class="col-4 mr-2">
                                            <select v-model="form.document_type" class="form-control">
                                                <option value="1">DNI</option>
                                                <option value="2">RUC</option>
                                                <option value="3">Pasaporte</option>
                                            </select>
                                        </div>
                                        <div class="col">
                                            <input v-model="form.document_number" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Nombre Cliente</div>
                                <div class="col">
                                    <input v-model="form.client_name" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Correo Cliente</div>
                                <div class="col">
                                    <input v-model="form.client_email" type="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Asunto</div>
                                <div class="col">
                                    <select v-model="form.subject" class="form-control">
                                        <option v-for="item in subjects" :value="item">{{ item }}</option>
                                    </select>
                                </div>
                            </div>
                            <div v-if="form.subject === 'Otro...'" class="form-group form-row">
                                <div class="col-3">Asunto (otro)</div>
                                <div class="col">
                                    <input v-model="form.subject2" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Fecha</div>
                                <div class="col">
                                    <input v-model="form.date" type="date" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Hora Inicio</div>
                                <div class="col">
                                    <input v-model="form.from" type="time" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Hora Fin</div>
                                <div class="col">
                                    <input v-model="form.to" type="time" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Comentarios</div>
                                <div class="col">
                                    <textarea v-model="form.comment" class="form-control" required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal Update Event -->
        <div class="modal fade" id="updateEventModal" tabindex="-1" role="dialog" aria-labelledby="addEventModalTitle"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form id="frmUpdateEvent" @submit.prevent="onSubmitUpdate">
                        <div class="modal-header">
                            <h5 class="modal-title">Actualizar Cita</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div v-if="$store.getters.isAdmin || $store.getters.isSupervisor"
                                 class="form-group form-row">
                                <div class="col-3">Usuario</div>
                                <div class="col">
                                    <input v-model="formUpdate.username" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Documento</div>
                                <div class="col">
                                    <div class="row no-gutters">
                                        <div class="col-4 mr-2">
                                            <select v-model="formUpdate.document_type" class="form-control">
                                                <option value="1">DNI</option>
                                                <option value="2">RUC</option>
                                                <option value="3">Pasaporte</option>
                                            </select>
                                        </div>
                                        <div class="col">
                                            <input v-model="formUpdate.document_number" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Nombre Cliente</div>
                                <div class="col">
                                    <input v-model="formUpdate.client_name" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Correo Cliente</div>
                                <div class="col">
                                    <input v-model="formUpdate.client_email" type="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Asunto</div>
                                <div class="col">
                                    <select v-model="formUpdate.subject" class="form-control">
                                        <option v-for="item in subjects" :value="item">{{ item }}</option>
                                    </select>
                                </div>
                            </div>
                            <div v-if="formUpdate.subject === 'Otro...'" class="form-group form-row">
                                <div class="col-3">Asunto (otro)</div>
                                <div class="col">
                                    <input v-model="formUpdate.subject2" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Fecha</div>
                                <div class="col">
                                    <input v-model="formUpdate.date" type="date" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Hora Inicio</div>
                                <div class="col">
                                    <input v-model="formUpdate.from" type="time" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Hora Fin</div>
                                <div class="col">
                                    <input v-model="formUpdate.to" type="time" class="form-control">
                                </div>
                            </div>
                            <div class="form-group form-row">
                                <div class="col-3">Comentarios</div>
                                <div class="col">
                                    <textarea v-model="formUpdate.comment" class="form-control" required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import FullCalendar from '@fullcalendar/vue'
    import dayGridPlugin from '@fullcalendar/daygrid'
    import timeGridPlugin from '@fullcalendar/timegrid'
    import interactionPlugin from '@fullcalendar/interaction'
    import esLocale from '@fullcalendar/core/locales/es';
    import * as moment from 'moment';
    import Loading from 'vue-loading-overlay';
    import 'vue-loading-overlay/dist/vue-loading.css';

    export default {
        components: {
            Loading,
            esLocale,
            FullCalendar // make the <FullCalendar> tag available
        },
        data() {
            return {
                isLoading: true,
                locale: 'es',
                calendarPlugins: [ // plugins must be defined in the JS
                    dayGridPlugin,
                    timeGridPlugin,
                    interactionPlugin // needed for dateClick
                ],
                eventSources: [
                    {
                        events: (fetchInfo, successCallback, failureCallback) => {
                            this.isLoading = true;
                            let data = {
                                params: {
                                    start: fetchInfo.start,
                                    end: fetchInfo.end
                                }
                            };
                            axios.get('calendar-lead-appointments', data).then((response) => {
                                successCallback(response.data);
                                //this.calendarEvents = response.data;
                            }).catch((error) => {

                            }).then(() => {
                                this.isLoading = false;
                            });
                        },
                        id: 'leads-appointments'
                    },
                ],
                calendarEvents: [],
                currentEvent: {},
                form: {
                    client_name: '',
                    client_email: '',
                    document_type: 1,
                    document_number: '',
                    subject: 'Cita',
                    subject2: '',
                    date: moment().format('YYYY-MM-DD'),
                    from: moment().format('HH:mm'),
                    to: moment().add(1, 'hour').format('HH:mm'),
                    comment: ''
                },
                formUpdate: {
                    username: '',
                    client_name: '',
                    client_email: '',
                    document_type: 1,
                    document_number: '',
                    subject: 'Primera cita',
                    subject2: '',
                    date: moment().format('YYYY-MM-DD'),
                    from: moment().format('HH:mm'),
                    to: moment().add(1, 'hour').format('HH:mm'),
                    comment: ''
                },
                subjects: [
                    'Llamada', 'Primera cita', 'Segunda cita', 'Cita de cierre', 'Entrega de políza', 'Visita de cobranza', 'Visita de servicio', 'Otro...'
                ]
            }
        },
        mounted() {
            //this.fetchEvents();
        },
        methods: {
            fetchEvents() {
                this.isLoading = true;
                axios.get('calendar').then((response) => {
                    this.calendarEvents = response.data;
                }).catch((error) => {

                }).then(() => {
                    this.isLoading = false;
                });

            },
            onSubmit() {
                this.isLoading = true;
                let data = this.form;
                axios.post('calendar', data).then(() => {
                    this.fetchEvents();
                }).catch().then(() => {
                    $('#addEventModal').modal('hide');
                    this.clean();
                    this.isLoading = false;
                });
            },
            onSubmitUpdate() {
                this.isLoading = true;
                let data = this.formUpdate;
                axios.put('calendar/' + this.currentEvent.id, data).then(() => {
                    this.fetchEvents();
                }).catch().then(() => {
                    $('#updateEventModal').modal('hide');
                    this.clean();
                    this.isLoading = false;
                });
            },
            clean() {
                $('#frmAddEvent').get(0).reset();

                this.form.client_name = '';
                this.form.client_email = '';
                this.form.document_number = '';
                this.form.document_type = 1;
                this.form.subject = 'Cita';
                this.form.date = moment().format('YYYY-MM-DD');
                this.form.from = moment().format('HH:mm');
                this.form.to = moment().add(1, 'hour').format('HH:mm');
                this.form.comment = '';
            },
            handleDateClick(arg) {
                this.form.date = moment(arg.date).format('YYYY-MM-DD');
                $('#addEventModal').modal('show');
            },
            handleEventClick(arg) {
                if (arg.event.source.id === 'leads') {
                    return;
                }

                this.isLoading = true;
                let id = arg.event.id;
                axios.get('calendar/' + id).then((response) => {
                    this.currentEvent = response.data.data;
                    this.formUpdate = {
                        username: response.data.data.user.name,
                        client_name: response.data.data.client_name,
                        client_email: response.data.data.client_email,
                        document_type: response.data.data.document_type,
                        document_number: response.data.data.document_number,
                        subject: response.data.data.subject,
                        subject2: response.data.data.subject2,
                        date: response.data.data.date,
                        from: response.data.data.from,
                        to: response.data.data.to,
                        comment: response.data.data.comment
                    };
                    $('#updateEventModal').modal('show');
                }).catch(() => {
                }).then(() => {
                    this.isLoading = false;
                });
            }
        }
    }

</script>

<style lang='scss'>
    @import '~@fullcalendar/core/main.css';
    @import '~@fullcalendar/daygrid/main.css';
    @import '~@fullcalendar/timegrid/main.css';
</style>
