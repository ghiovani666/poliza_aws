<template>
    <div class="d-inline">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#importPayingModal">
            <i class="fas fa-upload"></i>
        </button>

        <!-- Modal -->
        <div class="modal fade" id="importPayingModal" tabindex="-1" role="dialog"
             aria-labelledby="importPayingModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form @submit.prevent="onSubmit">
                        <div class="modal-header">
                            <h5 class="modal-title" id="importPayingModalLabel">Importar liquidaciones</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">Descarga la siguiente <a href="/MorganPlantillaLiquidaciones.csv"
                                                                       target="_blank">plantilla</a>, llena los campos y
                                sube el archivo para
                                ser importado.
                            </div>
                            <div class="form-group form-row">
                                <div class="col-4">Archivo</div>
                                <div class="col">
                                    <input type="file" id="file" ref="file" v-on:change="onChangeFileUpload()"/>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Importar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- loading -->
        <loading :active.sync="isLoading" :is-full-page="true" :z-index="9999"></loading>
    </div>
</template>

<script>
    import Loading from 'vue-loading-overlay';
    import 'vue-loading-overlay/dist/vue-loading.css';

    export default {
        components: {Loading},
        data() {
            return {
                isLoading: false,
                form: {
                    company: '',
                    file: '',
                },
                companies: []
            };
        },
        methods: {
            onChangeFileUpload() {
                this.file = this.$refs.file.files[0];
            },
            onSubmit() {
                this.isLoading = true;
                let settings = {headers: {'Content-Type': 'multipart/form-data'}};

                let formData = new FormData();
                formData.append('file', this.file);

                axios.post('payings/import', formData, settings).then((response) => {
                    $('#importPayingModal').modal('hide');
                    this.form.company = '';
                }).catch(() => {

                }).then(() => {
                    this.isLoading = false;
                    window.location.reload();
                });
            }
        }
    }
</script>
