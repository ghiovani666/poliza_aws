<template>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-6">
                    <div class="h5">Key</div>
                    <div class="form-row form-group">
                        <label class="col-4 col-form-label">Compañia</label>
                        <div class="col">
                            <div class="d-inline-block" style="width: calc(100% - 90px)">
                                <select name="company_id" class="form-control" placeholder="- Seleccionar -">
                                    <option v-for="company in companies" :key="company.id" :value="company.id">{{
                                        company.name }}
                                    </option>
                                </select>
                            </div>
                            <div class="d-inline-block">
                                <button class="btn btn-secondary"><i class="fas fa-plus"></i></button>
                                <button class="btn btn-secondary"><i class="fas fa-edit"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-4 col-form-label">Ramo</label>
                        <div class="col">
                            <select name="sector_id" class="form-control"></select>
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-4 col-form-label">Producto</label>
                        <div class="col">
                            <input v-model="form.name" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-4 col-form-label">Comision Morgan</label>
                        <div class="col">
                            <input v-model="form.commission" type="text" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="col-6"></div>
            </div>
            <hr>
            <div class="row">
                <div class="col">
                    <button class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['id', 'name', 'commission', 'companyId', 'sectorId'],
        data() {
            return {
                form: {
                    companyId: this.companyId,
                    sectorId: this.sectorId,
                    name: this.name,
                    commission: this.commission,
                },
                companies: [],
            };
        },
        mounted() {
            this.fetchCompanies();

            $('select[name=company_id]').select2();
            $('select[name=sector_id]').select2();
        },
        methods: {
            fetchCompanies() {
                axios.get('/api/companies').then((response) => {
                    this.companies = response.data.data;
                });
            }
        }
    }
</script>
