<template>
  <div>
    <div class="row mb-4">
      <div class="col-2">
        <chart-filter
            v-if="filterYearEnabled"
            :batch="batch"
            name="year"
            label="Año"
            endpoint="chart/years"
            :is-global="false"
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
        ></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            v-if="filterCompanyEnabled"
            :batch="batch"
            name="company_id"
            label="Compañia"
            endpoint="chart/companies"
            :is-global="false"
            @change-filter="onChangeFilter"
            @remove-filter="onRemoveFilter"
        ></chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>
    <table class="table table-bordered" style="font-size: 0.8rem">
      <thead style="font-size: 1rem">
      <tr>
        <th></th>
        <th colspan="2" class="text-center">STOCK ACUMULADO</th>
        <th colspan="3" class="text-center">MES ACTUAL: {{ current_month }}</th>
      </tr>
      </thead>
      <tbody>
      <tr>
        <th>S/ PEN</th>
        <td>
          <div class=""><i class="fas fa-edit"></i> {{ pen.stock_num_policies }} Pólizas totales</div>
        </td>
        <td>
          <div><i class="fas fa-money-bill"></i> S/ {{ pen.stock_total }}</div>
        </td>
        <td>
          <div><i class="fas fa-edit"></i> {{ pen.month_sell }} Pólizas vendidas</div>
        </td>
        <td>
          <div><i class="fas fa-user-check"></i> {{ pen.month_agent }} Agenciamientos</div>
        </td>
        <td>
          <div><i class="fas fa-ban"></i> {{ pen.month_cancel }} Pólizas anuladas</div>
        </td>
      </tr>
      <tr>
        <th>$ USD</th>
        <td>
          <div class=""><i class="fas fa-edit"></i> {{ usd.stock_num_policies }} Pólizas totales</div>
        </td>
        <td>
          <div><i class="fas fa-money-bill"></i> $ {{ usd.stock_total }}</div>
        </td>
        <td>
          <div class=""><i class="fas fa-edit"></i> {{ usd.month_sell }} Pólizas vendidas</div>
        </td>
        <td>
          <div><i class="fas fa-user-check"></i> {{ usd.month_agent }} Agenciamientos</div>
        </td>
        <td>
          <div><i class="fas fa-ban"></i> {{ usd.month_cancel }} Pólizas anuladas</div>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import ChartFilter from "./ChartFilter";

export default {
  components: {ChartFilter},
  props: {
    type: {type: Number, default: 8, required: false},
    filterYearEnabled: {type: Boolean, default: false, required: false},
    filterCompanyEnabled: {type: Boolean, default: false, required: false},
  },
  data() {
    return {
      batch: Math.random().toString(32).substring(2),
      filters: {
        year: '',
      },
      defaultFilters: {
        year: '',
      },
      current_month: '',
      pen: {
        stock_total: 0,
        stock_num_policies: 0,
        month_sell: 0,
        month_agent: 0,
        month_cancel: 0
      },
      usd: {
        stock_total: 0,
        stock_num_policies: 0,
        month_sell: 0,
        month_agent: 0,
        month_cancel: 0
      },
    };
  },
  mounted() {
    //this.filters = this.defaultFilters
    this.getData();
  },
  methods: {
    getData() {
      let url = 'chart/policies/stock-table';
      let config = {params: this.filters};
      axios.get(url, config).then((response) => {
        this.current_month = response.data.data.current_month;
        this.pen = response.data.data.pen;
        this.usd = response.data.data.usd;
      });
    },
    onChangeFilter(payload) {
      this.filters[payload.filter] = payload.value;
    },
    onSearch() {
      this.getData()
    },
    onReset() {
      this.$root.$emit('batch-reset', this.batch)
      this.filters = this.defaultFilters
      this.getData()
    },
    onRemoveFilter(payload) {
      console.log(payload)
      delete this.filters[payload.filter]
    },
  }
}
</script>
