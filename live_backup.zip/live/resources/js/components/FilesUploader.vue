<template>
    <div class="card">
        <div class="card-body">
            <div class="d-flex flex-column" style="gap: 5px;">
                <div v-for="(file) in files" class="mr-2 d-flex align-items-center badge badge-light">
                    <a :href="file.path" :download="file.name">{{ file.name }}</a>
                    <button @click="onClickRemoveFile($event, file.id)" type="button" class="pb-1 ml-1 close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
            </div>
            <div class="mt-3">
                <label class="btn btn-link">
                    <i class="fa-solid fa-plus"></i> Agregar
                    <input id="input-file" @change="onChangeFile" name="files[]" type="file" multiple hidden>
                </label>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                files: []
            }
        },
        props: ['initialfiles', 'target', 'mode', 'entityid'],
        mounted() {
            this.files.push(...this.initialfiles);
        },
        methods: {
            onChangeFile(evt) {
                if (this.mode == "create") {
                    for (const file of evt.target.files) {
                        this.files.push({
                            id: crypto.randomUUID ? crypto.randomUUID() : (Date.now() + Math.random()).toString(),
                            name: file.name,
                            path: URL.createObjectURL(file)
                        });
                    }
                } else {
                    const formData = new FormData();
                    formData.append("target", this.target);
                    formData.append("entity_id", this.entityid);
                    for (const file of evt.target.files) {
                        formData.append("files[]", file);
                    }
                    axios.post('/policies/files/upload', formData).then((rsp) => {
                        this.files.push(...rsp.data);
                    });
                }
            },
            onClickRemoveFile(evt, i) {
                return;
                if (this.mode == "create") {
                    document.getElementById("input-file").files
                } else {
                    axios.post('/policies/files/upload', formData).then((rsp) => {
                        this.files.findIndex(f => f.id == i);
                        this.files.splice(0);
                    });
                }
            }
        }
    }
</script>
