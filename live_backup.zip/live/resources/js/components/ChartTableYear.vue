<template>
  <div>
    <div class="card-title">
      Grafico 4
    </div>

    <div class="row">
      <div class="col-2">
        <chart-filter @change-filter="filter"
                      @remove-filter="onRemoveFilter"
                      name="year" label="Año" endpoint="chart/years"
                      default-value="2021"></chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>

    <table class="table table-striped table-striped-columns">
      <thead>
      <tr>
        <th>Periodo</th>
        <th>Enero</th>
        <th>Febrero</th>
        <th>Marzo</th>
        <th>Abril</th>
        <th>Mayo</th>
        <th>Junio</th>
        <th>Julio</th>
        <th>Agosto</th>
        <th>Septiembre</th>
        <th>Octubre</th>
        <th>Noviembre</th>
        <th>Diciembre</th>
      </tr>
      </thead>
      <tbody>
      <template v-for="data in data">
        <tr>
          <th colspan="13">{{ data.year }}</th>
        </tr>
        <template v-for="currency in data.currencies">
          <tr>
            <th colspan="13">---- {{ currency.currency }}</th>
          </tr>
          <template v-for="sector in currency.sectors">
            <tr>
              <td>-------- {{ sector.sector }}</td>
              <td v-for="month in sector.months" class="text-right">{{ month }}</td>
            </tr>
          </template>
        </template>
      </template>
      </tbody>
    </table>
  </div>
</template>

<script>
import ChartFilter from './ChartFilter'

export default {
  components: {ChartFilter},
  props: ['currency'],
  data() {
    return {
      data: [],
      filters: {},
    };
  },
  mounted() {
    this.getData();
  },
  created() {
    let ctx = this;
    this.$root.$on('apply-filter', function (payload) {
      ctx.filters[payload.filter] = payload.value;
      ctx.getData();
    });
  },
  methods: {
    getData() {
      let url = 'chart/policies/stair';
      axios.get(url, {params: this.filters}).then((response) => {
        this.data = response.data.data;
      });
    },
    filter(payload) {
      this.filters[payload.filter] = payload.value;
    },
    onSearch() {
      this.getData();
    },
    onRemoveFilter(payload) {
      delete this.filters[payload.filter]
    },
  }
}
</script>
