<template>
  <div>
    <div class="card-title">
      {{ label }}
    </div>

    <div class="row">
      <div class="col-2">
        <chart-filter @change-filter="filter"
                      @remove-filter="onRemoveFilter"
                      name="currency" label="Moneda" endpoint="chart/currencies"
                      default-value="PEN"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter @change-filter="filter"
                      @remove-filter="onRemoveFilter"
                      name="year" label="Año" endpoint="chart/years"
                      default-value="2021"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter @change-filter="filter"
                      @remove-filter="onRemoveFilter"
                      name="type" label="Tipo" endpoint="chart/top-types"
                      default-value="2"></chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>

    <table class="table table-striped table-striped-columns">
      <thead>
      <tr>
        <th></th>
        <th>Enero</th>
        <th>Febrero</th>
        <th>Marzo</th>
        <th>Abril</th>
        <th>Mayo</th>
        <th>Junio</th>
        <th>Julio</th>
        <th>Agosto</th>
        <th>Septiembre</th>
        <th>Octubre</th>
        <th>Noviembre</th>
        <th>Diciembre</th>
        <th class="text-right">Total</th>
      </tr>
      </thead>
      <tbody>
      <template v-for="data in data">
        <tr>
          <td>{{ data.name }}</td>
          <td v-for="month in data.rows.months">{{ month }}</td>
          <td class="text-right">{{ data.rows.total }}</td>
        </tr>
      </template>
      </tbody>
    </table>
  </div>
</template>

<script>
import ChartFilter from './ChartFilter'

export default {
  components: {ChartFilter},
  props: {
    label: {type: String, required: false, default: 'Grafico 2 - Distribucion'},
    ignoreGlobalFilters: {type: Boolean, required: false, default: false},
  },
  data() {
    return {
      data: {},
      filters: {
        currency: 'PEN',
        year: 2021,
        type: 2,
      },
    };
  },
  mounted() {
    this.getData();
  },
  created() {
    if (!this.ignoreGlobalFilters) {
      let ctx = this;
      this.$root.$on('apply-filter', function (payload) {
        ctx.filters[payload.filter] = payload.value;
        ctx.getData();
      });
    }
  },
  methods: {
    getData() {
      let url = 'chart/policies/status';
      axios.get(url, {params: this.filters}).then((response) => {
        this.data = response.data.data;
      });
    },
    filter(payload) {
      this.filters[payload.filter] = payload.value;
    },
    onSearch() {
      this.getData()
    },
    onRemoveFilter(payload) {
      delete this.filters[payload.filter]
    },
  }
}
</script>
