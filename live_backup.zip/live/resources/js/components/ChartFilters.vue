<template>
    <div>
        <chart-filter v-if="withYear" name="year" label="Año" endpoint="chart/years"
                      default-value="2021"></chart-filter>

        <chart-filter v-if="withCompany" name="company_id" label="Compañia" endpoint="chart/companies"></chart-filter>

        <chart-filter v-if="withSector" name="sector" label="Ramo" endpoint="chart/sectors"></chart-filter>

        <chart-filter v-if="withProduct" name="product" label="Producto" endpoint="chart/products"></chart-filter>

        <chart-filter v-if="withSellType" name="sell_type" label="Tipo de venta"
                      endpoint="chart/sell-types"></chart-filter>

        <chart-filter v-if="withEmployeeType" name="employee_type" label="Tipo de usuario"
                      endpoint="chart/employees/types"
                      @change-filter="updateEmployees"
        ></chart-filter>

        <chart-filter v-if="withAssessor" name="employee_id" label="Usuarios" endpoint="chart/employees"></chart-filter>
    </div>
</template>

<script>
import ChartFilter from './ChartFilter'

export default {
    components: {ChartFilter},
    props: {
        withYear: {type: Boolean, required: false, default: true},
        withCompany: {type: Boolean, required: false, default: true},
        withSector: {type: Boolean, required: false, default: true},
        withProduct: {type: Boolean, required: false, default: true},
        withSellType: {type: Boolean, required: false, default: true},
        withEmployeeType: {type: Boolean, required: false, default: true},
        withAssessor: {type: Boolean, required: false, default: true},
    },
    data() {
        return {
            employeesEndPoint: 'chart/employees'
        }
    },
    methods: {
        updateEmployees(payload) {
            let roleId = payload.value
            this.$root.$emit('update-employees', roleId)
        }
    }
}
</script>
