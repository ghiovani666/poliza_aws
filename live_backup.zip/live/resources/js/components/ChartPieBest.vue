<template>
    <div>
        {{ this.title }} {{ this.year }}
        <canvas :id="canvasId" height="150"></canvas>
    </div>
</template>

<script>
    export default {
        props: ['year', 'currency', 'title', 'company', 'sector', 'product'],
        data() {
            return {labels: [], values: []};
        },
        mounted() {
            this.getData();
        }
        ,
        computed: {
            canvasId() {
                return 'chartPie' + this.year + this.currency;
            }
        }
        ,
        methods: {
            getData() {
                let url = 'chart/policies/best?year=' + this.year + '&currency=' + this.currency + '&company=' + this.company + '&sector=' + this.sector + '&product=' + this.product;
                axios.get(url).then((response) => {
                    this.labels = response.data.data.labels;
                    this.values = response.data.data.values;
                    this.chart();
                });
            }
            ,
            chart() {
                var ctx = document.getElementById(this.canvasId);
                var myChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: this.labels,
                        datasets: [{
                            label: 'My First dataset',
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            data: this.values,
                        }]
                    },
                    options: {
                        legend: {display: true, position: 'bottom'}
                    }
                });
            }
        }
    }
</script>
