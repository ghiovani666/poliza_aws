<template>
  <div class="mb-2">
    <multiselect
        v-model="value"
        :options="options"
        :show-labels="false"
        :placeholder="label"
        label="name"
        track-by="id"
        :allow-empty="true"
        @select="onChange"
        @close="onClose"
        @remove="onRemove"
        :multiple="multiple"
        :close-on-select="!multiple"
        :clear-on-select="!multiple"
    >
      <template v-if="multiple" slot="selection" slot-scope="{ values, search, isOpen }">
        <span class="multiselect__single" v-if="values.length && !isOpen">
          {{ values.length }} selecionados
        </span>
      </template>
    </multiselect>
  </div>
</template>

<script>
export default {
  props: {
    batch: {type: String, required: false},
    name: {type: String, required: true},
    endpoint: {type: String, required: true},
    label: {type: String, required: true},
    isGlobal: {type: Boolean, required: false, default: false},
    defaultValue: {required: false, default: ''},
    multiple: {type: Boolean, required: false, default: false}
  },
  data() {
    return {
      value: '',
      options: [],
      filters: {},
    };
  },
  created() {
    this.$root.$on('batch-reset', (batch) => {
      if (this.batch === batch) {
        this.value = this.defaultValue === '' ? '' : this.options.find((items) => parseInt(this.defaultValue) === items.id)
      }
    })
    this.$root.$on('update-employees', (payload) => {
      if (this.name === 'employee_id') {
        this.filters['type'] = payload
        this.getOptions()
      }
    })
  },
  mounted() {
    this.getOptions();
  },
  methods: {
    getOptions() {
      axios.get(this.endpoint, {params: this.filters}).then((response) => {
        this.options = response.data.data;
        this.loadDefaultValue()
      }).catch((error) => {

      });
    },
    onChange(payload) {
      if (!this.multiple) {
        this.$emit('change-filter', {filter: this.name, value: payload.id});
      }

      if (this.name === 'employee_type') {
        this.$root.$emit('update-employees', payload.id);
      }
    },
    loadDefaultValue() {
      if (this.defaultValue !== '') {
        this.value = this.options.find((items) => {
          return parseInt(this.defaultValue) === items.id
        })
      }
    },
    onClose(payload) {
      if (this.multiple) {
        let values = payload.map(function (obj) {
          return obj.id;
        });
        this.$emit('change-filter', {filter: this.name, value: values});
      }

      return '';
    },
    onRemove(payload) {
      this.$emit('remove-filter', {filter: this.name, value: payload.id});
    }
  }
}
</script>
