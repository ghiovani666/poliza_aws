<template>
    <div>
        <div class="card-title">
            {{ title }}
        </div>
        <canvas :id="name" height="50"></canvas>
    </div>
</template>

<script>
    import ChartDataLabels from 'chartjs-plugin-datalabels';

    export default {
        props: ['name', 'title', 'type', 'currency'],
        data() {
            return {
                counters: {},
                filters: {},
            };
        },
        mounted() {
            this.chart();
            this.getData();
        },
        created() {
            let ctx = this;
            this.$root.$on('apply-filter', function (payload) {
                ctx.filters[payload.filter] = payload.value;
                ctx.getData();
            });
        },
        methods: {
            getData() {
                let url = 'chart/policies/year-stack';
                axios.get(url, {params: this.filters}).then((response) => {
                    if (this.currency === 'PEN') {
                        window['charYear' + this.name].data.datasets[0].data = response.data.status5_pen_sum;
                        window['charYear' + this.name].data.datasets[1].data = response.data.status6_pen_sum;
                        window['charYear' + this.name].data.datasets[0].counters = response.data.status5_pen_counter;
                        window['charYear' + this.name].data.datasets[1].counters = response.data.status6_pen_counter;
                    }
                    if (this.currency === 'USD') {
                        window['charYear' + this.name].data.datasets[0].data = response.data.status5_usd_sum;
                        window['charYear' + this.name].data.datasets[1].data = response.data.status6_usd_sum;
                        window['charYear' + this.name].data.datasets[0].counters = response.data.status5_usd_counter;
                        window['charYear' + this.name].data.datasets[1].counters = response.data.status6_usd_counter;
                    }

                    window['charYear' + this.name].update();
                });
            },
            chart() {
                let vue = this;
                let ctx = document.getElementById(this.name);
                window['charYear' + this.name] = new Chart(ctx, {
                    plugins: [ChartDataLabels],
                    type: 'bar',
                    data: {
                        labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                        datasets: [
                            {
                                stack: 'stack01',
                                label: 'Renovados ' + vue.currency,
                                data: [],
                                backgroundColor: vue.currency === 'PEN' ? '#ffe5a7' : '#90ecec',
                                borderColor: vue.currency === 'PEN' ? '#fcc12c' : '#34d6d6',
                                borderWidth: 1,
                                minBarLength: 30,
                            },
                            {
                                stack: 'stack01',
                                label: 'En Renovacion ' + vue.currency,
                                data: [],
                                backgroundColor: vue.currency === 'PEN' ? 'rgba(255, 206, 86, 0.2)' : 'rgba(75, 192, 192, 0.2)',
                                borderColor: vue.currency === 'PEN' ? 'rgba(255, 206, 86, 1)' : 'rgba(75, 192, 192, 1)',
                                borderWidth: 1,
                                minBarLength: 60,
                            },
                            /*
                            {
                                stack: 'stack02',
                                label: 'Renovados USD',
                                data: [],
                                backgroundColor: '#90ecec',
                                borderColor: '#34d6d6',
                                borderWidth: 1
                            },
                            {
                                stack: 'stack02',
                                label: 'En Renovacion USD',
                                data: [],
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                borderColor: 'rgba(75, 192, 192, 1)',
                                borderWidth: 1
                            }
                             */
                        ]
                    },
                    options: {
                        tooltips: {
                            enabled: true,
                            callbacks: {
                                label: function (tooltip, data) {
                                    let total = tooltip.value;
                                    let locale = vue.currency === 'PEN' ? 'es-PE' : 'en-US';
                                    let formatter = new Intl.NumberFormat(locale, {
                                        style: 'currency',
                                        currency: vue.currency,
                                    });

                                    return [
                                        data.datasets[tooltip.datasetIndex].label,
                                        formatter.format(total),
                                        data.datasets[tooltip.datasetIndex].counters[tooltip.index] + ' polizas',
                                    ];
                                }
                            }
                        },
                        scales: {
                            xAxes: [{
                                stacked: true,
                            }],
                            yAxes: [{
                                stacked: true,
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        },
                        plugins: {
                            datalabels: {
                                align: 'start',
                                clap: true,
                                anchor: 'end',
                                formatter: function (value, context) {
                                    let total = value;
                                    let locale = vue.currency === 'PEN' ? 'es-PE' : 'en-US';
                                    let formatter = new Intl.NumberFormat(locale, {
                                        style: 'currency',
                                        currency: vue.currency,
                                    });

                                    return total === 0 ? '' : formatter.format(total);
                                },
                                //rotation: -45,
                            }
                        }
                    }
                });
            }
        }
    }
</script>
