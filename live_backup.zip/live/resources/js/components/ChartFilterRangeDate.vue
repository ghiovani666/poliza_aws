<template>
    <div class="mr-3" style="display: inline-block">
        <span class="mr-2">{{ label }}</span>
        <date-range-picker
            ref="picker"
            v-model="value"
            opens="right"
            :autoApply="true"
            :ranges="localeRanges"
            @update="onChange"
        >
        </date-range-picker>
        <div v-if="displayCleanFilter" class="clear mr-1" title="limpiar filtro">
            <i @click="onClean" class="fas fa-times"></i>
        </div>
    </div>
</template>

<script>
    import DateRangePicker from 'vue2-daterange-picker'
    import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
    import moment from 'moment'

    export default {
        components: {DateRangePicker},
        props: {
            name: {type: String, required: true},
            endpoint: {type: String, required: true},
            label: {type: String, required: true},
            isGlobal: {type: Boolean, required: false, default: true},
            defaultValue: {type: String, required: false, default: ''}
        },
        data() {
            return {
                value: {
                    startDate: null,
                    endDate: null
                },
                displayCleanFilter: false,
            };
        },
        computed: {
            localeRanges() {
                return {
                    'Hoy': [moment().toDate(), moment().toDate()],
                    'Ayer': [moment().subtract(1, 'days').toDate(), moment().subtract(1, 'days').toDate()],
                    'Los últimos 7 días': [moment().subtract(6, 'days').toDate(), moment().toDate()],
                    'Los últimos 30 días': [moment().subtract(29, 'days').toDate(), moment().toDate()],
                    'Este mes': [moment().startOf('month').toDate(), moment().endOf('month').toDate()],
                    'El mes pasado': [moment().subtract(1, 'month').startOf('month').toDate(), moment().subtract(1, 'month').endOf('month').toDate()]
                }
            }
        },
        mounted() {
            // default
            if (this.defaultValue !== '') {
                this.value = this.defaultValue;
            }
        },
        methods: {
            onChange() {
                this.displayCleanFilter = true;
                let value = moment(this.value.startDate).startOf('day').format() + ' - ' + moment(this.value.endDate).endOf('day').format();
                if (this.isGlobal) {
                    this.$root.$emit('apply-filter', {filter: this.name, value: value});
                } else {
                    this.$emit('change-filter', {filter: this.name, value: value});
                }
            },
            onClean() {
                this.value.startDate = null;
                this.value.endDate = null;
                this.$root.$emit('remove-filter', {filter: this.name});
                this.displayCleanFilter = false;
            }
        }
    }
</script>
<style lang="scss">
    .daterangepicker {
        top: 30px;
    }

    .vue-daterange-picker {
        min-width: 180px !important;
    }

    .clear {
        display: inline;
        cursor: pointer;
    }
</style>
