<template>
    <div>
        <textarea v-model="message" class="form-control mb-2" placeholder="Añade un comentario aqui..."
                  rows="5"></textarea>
        <div class="row mt-2">
            <div class="col-2">
                <button @click="onSubmit" class="btn btn-primary btn-block">
                    <i class="fas fa-save mr-2"></i>
                    Enviar
                </button>
            </div>
            <div class="col">
                <!--
                <input v-if="!isUploading" type="file" id="file" ref="file" @change="handleFileUpload">
                -->
                <progress v-if="isUploading" max="100" :value.prop="uploadPercentage"></progress>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['id', 'type'],
    data() {
        return {
            isUploading: false,
            file: '',
            uploadPercentage: 0,
            message: '',
            checkedActions: [],
            actions: [],
            notify: false,
            meeting_date: '',
            meeting_time: '',
        };
    },
    computed: {
        isAssessor() {
            //return window.User.employee.type === 1;
            return false;
        },
        isMeetingOneChecked() {
            return this.checkedActions.includes(4) || this.checkedActions.includes(5) || this.checkedActions.includes(6);
        }
    },
    created() {
        this.$root.$on('comment-new', () => {
            this.getActions();
        });
    },
    mounted() {

    },
    methods: {
        handleFileUpload() {
            this.file = this.$refs.file.files[0];
        },
        onSubmit() {
            this.isUploading = true;
            /*
              Initialize the form data
            */
            let formData = new FormData();

            /*
              Add the form data we need to submit
            */
            formData.append('file', this.file);
            formData.append('message', this.message);
            formData.append('source_id', this.id);
            formData.append('source_type', this.type);
            /*
              Make the request to the POST /single-file URL
            */
            axios.post('/comments',
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    },
                    onUploadProgress: function (progressEvent) {
                        this.uploadPercentage = parseInt(Math.round((progressEvent.loaded * 100) / progressEvent.total));
                    }.bind(this)
                }
            ).then((response) => {
                this.message = '';
                this.checkedActions = [];
                this.$root.$emit('comment-new');
            }).catch(function (error) {
                console.log(error);
            }).then(() => this.isUploading = false);
        },
    }
}
</script>
