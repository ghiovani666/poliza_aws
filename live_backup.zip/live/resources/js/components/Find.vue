<template>
    <div class="d-inline">
        <b-button v-b-modal.findModal variant="outline-secondary"><i class="fas fa-search"></i></b-button>
        <b-modal id="findModal" title="Buscar Cliente">
            <b-table striped hover :items="items" :fields="fields">
                <template slot="[actions]" slot-scope="row">
                    <b-button @click="select(row.item)" size="sm" class="">Seleccionar</b-button>
                </template>
            </b-table>
        </b-modal>
    </div>
</template>

<script>
    export default {
        props: ['search'],
        data() {
            return {
                items: [],
                fields: [
                    {key: 'id', label: 'ID'},
                    {key: 'name', label: 'Nombre'},
                    {key: 'dni_ruc', label: 'DNI / RUC'},
                    {key: 'email', label: 'Correo'},
                    {key: 'phone', label: 'Teléfono'},
                    {key: 'actions', label: ''},
                ],
            };
        },
        mounted() {
            this.fetch();
        },
        methods: {
            fetch() {
                let url = '/api/customers';
                let config = {params: {search: this.search}};
                axios.get(url, config).then((response) => {
                    this.items = response.data.data;
                }).catch().then();
            },
            select(item) {
                this.$root.$emit('customer-selected', item);
                this.$bvModal.hide('findModal');
            }
        }
    }
</script>
