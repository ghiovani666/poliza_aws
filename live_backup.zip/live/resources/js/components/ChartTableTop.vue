<template>
  <div>
    <div class="card-title">
      {{ label }} {{ currency }}
    </div>

    <div class="row">
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            default-value="2" name="type" label="Tipo"
            endpoint="chart/top-types"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            name="company_id" label="Compañia"
            endpoint="chart/companies"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            name="sector" label="Ramo" endpoint="chart/sectors"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            name="product_id" label="Producto" endpoint="chart/products"></chart-filter>
      </div>
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            name="sell_type" label="Tipo de venta"
            endpoint="chart/sell-types"></chart-filter>
      </div>
      <div class="col-2"></div>
      <div class="col-2">
        <chart-filter
            @change-filter="filter"
            @remove-filter="onRemoveFilter"
            multiple
            name="employee_id"
            label="Usuarios"
            endpoint="chart/employees?type=12">
        </chart-filter>
      </div>
      <div class="col-2">
        <button @click="onSearch" class="btn btn-primary btn-lg btn-block">
          <i class="fas fa-filter"></i>
          APLICAR FILTROS
        </button>
      </div>
    </div>

    <div v-for="item in data" class="mt-3">
      <p class="font-weight-bold">{{ item.supervisor }}</p>
      <table class="table table-striped table-striped-columns">
        <thead>
        <tr>
          <th style="width: 240px">Nombre</th>
          <th>Enero</th>
          <th>Febrero</th>
          <th>Marzo</th>
          <th>Abril</th>
          <th>Mayo</th>
          <th>Junio</th>
          <th>Julio</th>
          <th>Agosto</th>
          <th>Septiembre</th>
          <th>Octubre</th>
          <th>Noviembre</th>
          <th>Diciembre</th>
          <th class="text-right">Total</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="user in item.top">
          <td>{{ user.name }}</td>
          <td>{{ user.month1 }}</td>
          <td>{{ user.month2 }}</td>
          <td>{{ user.month3 }}</td>
          <td>{{ user.month4 }}</td>
          <td>{{ user.month5 }}</td>
          <td>{{ user.month6 }}</td>
          <td>{{ user.month7 }}</td>
          <td>{{ user.month8 }}</td>
          <td>{{ user.month9 }}</td>
          <td>{{ user.month10 }}</td>
          <td>{{ user.month11 }}</td>
          <td>{{ user.month12 }}</td>
          <td class="text-right">{{ user.total }}</td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import ChartFilter from './ChartFilter'

export default {
  components: {ChartFilter},
  props: {
    currency: {type: String, required: true},
    label: {type: String, required: false, default: 'Grafico 3 - Top 10'},
    ignoreGlobalFilters: {type: Boolean, required: false, default: false},
  },
  data() {
    return {
      data: {},
      filters: {
        currency: this.currency,
        year: 2021,
        type: 2,
      },
    };
  },
  mounted() {
    this.getData();
  },
  created() {
    if (!this.ignoreGlobalFilters) {
      let ctx = this;
      this.$root.$on('apply-filter', function (payload) {
        ctx.filters[payload.filter] = payload.value;
        ctx.getData();
      });
    }
  },
  methods: {
    getData() {
      let url = 'chart/policies/top';
      axios.get(url, {params: this.filters}).then((response) => {
        this.data = response.data.data;
      });
    },
    filter(payload) {
      this.filters[payload.filter] = payload.value;
    },
    onSearch() {
      this.getData()
    },
    onRemoveFilter(payload) {
      console.log(payload)
      delete this.filters[payload.filter]
    },
  }
}
</script>
