<template>
    <div>
        <div class="card-title">
            Stock
            <i class="far fa-question-circle" title="El stock es la suma de polizas en estado emitido y renovado"></i>
        </div>
        <div>
            <span class="mr-3">Año:</span>
            <select v-model="year" @change="onChange">
                <option v-for="year in years" :key="year" :value="year" v-text="year"></option>
            </select>
        </div>
        <canvas id="stock" height="50"></canvas>
    </div>
</template>

<script>
    import Chart from 'chart.js';
    import ChartDataLabels from 'chartjs-plugin-datalabels';

    export default {
        data() {
            return {
                year: 2020,
                Y2020: [],
                Y2019: [],
                NPEN: [],
                NUSD: [],
            };
        },
        mounted() {
            this.chart();
            this.getData();
        }
        ,
        computed: {
            years() {
                return [2015, 2016, 2017, 2018, 2019, 2020].reverse();
            }
        }
        ,
        methods: {
            getData() {
                let url = 'chart/policies/stock?year=' + this.year;
                axios.get(url).then((response) => {
                    this.NPEN = response.data.data.x;
                    this.NUSD = response.data.data.y;
                    window.chart.data.datasets[0].data = this.Y2020 = response.data.data.a;
                    window.chart.data.datasets[1].data = this.Y2019 = response.data.data.b;
                    window.chart.update();
                });
            },
            chart() {
                let vue = this;
                let ctx = document.getElementById('stock');
                window.chart = new Chart(ctx, {
                    plugins: [ChartDataLabels],
                    type: 'bar',
                    data: {
                        labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                        datasets: [
                            {
                                label: 'PEN',
                                data: this.Y2020,
                                backgroundColor: 'rgba(255, 206, 86, 0.2)',
                                borderColor: 'rgba(255, 206, 86, 1)',
                                borderWidth: 1
                            },
                            {
                                label: 'USD',
                                data: this.Y2019,
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                borderColor: 'rgba(75, 192, 192, 1)',
                                borderWidth: 1
                            }
                        ]
                    },
                    options: {
                        title: {
                            display: false,
                            text: this.year
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        },
                        plugins: {
                            datalabels: {
                                align: 'end',
                                formatter: function (value, context) {
                                    let num_policies = 0;
                                    if (context.dataset.label === 'PEN') {
                                        num_policies = vue.NPEN[context.dataIndex];
                                    }
                                    if (context.dataset.label === 'USD') {
                                        num_policies = vue.NUSD[context.dataIndex];
                                    }
                                    return num_policies;
                                },
                                //rotation: -45,
                            }
                        }
                    }
                });
            },
            onChange() {
                this.getData();
            }
        }
    }
</script>
