<template>
    <div id="chart-renewal">
        <div class="card-title mb-4">
            Gestion de Renovaciones
        </div>

        <div class="row">
            <template v-for="(item, index) in data">
                <div v-if="index === 6" class="w-100 mb-5"></div>
                <div class="col">
                    <div>{{ item.month }}</div>
                    <hr>
                    <div>En renovacion: <span class="font-weight-bold">{{ item.total }}</span></div>
                    <div>Si: <span class="font-weight-bold">{{ item.answer_yes }}</span></div>
                    <div>No: <span class="font-weight-bold">{{ item.answer_no }}</span></div>
                    <div>No contactados: <span class="font-weight-bold">{{ item.answer_pending }}</span></div>
                    <div>Pendientes de gestion: <span class="font-weight-bold">{{ item.pending }}</span></div>
                </div>
            </template>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['currency'],
        data() {
            return {
                items1: [1, 2, 3],
                items2: [1, 2, 3],
                data: {},
                filters: {
                    currency: this.currency
                },
            };
        },
        mounted() {
            this.getData();
        },
        created() {
            let ctx = this;
            this.$root.$on('apply-filter', function (payload) {
                ctx.filters[payload.filter] = payload.value;
                ctx.getData();
            });
        },
        methods: {
            getData() {
                let url = 'chart/policies/renewals';
                axios.get(url, {params: this.filters}).then((response) => {
                    this.data = response.data;
                });
            }
        }
    }
</script>
<style lang="scss">
    #chart-renewal .row {
        font-size: 0.9rem;
        line-height: 1.4rem;
    }
</style>
