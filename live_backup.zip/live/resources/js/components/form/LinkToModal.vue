<template>
    <div class="link-to-modal">
        <a @click.prevent="onClick" href="#">{{ text }}</a>

        <!-- Modal -->
        <div class="modal fade" :id="modalId" tabindex="-1" role="dialog" aria-labelledby="modalIdLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalIdLabel">{{ modalTitle }}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <crm-dashboard-detail v-if="isOpen" :endpoint="url"></crm-dashboard-detail>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        text: {type: String},
        url: {type: String},
        modalTitle: {type: String, default: 'Modal Title'}
    },
    data() {
        return {isOpen: false}
    },
    computed: {
        modalId() {
            return Math.random().toString(36).substring(7)
        }
    },
    mounted() {
        let ctx = this
        $('#' + this.modalId).on('hide.bs.modal', function (e) {
            ctx.isOpen = false
        })
    },
    methods: {
        onClick() {
            this.isOpen = true
            $('#' + this.modalId).modal('toggle')
        }
    }
}
</script>
