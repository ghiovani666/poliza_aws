<template>
    <div v-on-clickaway="onClickAway" class="dropdown">
        <div @click="open = !open" class="label">
            <i class="fas fa-chevron-down"></i>
            {{ label }}
        </div>
        <div v-show="open" class="items">
            <ul>
                <li v-for="item in items" class="item">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input"
                               :id="'chkItem'+item[itemValue]"
                               :checked="itemsChecked.includes(String(item[itemValue]))"
                               name="employee[]"
                               :value="item[itemValue]"
                               v-model="itemsSelected"
                               @change="onChange"
                        >
                        <label class="custom-control-label" :for="'chkItem'+item[itemValue]">
                            {{ item[itemText] }}
                        </label>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import {mixin as clickaway} from 'vue-clickaway';

export default {
    mixins: [clickaway],
    props: {
        items: {
            type: Array,
            default: [],
        },
        label: {
            type: String,
            default: 'Options',
        },
        itemValue: {
            type: String,
            default: 'value',
        },
        itemText: {
            type: String,
            default: 'text',
        },
        itemsChecked: {
            type: Array,
            default: [],
        }
    },
    data() {
        return {
            open: false,
            itemsSelected: []
        }
    },
    methods: {
        onChange() {
            this.$emit('change', this.itemsSelected)
        },
        onClickAway() {
            this.open = false
        }
    }
}
</script>

<style lang="scss" scoped>
.dropdown {
    width: 100%;
    position: relative;

    .label {
        position: relative;
        border: 1px solid #ced4da;
        padding: 0.375rem 0.75rem;
        border-radius: 0.5rem;
        background-color: white;
        cursor: pointer;

        i {
            position: absolute;
            top: 8px;
            right: 8px;
        }
    }

    .items {
        width: 100%;
        position: absolute;
        top: 32px;
        right: 0;
        background-color: white;
        padding: 0.375rem 0.75rem;
        border: 1px solid #ced4da;
        border-radius: 0.5rem;
        z-index: 100;
        max-height: 400px;
        overflow: auto;
    }

    ul {
        padding: 0;
        list-style: none;
        margin: 0.5rem 0 0;

        li {
            padding: 0;
            margin: 0 0 0.5rem;
        }
    }
}
</style>
