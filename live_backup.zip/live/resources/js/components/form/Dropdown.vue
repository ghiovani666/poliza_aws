<template>
  <div v-on-clickaway="onClickAway" class="dropdown">
    <div @click="open = !open" class="label">
      <i class="fas fa-chevron-down"></i>
      {{ selectedLabel }}
      <input :name="inputName" type="hidden" :value="itemSelected.id">
    </div>
    <div v-show="open" class="items">
      <ul>
        <li v-for="item in items" class="item">
          <span v-if="isSelect" @click="onSelect(item)" style="cursor: pointer">{{ item[itemText] }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import {RoleEventBus} from '../../app'
import {mixin as clickaway} from 'vue-clickaway';

const MODE_SELECT = 'select'
const MODE_CHECKBOX = 'checkbox'

export default {
  mixins: [clickaway],
  props: {
    type: {
      type: String,
      default: MODE_SELECT, // select, checkbox
    },
    label: {
      type: String,
      default: 'Options',
    },
    inputName: {
      type: String,
      default: 'input-name',
    },
    items: {
      type: Array,
      default: [],
    },
    itemValue: {
      type: String,
      default: 'value',
    },
    itemText: {
      type: String,
      default: 'text',
    },
    itemsChecked: {
      type: Array,
      default: [],
    }
  },
  data() {
    return {
      open: false,
      itemSelected: {},
      itemsSelected: []
    }
  },
  computed: {
    isSelect() {
      return this.type === MODE_SELECT
    },
    isCheckbox() {
      return this.type === MODE_CHECKBOX
    },
    selectedLabel() {
      if (parseInt(this.itemSelected.id) > 0) {
        return this.itemSelected.name
      }
      return this.label
    }
  },
  created() {
    RoleEventBus.$on('onSelect', (data) => {
      console.log(data)
    })
  },
  methods: {
    onChange() {
      this.$emit('change', this.itemsSelected)
    },
    onClickAway() {
      this.open = false
    },
    onSelect(item) {
      this.open = false
      this.itemSelected = item
      RoleEventBus.$emit('onSelect', {inputName: this.inputName, item: item})
    }
  }
}
</script>

<style lang="scss" scoped>
.dropdown {
  width: 100%;
  position: relative;

  .label {
    position: relative;
    border: 1px solid #ced4da;
    padding: 0.375rem 0.75rem;
    border-radius: 0.5rem;
    background-color: white;
    cursor: pointer;

    i {
      position: absolute;
      top: 8px;
      right: 8px;
    }
  }

  .items {
    width: 100%;
    position: absolute;
    top: 32px;
    right: 0;
    background-color: white;
    padding: 0.375rem 0.75rem;
    border: 1px solid #ced4da;
    border-radius: 0.5rem;
    z-index: 100;
    max-height: 400px;
    overflow: auto;
  }

  ul {
    padding: 0;
    list-style: none;
    margin: 0.5rem 0 0;

    li {
      padding: 0;
      margin: 0 0 0.5rem;
    }
  }
}
</style>
