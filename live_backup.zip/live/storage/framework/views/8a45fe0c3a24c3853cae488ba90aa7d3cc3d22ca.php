<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Cambio de via cobro</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('payment_collections.index')); ?>">Cambio de via cobro</a></li>
                        <li class="breadcrumb-item"><a
                                href="<?php echo e(route('payment_collections.edit',$paymentCollection)); ?>"><?php echo e($paymentCollection->id); ?></a></li>
                        <li aria-current="page" class="breadcrumb-item active">Actualizar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <?php echo e(Form::model($paymentCollection,['url' => route('payment_collections.update', $paymentCollection), 'method' => 'PUT'])); ?>

                        <?php echo $__env->make('payment_collections._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=company_id]').select2();
            $('select[name=sector_id]').select2();
            $('select[name=product_id]').select2();
            $('select[name=customer_id]').select2();
            $('select[name=bank_id]').select2();
            $('select[name=assessor_id]').select2();
            $('#policy_id').select2();

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                axios.get('/api/sectors?company_id=' + company_id).then((response) => {
                    $('select[name=sector_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                axios.get('/api/products?sector_id=' + sector_id).then((response) => {
                    $('select[name=product_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });

            // policy
            $('select[name=customer_id]').change(function () {
                let customer_id = $(this).val();
                axios.get('/api/policies?customer_id=' + customer_id).then((response) => {
                    $('#policy_id').empty();
                    response.data.data.forEach(function (policy) {
                        $('#policy_id').append($("<option />").val(policy.id).text(policy.code));
                    });
                });
            });
        };
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/payment_collections/edit.blade.php ENDPATH**/ ?>