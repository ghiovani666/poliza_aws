<div class="row">
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Compañia</label>
            <div class="col">
                <?php echo e(Form::select('company_id', dropdownData('Companies'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Contratante</label>
            <div class="col">
                <?php echo e(Form::select('customer_id', dropdownData('Customers'), null, ['class' => 'form-control'.($errors->has('customer_id') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -'])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('customer_id')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Banco</label>
            <div class="col">
                <?php echo e(Form::select('bank_id', dropdownData('Banks'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ticket</label>
            <div class="col">
                <?php echo e(Form::text('ticket', null, ['class' => 'form-control'.($errors->has('ticket') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('ticket')); ?></div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Asesor</label>
            <div class="col">
                <?php echo e(Form::select('assessor_id', dropdownData('Employees'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Poliza</label>
            <div class="col">
                <?php echo e(Form::select('policy_id', dropdownData('Policies', $finance ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Ramo</label>
            <div class="col">
                <?php echo e(Form::select('sector_id', dropdownData('Sectors', $finance ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Producto</label>
            <div class="col">
                <?php echo e(Form::select('product_id', dropdownData('Products', $finance ?? null), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Cuotas (#)</label>
            <div class="col">
                <?php echo e(Form::select('dues', dropdownData('Dues'), null, ['class' => 'form-control'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo de doc.</label>
            <div class="col">
                <?php echo e(Form::select('payment_type', dropdownData('PaymentType'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
    </div>
    <div class="col">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Status</label>
            <div class="col">
                <?php echo e(Form::select('status', dropdownData('FinanceStatuses'), null, ['class' => 'form-control', 'placeholder' => '- Seleccionar -'])); ?>

            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Financiamiento</label>
            <div class="col">
                <?php echo e(Form::text('finance', null, ['class' => 'form-control'])); ?>

            </div>
        </div>
        <div class="form-group">Observaciones</div>
        <div class="form-group">
            <?php echo e(Form::textarea('comments', null, ['class' => 'form-control'])); ?>

        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=company_id]').select2();
            $('select[name=sector_id]').select2();
            $('select[name=product_id]').select2();
            $('select[name=customer_id]').select2();
            $('select[name=bank_id]').select2();
            $('select[name=assessor_id]').select2();
            $('select[name=policy_id]').select2();

            // key
            $('select[name=company_id]').change(function () {
                let company_id = $(this).val();
                axios.get('sectors?company_id=' + company_id).then((response) => {
                    $('select[name=sector_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=sector_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });
            $('select[name=sector_id]').change(function () {
                let sector_id = $(this).val();
                axios.get('products?sector_id=' + sector_id).then((response) => {
                    $('select[name=product_id]').empty();
                    response.data.data.forEach(function (sector) {
                        $('select[name=product_id]').append($("<option />").val(sector.id).text(sector.name));
                    });
                });
            });

            // policy
            $('select[name=customer_id]').change(function () {
                let customer_id = $(this).val();
                axios.get('policies?customer_id=' + customer_id).then((response) => {
                    $('select[name=policy_id]').empty();
                    response.data.data.forEach(function (policy) {
                        $('select[name=policy_id]').append($("<option />").val(policy.id).text(policy.code));
                    });
                });
            });
        };
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/ubuntu/morgan/live/resources/views/finances/_form.blade.php ENDPATH**/ ?>