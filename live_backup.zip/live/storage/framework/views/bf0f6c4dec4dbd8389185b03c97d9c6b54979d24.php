<div class="row">
    <div class="col-6">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo</label>
            <div class="col">
                <?php echo e(Form::select('type', dropdownData('VehicleTypes'), null, ['class' => 'form-control'.($errors->has('type') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('type')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Uso</label>
            <div class="col">
                <?php echo e(Form::text('use', null, ['class' => 'form-control'.($errors->has('use') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('use')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Placa</label>
            <div class="col">
                <?php echo e(Form::text('plate_number', null, ['class' => 'form-control'.($errors->has('plate_number') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('plate_number')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Motor</label>
            <div class="col">
                <?php echo e(Form::text('engine', null, ['class' => 'form-control'.($errors->has('engine') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('engine')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Chasis</label>
            <div class="col">
                <?php echo e(Form::text('chassis', null, ['class' => 'form-control'.($errors->has('chassis') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('chassis')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Marca</label>
            <div class="col">
                <?php echo e(Form::text('brand', null, ['class' => 'form-control'.($errors->has('brand') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('brand')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Modelo</label>
            <div class="col">
                <?php echo e(Form::text('model', null, ['class' => 'form-control'.($errors->has('model') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('model')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Año de fabricacion</label>
            <div class="col">
                <?php echo e(Form::text('manufacturing_year', null, ['class' => 'form-control'.($errors->has('manufacturing_year') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('manufacturing_year')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Valor comercial</label>
            <div class="col">
                <div class="row no-gutters">
                    <div class="col-4 mr-2">
                        <?php echo e(Form::select('currency', \App\Enums\CurrencyType::toArray(), null, ['class' => 'form-control'.($errors->has('currency') ? ' is-invalid': null)])); ?>

                        <div class="invalid-feedback"><?php echo e($errors->first('currency')); ?></div>
                    </div>
                    <div class="col">
                        <?php echo e(Form::text('commercial_value', null, ['class' => 'form-control'.($errors->has('commercial_value') ? ' is-invalid': null)])); ?>

                        <div class="invalid-feedback"><?php echo e($errors->first('commercial_value')); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Numero de certificado</label>
            <div class="col">
                <?php echo e(Form::text('certificate_number', null, ['class' => 'form-control'.($errors->has('certificate_number') ? ' is-invalid': null)])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('certificate_number')); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Endoso</label>
            <div class="col">
                <?php echo e(Form::select('endorsement', dropdownData('YesNot'), null, ['class' => 'form-control'.($errors->has('endorsement') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -'])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('endorsement')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Tipo</label>
            <div class="col">
                <?php echo e(Form::select('endorsement_type', [
                    1 => 'Inclusion',
                    0 => 'Exclusion',
                ], null, ['class' => 'form-control'.($errors->has('endorsement_type') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -'])); ?>

                <div class="invalid-feedback"><?php echo e($errors->first('endorsement_type')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <label class="col-4 col-form-label">Monto</label>
            <div class="col">
                <div class="row no-gutters">
                    <div class="col-2">
                        <?php echo e(Form::select('endorsement_operator', [
                            '+' => '+',
                            '-' => '-',
                        ], null, ['class' => 'form-control'.($errors->has('endorsement_operator') ? ' is-invalid': null), 'placeholder' => '- Seleccionar -'])); ?>

                        <div class="invalid-feedback"><?php echo e($errors->first('endorsement_operator')); ?></div>
                    </div>
                    <div class="col">
                        <?php echo e(Form::text('endorsement_amount', null, ['class' => 'form-control'.($errors->has('endorsement_amount') ? ' is-invalid': null)])); ?>

                        <div class="invalid-feedback"><?php echo e($errors->first('endorsement_amount')); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        window.onload = function () {
            $('select[name=endorsement]').change(function () {
                checkEndorsement();
            });

            checkEndorsement();
        };

        function checkEndorsement() {
            let endorsement = $('select[name=endorsement]').val();
            if (parseInt(endorsement)) {
                $('select[name=endorsement_type]').removeAttr('disabled');
                $('select[name=endorsement_operator]').removeAttr('disabled');
                $('input[name=endorsement_amount]').removeAttr('disabled');
            } else {
                $('select[name=endorsement_type]').attr('disabled', 'disabled');
                $('select[name=endorsement_operator]').attr('disabled', 'disabled');
                $('input[name=endorsement_amount]').attr('disabled', 'disabled');
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/vehicles/_form.blade.php ENDPATH**/ ?>