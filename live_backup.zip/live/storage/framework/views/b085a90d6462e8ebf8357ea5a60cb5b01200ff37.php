<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <img src="<?php echo e(asset('img/morgan-logo.png')); ?>">
        </a>
    </td>
</tr>
<?php /**PATH /home/ubuntu/morgan/live/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>