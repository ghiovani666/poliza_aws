<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">Mi Perfil</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Mi Perfil</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">

                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo e(Form::model($employee,['url' => route('profile.update'), 'method' => 'POST'])); ?>

                        <div class="row">
                            <div class="col">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Nombre</label>
                                    <div class="col">
                                        <?php echo e(Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid': null)])); ?>

                                        <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Correo</label>
                                    <div class="col">
                                        <?php echo e(Form::text('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid': null)])); ?>

                                        <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Telefono</label>
                                    <div class="col">
                                        <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">DNI</label>
                                    <div class="col">
                                        <?php echo e(Form::text('dni', null, ['class' => 'form-control'])); ?>

                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Fecha de nacimiento</label>
                                    <div class="col">
                                        <?php echo e(Form::date('birth_date', null, ['class' => 'form-control'])); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Cambiar contraseña</label>
                                    <div class="col">
                                        <?php echo e(Form::password('password', ['class' => 'form-control'.($errors->has('password') ? ' is-invalid': null)])); ?>

                                        <div class="text-muted">Llenar solo si desea cambiar su contraseña.</div>
                                        <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                                    </div>
                                </div>
                                <div class="form-row form-group">
                                    <label class="col-4 col-form-label">Confirmar contraseña</label>
                                    <div class="col">
                                        <?php echo e(Form::password('password_confirmation', ['class' => 'form-control'.($errors->has('password_confirmation') ? ' is-invalid': null)])); ?>

                                        <div class="text-muted">Llenar solo si desea cambiar su contraseña.</div>
                                        <div class="invalid-feedback"><?php echo e($errors->first('password_confirmation')); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/profile/edit.blade.php ENDPATH**/ ?>