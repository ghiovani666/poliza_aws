<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Cambio de via cobro</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li aria-current="page" class="breadcrumb-item active">Cambio de via cobro</li>
                    </ol>
                </nav>
                <div class="float-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',\App\PaymentCollection::class)): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('payment_collections.create')); ?>"><i
                                class="fas fa-plus mr-2"></i>Nuevo</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-deleted',\App\PaymentCollection::class)): ?>
                        <a class="btn btn-danger" href="<?php echo e(route('payment_collections.disabled')); ?>"><i
                                class="fas fa-trash-alt mr-2"></i>Eliminados</a>
                    <?php endif; ?>
                </div>
                <div class="card">
                    <div class="card-body">

                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="mb-2">
                            <?php echo e(Form::open(['url' => route('payment_collections.index'), 'method' => 'GET'])); ?>

                            <label>Documento (#)</label>
                            <?php echo e(Form::text('document_number', request('document_number'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline'])); ?>


                            <label class="ml-3">Contratante</label>
                            <?php echo e(Form::text('customer', request('customer'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline'])); ?>


                            <label class="ml-3">Fecha</label>
                            <input name="dates" value="<?php echo e(request('dates')); ?>" style="width: 200px">

                            <label class="ml-3">Status</label>
                            <?php echo e(Form::select('status',$cboStatus, request('status'), ['class' => 'form-control', 'style' => 'width: 200px; display: inline'])); ?>


                            <button class="btn btn-primary  ml-3">Buscar</button>
                            <a href="<?php echo e(route('payment_collections.index')); ?>" class="btn btn-secondary">Resetear</a>
                            <?php echo e(Form::close()); ?>

                        </div>

                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>F. Registro</th>
                                <th>Compañia</th>
                                <th>Ticket</th>
                                <th>Asesor</th>
                                <th>Contratante</th>
                                <th>Polizas</th>
                                <th>Producto</th>
                                <th>Banco</th>
                                <th>Medio de pago</th>
                                <th>Pago facil</th>
                                <th>Status</th>
                                <th>Observaciones</th>
                                <th>Usuario</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $paymentCollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($paymentCollection->id); ?></td>
                                    <td><?php echo e($paymentCollection->createdDateTime); ?></td>
                                    <td><?php echo e($paymentCollection->company->name); ?></td>
                                    <td><?php echo e($paymentCollection->ticket); ?></td>
                                    <td><?php echo e($paymentCollection->assessor->name); ?></td>
                                    <td><?php echo e($paymentCollection->customer->name); ?></td>
                                    <td><?php echo e($paymentCollection->policiesNumber); ?></td>
                                    <td><?php echo e($paymentCollection->product->name); ?></td>
                                    <td><?php echo e($paymentCollection->bank->name); ?></td>
                                    <td><?php echo e($paymentCollection->account_number); ?></td>
                                    <td><?php echo e($paymentCollection->easy_pay); ?></td>
                                    <td><?php echo e($paymentCollection->statusName); ?></td>
                                    <td><?php echo e($paymentCollection->comments); ?></td>
                                    <td><?php echo e($paymentCollection->user->name); ?></td>
                                    <td class="text-right" style="white-space: nowrap">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $paymentCollection)): ?>
                                        <a href="<?php echo e(route('payment_collections.edit', $paymentCollection)); ?>"
                                           class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('disable', $paymentCollection)): ?>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                    data-target="#deleteModal<?php echo e($paymentCollection->id); ?>">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($paymentCollections->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal -->
    <?php $__currentLoopData = $paymentCollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="deleteModal<?php echo e($paymentCollection->id); ?>" tabindex="-1" role="dialog"
             aria-labelledby="deleteModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLongTitle">Eliminar Registro</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="h4 text-center mb-3">¿Seguro que desea eliminar el cambio de via cobro?</div>
                    </div>
                    <div class="modal-footer">
                        <?php echo e(Form::open(['url' => route('payment_collections.disable', $paymentCollection), 'method' => 'PUT'])); ?>

                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Si, eliminar</button>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        window.onload = function () {
            $('input[name="dates"]').daterangepicker({
                "autoApply": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
            }, function (start, end, label) {
                $('input[name="dates"]').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
            });
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/payment_collections/index.blade.php ENDPATH**/ ?>