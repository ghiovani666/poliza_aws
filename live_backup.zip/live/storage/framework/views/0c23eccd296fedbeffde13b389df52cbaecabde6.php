<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">CARTERA DE CLIENTES</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('policies.index')); ?>">Carteda de clientes</a></li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.show',$policy)); ?>"><?php echo e($policy->customer->name); ?></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.documents.index',$policy)); ?>">Documentos</a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Nuevo</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('policies._detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('policies._tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo e(Form::open(['url' => route('policies.documents.store', [$policy]), 'method' => 'POST'])); ?>

                        <?php echo $__env->make('policies.documents._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <a href="<?php echo e(route('policies.documents.index', $policy).'#documents'); ?>"
                                   class="btn btn-secondary">Volver</a>
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/documents/create.blade.php ENDPATH**/ ?>