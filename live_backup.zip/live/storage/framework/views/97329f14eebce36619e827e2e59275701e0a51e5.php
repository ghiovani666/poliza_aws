<ul class="nav nav-tabs mb-2">
    <li class="nav-item">
        <a id="documents"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/comments','policies/*/comments/*'])); ?>"
           href="<?php echo e(route('policies.comments.index',$policy)); ?>#comments">Comentarios</a>
    </li>
    <li class="nav-item">
        <a id="documents"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/documents','policies/*/documents/*'])); ?>"
           href="<?php echo e(route('policies.documents.index',$policy)); ?>#documents">Documentos</a>
    </li>
    <li class="nav-item">
        <a id="beneficiaries"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/beneficiaries','policies/*/beneficiaries/*'])); ?>"
           href="<?php echo e(route('policies.beneficiaries.index',$policy)); ?>#beneficiaries">Beneficiarios</a>
    </li>
    <li class="nav-item">
        <a id="insureds"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/insureds','policies/*/insureds/*'])); ?>"
           href="<?php echo e(route('policies.insureds.index',$policy)); ?>#insureds">Asegurados</a>
    </li>
    <li class="nav-item">
        <a id="vehicles"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/vehicles','policies/*/vehicles/*'])); ?>"
           href="<?php echo e(route('policies.vehicles.index',$policy)); ?>#vehicles">Vehiculos</a>
    </li>
    <li class="nav-item">
        <a id="vehicles"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/payments','policies/*/payments/*'])); ?>"
           href="<?php echo e(route('policies.payments.index',$policy)); ?>#payments">Deudas</a>
    </li>
    <li class="nav-item">
        <a id="alerts"></a>
        <a class="nav-link <?php echo e(activeUrl(['policies/*/alerts','policies/*/alerts/*'])); ?>"
           href="<?php echo e(route('policies.alerts.index',$policy)); ?>#alerts">Alertas</a>
    </li>
</ul>
<?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/_tabs.blade.php ENDPATH**/ ?>