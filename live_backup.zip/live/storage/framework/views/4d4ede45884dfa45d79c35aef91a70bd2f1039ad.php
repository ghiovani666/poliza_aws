<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $policy)): ?>
    <a class="btn btn-secondary" href="<?php echo e(route('policies.edit', $policy)); ?>">
        <i class="fas fa-edit mr-2"></i>Modificar
    </a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-renewal', $policy)): ?>
<button class="btn btn-secondary" data-toggle="modal" <?php if($policy->period === 99): ?> disabled title="Polizas a termino no se pueden renovar." <?php endif; ?>
        data-target="#renewModal<?php echo e($policy->id); ?>">
    <i class="fas fa-retweet mr-2"></i>Renovar
</button>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print', $policy)): ?>
<a class="btn btn-secondary" href="<?php echo e(route('policies.print', $policy)); ?>">
    <i class="fas fa-print mr-2"></i> Imprimir
</a>
<?php endif; ?>

<!-- Renew Modal -->
<div class="modal fade" id="renewModal<?php echo e($policy->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="renewModalLongTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="renewModalLongTitle">Renovar poliza</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="h4 text-center mb-3">¿Seguro que desea renovar la poliza?</div>
            </div>
            <div class="modal-footer">
                <?php echo e(Form::open(['url' => route('policies.renew', [$policy]), 'method' => 'GET'])); ?>

                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Si, renovar</button>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/_nav-secondary.blade.php ENDPATH**/ ?>