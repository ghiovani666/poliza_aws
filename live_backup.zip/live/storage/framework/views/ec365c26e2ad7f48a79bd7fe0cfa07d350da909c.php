<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-trash-alt mr-2"></i> Papelera
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="#">Polizas</a>
                            </li>
                        </ul>

                        <table class="table">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($policy->id); ?></td>
                                    <td><?php echo e($policy->customer->name); ?></td>
                                    <td class="text-right">
                                        <a class="btn btn-secondary btn-sm" title="Restaurar poliza"
                                           href="<?php echo e(route('settings.restore',$policy)); ?>">
                                            <i class="fas fa-trash-restore"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/settings/index.blade.php ENDPATH**/ ?>