<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block text-uppercase">Reclamos</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="/">Inicio</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.index')); ?>">
                                Cartera de clientes
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('customers.show', $policy->customer)); ?>">
                                <?php echo e($policy->customer->name); ?>

                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.comments.index', $policy->id)); ?>">
                                <?php echo e($policy->id); ?>

                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.claims.index', $policy)); ?>">
                                Reclamos
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.claims.edit', [$policy, $claim])); ?>">
                                <?php echo e($claim->id); ?>

                            </a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Editar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <?php echo e(Form::model($claim, ['id' => 'frm-edit', 'url' => route('policies.claims.update', [$policy, $claim]), 'method' => 'PUT'])); ?>

                        <?php echo $__env->make('policies.claims._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr>
                        <div class="row">
                            <div class="col text-right">
                                <button class="btn btn-primary">
                                    Guardar
                                </button>
                            </div>
                        </div>
                        <input name="policy_id" type="hidden" value="<?php echo e($policy->id); ?>">
                        <input id="refresh" name="refresh" type="hidden" value="">
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>

        <div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/claims/edit.blade.php ENDPATH**/ ?>