<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="h2 d-inline-block">EMPLEADOS</div>
                <nav aria-label="breadcrumb" class="d-inline-block align-middle">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('keys.index')); ?>">Policies</a></li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.show',$policy)); ?>"><?php echo e($policy->id); ?></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.beneficiaries.index',$policy)); ?>">Beneficiarios</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('policies.beneficiaries.show',[$policy,$beneficiary])); ?>"><?php echo e($beneficiary->id); ?></a>
                        </li>
                        <li aria-current="page" class="breadcrumb-item active">Actualizar</li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('policies._detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('policies._tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo e(Form::model($beneficiary,['url' => route('policies.beneficiaries.update', [$policy, $beneficiary]), 'method' => 'PUT'])); ?>

                        <?php echo $__env->make('policies.beneficiaries._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <a href="<?php echo e(route('policies.beneficiaries.index', $policy)); ?>#beneficiaries"
                                   class="btn btn-secondary">Volver</a>
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/morgan/live/resources/views/policies/beneficiaries/edit.blade.php ENDPATH**/ ?>